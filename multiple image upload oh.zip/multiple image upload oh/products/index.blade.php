@extends('backend.layouts.app')
@section('title', app_name() . ' | ' . __('Products Management'))
@section('breadcrumb-links')
@include('backend.products.includes.breadcrumb-links')
@endsection
@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    {{ __('Products') }} 
                </h4>
            </div>
            <!--col-->
        </div>
        <!--row-->

        <div class="row mt-4">
            <div class="col">
                <div class="table-responsive">
                    <table id="example" class="table table-striped table-bordered" style="width:100%">
                         <thead>
                            <tr>
                                <th>Id</th>
                                <th>Prodcuts Name</th>
								<th>Description</th>
                                <th>Shipping Location</th>
								<th>Price</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(isset($products) && !empty($products))
                            @foreach($products as $myproducts)
                            <tr>
                                <td>{{$myproducts->id}}</td>
                                <td>{{$myproducts->name}}</td>
                                <td>{{$myproducts->description}}</td>
                                <td>{{$myproducts->shipping_location}}</td>
                                <td>{{$myproducts->price}}</td>
                                <td><img src="{{asset('img/products_image/'.$myproducts->image)}}" width="50"></td>
                                <td>
                                    @if($myproducts->status==1)
                                        Active
                                    @else
                                        Inactive
                                    @endif
                                </td>
                                <td class="btn-td">
                                    <div class="btn-group action-btn"><a href="{{url('admin/products/'.$myproducts->id.'/edit')}}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i>
                                    </a><a href="#" class="btn btn-primary btn-danger btn-sm" data-method="delete" data-trans-button-cancel="Cancel" data-trans-button-confirm="Delete" data-trans-title="Are you sure you want to do this?" style="cursor:pointer;" onclick="$(this).find(&quot;form&quot;).submit();">
                                    <i data-toggle="tooltip" data-placement="top" title="Delete" class="fa fa-trash"></i>
                                    <form action="{{url('admin/products/'.$myproducts->id)}}" method="POST" name="delete_item" style="display:none">
                                    <input type="hidden" name="_method" value="delete">
                                    {{csrf_field()}}
                                    
                                    </form>
                                    </a>
                                    </div>
                                </td>
                            </tr>
                            @endforeach
                            @endif

                    </table>
                </div>
            </div>
            <!--col-->
        </div>
        <!--row-->

    </div>
    <!--card-body-->
</div>
<!--card-->

@endsection
@section('pagescript')
<script>
    $(document).ready(function() {
    $('#example').DataTable();
} );
</script>

@stop
