<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use DateTime;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Product;
use App\Models\Coupon;
use App\Models\ProductsImage;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Models\Product\AddCart;
use App\Models\Product\Review;
use App\Models\Product\ProductView;
use App\Models\Product\ProductFavorite;
use App\Models\Product\OrderItem;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class ProductController extends APIController
{

        /*
        * UPDATE PASSWORD API END HERE
        */
        public function getProduct(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $getProduct=Product::with('images')->get();
            $procucts=array();
            $imagedata=array();
            foreach($getProduct as $p=>$procuct)
            {
                $procucts[$p]['id']=$procuct->id;
                $procucts[$p]['name']=$procuct->name;
                $procucts[$p]['description']=$procuct->description;
                $procucts[$p]['price']=$procuct->price;
                foreach($procuct->images as $pm=> $imageinfo)
                {
                    $imagedata[$pm]['image_id']=$imageinfo->id;
                    $imagedata[$pm]['image_name']=url('img/products_image/'.$imageinfo->image);
                }
                $procucts[$p]['images']=$imagedata;
                $userreviewlist=Review::with('getUser')->where('p_id',$procuct->id)
                            ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                        $ratingsum1=0;
                        $totaluser1=count($userreviewlist);
                        foreach($userreviewlist as $r=>$list)
                        {
                            $ratingsum1=$ratingsum1+$list->rating;
                        }
                    $procucts[$p]['totaloverallrating']=0;
                    $procucts[$p]['totalusercount']=$totaluser1;
                    if($ratingsum1!=0)
                    {
                        $procucts[$p]['totaloverallrating']=$ratingsum1/$totaluser1;
                    }
                   //favoritedata
                            $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$procuct->id."')")->first();
                            if(!empty($checkfavorite))
                            {
                                $isfavorite=true; 
                            }else
                            {
                                $isfavorite=false;
                            }
                    $procucts[$p]['is_favorite']= $isfavorite;
                    $totalfavorite=DB::table('product_favorite')->where('p_id',$procuct->id)->count();
                    $procucts[$p]['favorite_count']= $totalfavorite;

            }

            //Banner

            $productBanner=DB::table('product_banners')->where('status',1)->get();
            $banerData=array();
            foreach($productBanner as $b=>$banner)
            {
                $banerData[$b]['product_banner']=url('img/product_banners/'.$banner->product_banner);
            }

            //Business Type
            $categorys=DB::table('business_types')->where('status',1)->get();
            $businessCat=array();
            foreach($categorys as $c=>$category)
            {
                $businessCat[$c]['id']=$category->id;
                $businessCat[$c]['category_name']=$category->business_name;
            }

            //Business Type
            $categorys=DB::table('business_types')->where('status',1)->get();
            $businessCat=array();
            foreach($categorys as $c=>$category)
            {
                $businessCat[$c]['id']=$category->id;
                $businessCat[$c]['category_name']=$category->business_name;
            }

            //Coupans Type
            $discountCoupan=Coupon::where('status',1)->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'))
                ->get();
              //  echo '<pre>'; print_r($discountCoupan);exit;
            $discountCard=array();
            foreach($discountCoupan as $d=>$discount)
            {
                $discountCard[$d]['id']=$discount->id;
                $discountCard[$d]['min_order_value']=$discount->min_order_value;
                $discountCard[$d]['max_discount']=$discount->max_discount;
                $discountCard[$d]['coupon']=$discount->coupon;
                $discountCard[$d]['end_date']=$discount->end_date;
            }

            //On sale
              $onsaleProduct=  OrderItem::with('onSaleProduct')
                ->select('p_id', DB::raw('count(*) as total'))
                 ->groupBy('p_id')
                ->orderBy('total', 'DESC')
                 ->take(10)
                 ->get();

                $procuctssale=array();
                foreach($onsaleProduct as $p=>$procuct)
                {
                    $procuctssale[$p]['id']=$procuct->onSaleProduct->id;
                    $procuctssale[$p]['name']=$procuct->onSaleProduct->name;
                    $procuctssale[$p]['description']=$procuct->onSaleProduct->description;
                    $procuctssale[$p]['price']=$procuct->onSaleProduct->price;
                    if(!empty($procuct->onSaleProduct->singleImages))
                    {
                        $procuctssale[$p]['image_id']=$procuct->onSaleProduct->singleImages->id;
                        $procuctssale[$p]['image_name']=url('img/products_image/'.$procuct->onSaleProduct->singleImages->image);
                    }

                    $userreviewlist=Review::with('getUser')->where('p_id',$procuct->p_id)
                            ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                        $ratingsum1=0;
                        $totaluser1=count($userreviewlist);
                        foreach($userreviewlist as $r=>$list)
                        {
                            $ratingsum1=$ratingsum1+$list->rating;
                        }
                    $procuctssale[$p]['totaloverallrating']=0;
                    $procuctssale[$p]['totalusercount']=$totaluser1;
                    if($ratingsum1!=0)
                    {
                        $procuctssale[$p]['totaloverallrating']=$ratingsum1/$totaluser1;
                    }
                   //favoritedata
                            $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$procuct->p_id."')")->first();
                            if(!empty($checkfavorite))
                            {
                                $isfavorite=true; 
                            }else
                            {
                                $isfavorite=false;
                            }
                    $procuctssale[$p]['is_favorite']= $isfavorite;
                    $totalfavorite=DB::table('product_favorite')->where('p_id',$procuct->id)->count();
                    $procuctssale[$p]['favorite_count']= $totalfavorite;
                }
               
               //  echo '<pre>'; print_r($onsaleProduct);exit;
            $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();

            $resultArray['status']='1';
            $resultArray['message']=trans('product.frontend.product_list');
            $resultArray['data']=$procucts;
            $resultArray['banner']=$banerData;
            $resultArray['category']=$businessCat;
            $resultArray['discount']=$discountCard;
            $resultArray['count']=$getitemsCount;
            $resultArray['onsaleproduct']=$procuctssale;
            $resultArray['mostpopular']=$procuctssale;
            return response()->json($resultArray); exit;
        }

        public function productDetail(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $validator = Validator::make($request->all(), [
                'product_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $checkview= ProductView::whereRaw("(user_id='".$request->user_id."' AND p_id='".$request->product_id."')")->first();
            if(empty($checkview))
            {
                $addview= new ProductView;
                $addview->user_id=$request->user_id;
                $addview->p_id=$request->product_id;
                $addview->save();
            }

            $productDetail=Product::with('images')->where('id',$request->product_id)->first();
            $viewcount= ProductView::where('p_id',$request->product_id)->count();
            if(!empty($productDetail))
            {
                $procucts['id']=$productDetail->id;
                $procucts['name']=$productDetail->name;
                $procucts['description']=isset($productDetail->description)?$productDetail->description:'';
                $procucts['shipping_location']=isset($productDetail->shipping_location)?$productDetail->shipping_location:'';
                $procucts['price']=$productDetail->price;
                $procucts['view']=$viewcount;
                $imagedata=array();
                foreach($productDetail->images as $pm=> $imageinfo)
                {
                    $imagedata[$pm]['image_id']=$imageinfo->id;
                    $imagedata[$pm]['image_name']=url('img/products_image/'.$imageinfo->image);
                }
                $procucts['images']=$imagedata;
                //favoritedata
                    $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$productDetail->id."')")->first();
                    if(!empty($checkfavorite))
                    {
                        $isfavorite=true; 
                    }else
                    {
                        $isfavorite=false;
                    }
                $procucts['is_favorite']= $isfavorite;

                // item cart count
                $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();

                //Review List
                $userreviewlist=Review::with('getUser')->where('p_id',$request->product_id)         ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                $reviewArray=array();
                $ratingsum=0;
                $totaluser=count($userreviewlist);
                foreach($userreviewlist as $r=>$list)
                {
                    $reviewArray[$r]['user_name']=$list->getUser->first_name;
                    $reviewArray[$r]['user_image']='';
                    if(!empty($list->getUser->avatar_location))
                    {
                       $reviewArray[$r]['user_image']=url('img/user/profile/'.$list->getUser->avatar_location); 
                    }
                    
                    $reviewArray[$r]['rating']=$list->rating;
                    $reviewArray[$r]['description']=$list->description;
                    $reviewArray[$r]['image1']='';
                    $reviewArray[$r]['image2']='';
                    if(!empty($list->image))
                    {
                        $reviewArray[$r]['image1']=url('img/review/'.$list->image);
                    }
                    if(!empty($list->image2))
                    {
                        $reviewArray[$r]['image2']=url('img/review/'.$list->image2);
                    }
                        $ratingsum=$ratingsum+$list->rating;
                }

                $procucts['totalusercount']=$totaluser;
                $procucts['totaloverallrating']=0;
                if($ratingsum !=0)
                {
                    $procucts['totaloverallrating']=$ratingsum/$totaluser;
                }
               

                // Similar Product
                $similarProduct=Product::with('images')->where('name','NOT LIKE','%'.$productDetail->name.'%')->get();
                 //echo '<pre>'; print_r($similarProduct);exit;
                $procuctssimilar=array();
                foreach($similarProduct as $s=>$similar)
                {
                    $procuctssimilar[$s]['id']=$similar->id;
                    $procuctssimilar[$s]['name']=$similar->name;
                    $procuctssimilar[$s]['description']=$similar->description;
                    $procuctssimilar[$s]['price']=$similar->price;
                    $imagedata1=array();
                    foreach($similar->images as $pm=> $imageinfo)
                    {
                        $imagedata1[$pm]['image_id']=$imageinfo->id;
                        $imagedata1[$pm]['image_name']=url('img/products_image/'.$imageinfo->image);
                    }
                    $procuctssimilar[$s]['images']=$imagedata1;
                    //favoritedata
                    $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$similar->id."')")->first();
                    if(!empty($checkfavorite))
                    {
                        $isfavorite=true; 
                    }else
                    {
                        $isfavorite=false;
                    }
                    $procuctssimilar[$s]['is_favorite']= $isfavorite;
                    //
                    $userreviewlist=Review::with('getUser')->where('p_id',$similar->id)
                            ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                        $ratingsum1=0;
                        $totaluser1=count($userreviewlist);
                        foreach($userreviewlist as $r=>$list)
                        {
                            $ratingsum1=$ratingsum1+$list->rating;
                        }
                    $procuctssimilar[$s]['totaloverallrating']=0;
                    $procuctssimilar[$s]['totalusercount']=$totaluser1;
                    if($ratingsum1!=0)
                    {
                        $procuctssimilar[$s]['totaloverallrating']=$ratingsum1/$totaluser1;
                    }
                }
                //commentMessage
                $commentmessage=DB::table('product_comment')
                    ->join('users','users.id','=','product_comment.user_id')
                    ->where('p_id',$request->product_id)
                    ->get();
                $commentArray= array();    
                foreach($commentmessage as $k=>$message)
                {
                    $commentArray[$k]['user_name']=$message->first_name;
                    $commentArray[$k]['user_image']='';
                    if(!empty($message->avatar_location))
                    {
                       $commentArray[$r]['user_image']=url('img/user/profile/'.$message->avatar_location); 
                    }
                    $commentArray[$k]['comment']=$message->comment;
                }
                $totalfavorite=DB::table('product_favorite')->where('p_id',$request->product_id)->count();

                $resultArray['status']='1';
                $resultArray['message']=trans('product.frontend.product_detail');
                $resultArray['data']=$procucts;
                $resultArray['count']=$getitemsCount;
                $resultArray['review']=$reviewArray;
                $resultArray['similarproduct']=$procuctssimilar;
                $resultArray['comment']=$commentArray;
                $resultArray['favorite_count']=$totalfavorite;
                return response()->json($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('product.data_not_found');
                return response()->json($resultArray); exit;
            }
        }

        public function categoryFilter(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $catgory= isset($request->category_id)?$request->category_id:'';
            $subcatgory= isset($request->sub_category_id)?$request->sub_category_id:'';
            $productDataArray=array();
          
            if(!empty($catgory) && empty($subcatgory))
            {   
                $getsubcat=DB::table('business_services')->where('business_id',$catgory)->get();
                foreach($getsubcat as $cat=>$cateproduct)
                {   
                    $checkproductcount=Product::where('sub_cat_id',$cateproduct->id)->count();
                    if($checkproductcount>0)
                    {
                        $productData['sub_cat_id']=$cateproduct->id;
                        $productData['category_name']=$cateproduct->service_name;
                        $getproducts=Product::with('singleImages')->where('sub_cat_id',$cateproduct->id)->get();
                        $productArray=array();
                        foreach($getproducts as $pp=>$cateproduct)
                        {
                            $productArray[$pp]['id']=$cateproduct->id;
                            $productArray[$pp]['name']=$cateproduct->name;
                            $productArray[$pp]['description']=$cateproduct->description;
                            $productArray[$pp]['price']=$cateproduct->price;
                            $productArray[$pp]['image_name']='';
                            if(!empty($cateproduct['singleImages']->image))
                            {
                                $productArray[$pp]['image_name']=url('img/products_image/'.$cateproduct['singleImages']->image);
                            }
                            
                            //
                            $userreviewlist=Review::with('getUser')->where('p_id',$cateproduct->id)
                            ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                                $ratingsum1=0;
                                $totaluser1=count($userreviewlist);
                                foreach($userreviewlist as $r=>$list)
                                {
                                    $ratingsum1=$ratingsum1+$list->rating;
                                }

                                
                                $productArray[$pp]['totaloverallrating']=0;
                                $productArray[$pp]['totalusercount']=$totaluser1;
                                if($ratingsum1!=0)
                                {
                                    $productArray[$pp]['totaloverallrating']=$ratingsum1/$totaluser1;
                                }

                                //favoritedata
                                $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$cateproduct->id."')")->first();
                                if(!empty($checkfavorite))
                                {
                                    $isfavorite=true; 
                                }else
                                {
                                    $isfavorite=false;
                                }
                            $productArray[$pp]['is_favorite']= $isfavorite;
                            $totalfavorite=DB::table('product_favorite')->where('p_id',$cateproduct->id)->count();
                            $productArray[$pp]['favorite_count']= $totalfavorite;
                            
                        }
                        $productData['product']=$productArray;

                        array_push($productDataArray, $productData);
                    }
                }
            }

            elseif(!empty($catgory) && !empty($subcatgory))
            {
               $getProduct= Product::with('singleImages')->where('category_id',$catgory)->where('sub_cat_id',$subcatgory)->get();

                foreach($getProduct as $pp=>$cateproduct)
                {
                    $productData['id']=$cateproduct->id;
                    $productData['name']=$cateproduct->name;
                    $productData['description']=$cateproduct->description;
                    $productData['price']=$cateproduct->price;
                    $productData['image_name']=url('img/products_image/'.$cateproduct['singleImages']->image);

                    $userreviewlist=Review::with('getUser')->where('p_id',$cateproduct->id)
                            ->groupBy('user_id')
                            ->orderBy('id','desc')
                            ->get();
                        $ratingsum1=0;
                        $totaluser1=count($userreviewlist);
                        foreach($userreviewlist as $r=>$list)
                        {
                            $ratingsum1=$ratingsum1+$list->rating;
                        }
                    $productData['totaloverallrating']=0;
                    $productData['totalusercount']=$totaluser1;
                    if($ratingsum1!=0)
                    {
                        $productData['totaloverallrating']=$ratingsum1/$totaluser1;
                    }
                   //favoritedata
                            $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$request->user_id."' AND p_id='".$cateproduct->id."')")->first();
                            if(!empty($checkfavorite))
                            {
                                $isfavorite=true; 
                            }else
                            {
                                $isfavorite=false;
                            }
                    $productData['is_favorite']= $isfavorite;
                    $totalfavorite=DB::table('product_favorite')->where('p_id',$cateproduct->id)->count();
                    $productData['favorite_count']= $totalfavorite;

                     array_push($productDataArray, $productData);
                }
            }

            $subCats=DB::table('business_services')->where('business_id',$catgory)->get();  
            $subCategory=array();
            foreach($subCats as $c=>$subCat)
            {
                $subCategory[$c]['id']=$subCat->id;
                $subCategory[$c]['name']=$subCat->service_name;
            }

                $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();

                $resultArray['status']='1';
                $resultArray['message']=trans('product.frontend.product_detail');
                $resultArray['data']=$productDataArray;
                $resultArray['sub_category']=$subCategory;
                $resultArray['count']=$getitemsCount;
                return response()->json($resultArray); exit;
        }



        public function getLookBook(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $getlookbooks= DB::table('look_books')->get();
            if(!empty($request->category_id))
            {
                $getlookbooks=DB::table('look_books')->where('category_id',$request->category_id)->get();
            }

            $lookbooksArray=array();
            foreach($getlookbooks as $l=>$lookbook)
            {
                $lookbooksArray[$l]['look_book_id']=$lookbook->id;  
                $lookbooksArray[$l]['seller_id']=$lookbook->seller_id;  
                $lookbooksArray[$l]['image']=url('img/lookbook/'.$lookbook->look_book_image);  
            }

            //Business Type
            $categorys=DB::table('business_types')->where('status',1)->get();
            $businessCat=array();
            foreach($categorys as $c=>$category)
            {
                $businessCat[$c]['id']=$category->id;
                $businessCat[$c]['category_name']=$category->business_name;
                $businessCat[$c]['image']=url('img/businessimage/'.$category->business_image);  
            }

            $resultArray['status']='1';
            $resultArray['message']=trans('api.messages.look_book_get');
            $resultArray['lookbook']=$lookbooksArray;
            $resultArray['category']=$businessCat;
            return response()->json($resultArray); exit;  
        }   

        public function getLookBookDetal(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $validator = Validator::make($request->all(), [
                'look_book_id'=> 'required',
                'seller_id'=> 'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']= trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $getlookbooks=DB::table('look_books')->where('id',$request->look_book_id)->first();
            $totallikes=DB::table('look_book_favorites')->where('look_book_id',$getlookbooks->id)->count();
               
            if(!empty($getlookbooks))
            {
                $lookbooksArray['look_book_id']=$getlookbooks->id;  
                $lookbooksArray['seller_id']=$getlookbooks->seller_id;  
                $lookbooksArray['image']=url('img/lookbook/'.$getlookbooks->look_book_image);  

                $resultArray['status']='1';
                $resultArray['message']=trans('api.messages.look_book_detail');
                $resultArray['data']=$lookbooksArray;
                $resultArray['likes_count']=$totallikes;
                return response()->json($resultArray); exit; 
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.messages.look_book_not_found');
                return response()->json($resultArray); exit; 
            }
                
        }

        public function favorite(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'product_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $productId = isset($request->product_id) && !empty($request->product_id) ? $request->product_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                   
                    $checkfavorite=DB::table('product_favorite')->whereRaw("(user_id='".$userId."' AND p_id='".$productId."')")->first();
                    if(empty($checkfavorite))
                    {
                        DB::table('product_favorite')->insert([
                                                'user_id'=>$userId,
                                                'p_id'=>$productId
                                                ]);
                        $message='Favorite';
                        $isfavorite=true; 
                    }else
                    {
                        DB::table('product_favorite')->whereRaw("(user_id='".$userId."' AND p_id='".$productId."')")->delete();
                        $isfavorite=false;
                        $message='Unfavorite';
                    }

                        $totalfavorite=DB::table('product_favorite')->where('p_id',$productId)->count();
                        $resultArray['status']='1';
                        $resultArray['message']=$message;
                        $resultArray['is_favorite']=$isfavorite;
                        $resultArray['favorite_count']=$totalfavorite;
                        return response()->json($resultArray); exit;
        }

        public function favoriteList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
             
                    $favoriteLists=ProductFavorite::with('getProductInfo')
                                ->where('user_id',$userId)
                                ->get();
                               
                    if(count($favoriteLists)>0)
                    {
                        $favoritedata=array();
                        foreach ($favoriteLists as $key => $favoriteList)
                        {
                            $favoritedata[$key]['id']=isset($favoriteList->p_id)?$favoriteList->p_id:'';
                            $favoritedata[$key]['name']=isset($favoriteList->getProductInfo->name)?$favoriteList->getProductInfo->name:'';
                            $favoritedata[$key]['price']=isset($favoriteList->getProductInfo->price)?$favoriteList->getProductInfo->price:'';
                           
                            $favoritedata[$key]['image']='';
                            if(!empty($favoriteList->getProductInfo->singleImages->image) && file_exists(public_path('img/products_image/'.$favoriteList->getProductInfo->singleImages->image)))
                            {
                                $favoritedata[$key]['image']= url('img/products_image/'.$favoriteList->getProductInfo->singleImages->image);
                            }
                            $totalfavorite=DB::table('product_favorite')->where('p_id',$favoriteList->p_id)->count();
                            $favoritedata[$key]['favorite_count']=$totalfavorite;
                        }

                       

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.favorite_list');
                        $resultArray['data']=$favoritedata;
                        return response()->json($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.favorite_not_found');
                        return response()->json($resultArray); exit;
                    }
        }

        public function comment(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'product_id'=>'required',
                'message'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $productId = isset($request->product_id) && !empty($request->product_id) ? $request->product_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                $addcommet= array('user_id'=>$request->user_id,'p_id'=>$productId,'comment'=>$request->message);
                DB::table('product_comment')->insert($addcommet);
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.comment add successfully');
                        return response()->json($resultArray); exit;
        }



        public function checkToken($access_token,$user_id='',$session_key='',$lang='')
        {
            $token=123456;
            if($access_token!=$token)
            {
                $resultArray['status']='0';
                $resultArray['message']=__('Invalid token!');
                return $resultArray;
                die;
            }
            else
            {
                if($user_id!='')
                {
                    $user_arr = DB::table('users')->where('id',trim($user_id))->where('active',1)->first();
                    if($session_key=='')
                    {
                    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    $session_key=substr(str_shuffle($chars),0,8);
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->first();
                    
                    if($checkuser)
                    {
                        $update_arr= array('session_key' => $session_key);
                        DB::table('mobile_session')->where('id',$checkuser->id)->update($update_arr);
                        
                    }
                    else
                    {
                        $mobile['user_id'] = $user_id; 
                        $mobile['session_key'] = $session_key;
                        $savemobile = DB::table('mobile_session')->insert($mobile);
                                       
                    }
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray);
                    }
                    else
                    {
                    
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->where('session_key',$session_key)->first();

                    if($checkuser)
                    {
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray); die;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.Invalid session.');
                        return ($resultArray); die;
                    }
                    }
                }
                else
                {
                    $resultArray['status']='1';
                    $resultArray['Data']['message']='';
                    return ($resultArray); die;
                }   
            }
        }
         /*
          * CHECK AUTHENTICATION API END HERE
          */

        public function intToString($data=null,$indent='')
        {
            $userdata= array();
            if ($data) {
                foreach ($data as $key=> $value)
                {
                    if (is_array($value))
                    {
                        $userdata[$key]= $this->intToString($value,$indent);
                    }
                    else
                    {   
                        if(is_numeric($value))
                        {
                            $userdata[$key]=strval($value);
                        }
                        else
                        {
                            $userdata[$key]= $value;
                        }
                    }
                }
            }
                 return $userdata;
                exit;
        }



        function postpushnotification($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
            if(!empty($device_id))
            {
              $fields = array(
                 'to' => $device_id,
                  'data' =>array('title' => $title, 'message' => $message,'urlToken' => $urlToken,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus),
                'notification'=>array('title'=>$title,'body'=>$message,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus)
                );

                $response = $this->sendPushNotification($fields);
                return true;
            }
        }

        function sendPushNotification($fields = array(), $usertype=Null)
        {
             //echo '<pre>';print_r($fields); //exit;
              $API_ACCESS_KEY = 'AAAAfCJQ4L0:APA91bFz__v7ZXMDFUudEzA0y_C04gx1iiPSCeaGStcj_hrOx7oNfKl5lwGFqZxzKAqDjgedJy14GdxF_LRuXUZn7fTTcMztP4wkSxYMsPRltXCov-ldRUtFN5FyWoNB5i5qbSi9La2k';

              $headers = array
              (
                'Authorization: key=' . $API_ACCESS_KEY,
                'Content-Type: application/json'
              );

              $ch = curl_init();
              curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
              curl_setopt( $ch,CURLOPT_POST, true );
              curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
              curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
              // Execute post
              $result = curl_exec($ch);
              //print_r($result);//die;
              sleep(5);
              if ($result === FALSE) {
                  die('Curl failed: ' . curl_error($ch));
              }
              // Close connection
              curl_close($ch);
              return $result;    
        }
        function iospush($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
            $tokenLength = strlen($device_id);
            if (!empty($device_id)) {
                $apnsHost = 'gateway.push.apple.com';
                //$apnsHost = 'gateway.sandbox.push.apple.com';
               //$apnsCert = public_path('buskalock.pem');
                $apnsCert = public_path('pushcertBuskalo.pem');
                $sound = 'default';
                $apnsPort = 2195;
                $apnsPass = '';
                $token = $device_id;
                $payload['aps'] = array('title' => $title, 'alert' => $message, 'badge' => '1', 'sound' => 'default','order_id'=>$orderid,'orderstatus'=>$orderstatus);
                $output = json_encode($payload);
                $token = pack('H*', str_replace(' ', '', $token));
                $apnsMessage = chr(0) . chr(0) . chr(32) . $token . chr(0) . chr(strlen($output)) . $output;
                $streamContext = stream_context_create();
                stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
                stream_context_set_option($streamContext, 'ssl', 'passphrase', $apnsPass);
                $apns = @stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error, $errorString, 2, STREAM_CLIENT_CONNECT, $streamContext);
                //fwrite($apns, $apnsMessage);
                $result = @fwrite($apns, $apnsMessage, strlen($apnsMessage)); //fwrite($apns, $apnsMessage);
                @fclose($apns);
                if (!$result) {
                    $a = 'Message not delivered' . PHP_EOL;
                } else {
                    $a = 'Message successfully delivered' . PHP_EOL;
                }
                $log = "User: " . $_SERVER['REMOTE_ADDR'] . ' - ' . date("F j, Y, g:i a") . PHP_EOL .
                    "Attempt: " . (!empty($result) ? 'Success' : 'Failed') . PHP_EOL .
                    "Pass: " . $result . PHP_EOL .
                    "apns: " . $apns . PHP_EOL .
                    "apnsMessage: " . $apnsMessage . PHP_EOL .
                    "device_id:" .$device_id . PHP_EOL .
                    "Pass: " . $a . PHP_EOL .
                    "-------------------------" . PHP_EOL;
                  //  return $result; 
               // echo "<pre>"; print_r($apns); die;
                return $log;
                //Save string to log, use FILE_APPEND to append.
                //file_put_contents(content_url().'/log/log_'.date("j.n.Y").'.txt', $log, FILE_APPEND);
                //exit;
            }
        }
}   