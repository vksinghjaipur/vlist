<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use DateTime;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\City;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class UserController extends APIController
{

        /*
        * UPDATE PASSWORD API END HERE
        */
        public function userSetting(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;

            App::setLocale($lang);
            $addUpdatesetting=array(
                    'user_id'=>$userid,
                    'currency'=>$request->currency,
                    'language'=>$request->language,
                    'notification'=>$request->notification,
                    'message'=>$request->messages
                    );  
            $checkData=DB::table('user_settings')->where('user_id',$userid)->first();
            if(!empty($checkData))
            {
                DB::table('user_settings')->where('user_id',$userid)->update($addUpdatesetting);
                $message=trans('api.user_setting_update');
            }
            else
            {
                DB::table('user_settings')->insert($addUpdatesetting);
                $message=trans('api.user_setting_add');
            }

                $resultArray['status']=1;
                $resultArray['message']=$message;
                return ($resultArray); die;
        }

    
        // social login end
          /*
          * CHECK AUTHENTICATION API START HERE
          */

   



        public function checkToken($access_token,$user_id='',$session_key='',$lang='')
        {
            $token=123456;
            if($access_token!=$token)
            {
                $resultArray['status']='0';
                $resultArray['message']=__('Invalid token!');
                return $resultArray;
                die;
            }
            else
            {
                if($user_id!='')
                {
                    $user_arr = DB::table('users')->where('id',trim($user_id))->where('active',1)->first();
                    if($session_key=='')
                    {
                    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    $session_key=substr(str_shuffle($chars),0,8);
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->first();
                    
                    if($checkuser)
                    {
                        $update_arr= array('session_key' => $session_key);
                        DB::table('mobile_session')->where('id',$checkuser->id)->update($update_arr);
                        
                    }
                    else
                    {
                        $mobile['user_id'] = $user_id; 
                        $mobile['session_key'] = $session_key;
                        $savemobile = DB::table('mobile_session')->insert($mobile);
                                       
                    }
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray);
                    }
                    else
                    {
                    
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->where('session_key',$session_key)->first();

                    if($checkuser)
                    {
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray); die;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.Invalid session.');
                        return ($resultArray); die;
                    }
                    }
                }
                else
                {
                    $resultArray['status']='1';
                    $resultArray['Data']['message']='';
                    return ($resultArray); die;
                }   
            }
        }
         /*
          * CHECK AUTHENTICATION API END HERE
          */

        public function intToString($data=null,$indent='')
        {
            $userdata= array();
            if ($data) {
                foreach ($data as $key=> $value)
                {
                    if (is_array($value))
                    {
                        $userdata[$key]= $this->intToString($value,$indent);
                    }
                    else
                    {   
                        if(is_numeric($value))
                        {
                            $userdata[$key]=strval($value);
                        }
                        else
                        {
                            $userdata[$key]= $value;
                        }
                    }
                }
            }
                 return $userdata;
                exit;
        }


        public function home(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'latitude'=>'required',
                'longitude'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $latitude = isset($request->latitude) && !empty($request->latitude) ? $request->latitude: '';
                $category= isset($request->category_id)?$request->category_id:'';
                $longitude = isset($request->longitude) && !empty($request->longitude) ? $request->longitude: '';

                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                $radius = 200;

                 $query=DB::table('business_address')
                ->join('business_infos','business_infos.user_id','=','business_address.user_id')
                ->leftjoin('business_images','business_images.user_id','=','business_address.user_id')
                ->join('seller_business_services','seller_business_services.user_id','=','business_address.user_id')
                ->join('users','users.id','=','business_address.user_id')
                ->selectRaw("*,
                            ( 6371 * acos( cos( radians(" . $latitude . ") ) *
                            cos( radians(business_address.business_lat) ) *
                            cos( radians(business_address.business_long) - radians(" . $longitude . ") ) + 
                            sin( radians(" . $latitude . ") ) *
                            sin( radians(business_address.business_lat) ) ) ) 
                            AS distance")
                
                ->having("distance", "<", $radius)
                ->groupBy('seller_business_services.user_id');
               
                if(!empty($category))
                {
                    $query->where('seller_business_services.business_type_id',$category);
                }

                $servicemapDatas=$query->orderBy("distance")
                                ->get();

               //print_r($servicemapDatas);exit;
                $businessCatgory=DB::table('business_types')->where('status',1) ->whereRaw("(deleted_at IS null)")->get();

                $category=array();
                foreach ($businessCatgory as $key => $businessCat)
                {
                    $category[$key]['id']=$businessCat->id;
                    $category[$key]['name']=$businessCat->business_name;
                    $category[$key]['image']= url('img/businessimage/'.$businessCat->business_image);
                    
                }

                //City Favorite
                    $favoriteCity=array();
                    $cities= City::where('status',1)->get();
                    foreach($cities as $ct=>$city)
                    {
                       $favoriteCity[$ct]['id']= $city->id;
                       $favoriteCity[$ct]['name']= $city->cities_name;
                    }
                //End City
               
                $serviceMap1=array();
                $offers=array();
                if(count($servicemapDatas)>0)
                {
                    foreach ($servicemapDatas as $key => $servicemapData)
                    {
                        $checkstaff=DB::table('staff_members')->where('seller_id',$servicemapData->user_id)->first();
                        if(!empty($checkstaff))
                        {
                            $serviceMap['seller_id']=!empty($servicemapData->user_id)? $servicemapData->user_id: '';
                            $serviceMap['name']=!empty($servicemapData->business_name)? $servicemapData->business_name: '';
                            $serviceMap['contact_no']=!empty($servicemapData->mobile_no)? $servicemapData->mobile_no: '';
                            $serviceMap['address']=!empty($servicemapData->business_address)? $servicemapData->business_address: '';
                            $serviceMap['latitude']=!empty($servicemapData->business_lat)? $servicemapData->business_lat: '';
                            $serviceMap['longitude']=!empty($servicemapData->business_long)? $servicemapData->business_long: '';

                            if(file_exists(public_path('img/businessimage/'.$servicemapData->image)))
                            {
                                $serviceMap['image']=url('img/businessimage/'.$servicemapData->image);
                            }
                            array_push($serviceMap1,$serviceMap);
                            $specialoffer=DB::table('seller_business_services')
                                ->where('user_id',$servicemapData->user_id)
                                ->where('special_offer','!=','')
                                ->groupBy('business_type_id')
                                ->first();
                                    if(!empty($specialoffer->special_offer))
                                    {
                                        $serviceoffer['id']=!empty($specialoffer->id)? $specialoffer->id: '';
                                        $serviceoffer['seller_id']=!empty($servicemapData->user_id)? $servicemapData->user_id: '';
                                        $serviceoffer['offer']=!empty($specialoffer->special_offer)? $specialoffer->special_offer: '';
                                        $serviceoffer['name']=!empty($servicemapData->business_name)? $servicemapData->business_name: '';
                                        $serviceoffer['address']=!empty($servicemapData->business_address)? $servicemapData->business_address: '';
                                        if(file_exists(public_path('img/businessimage/'.$servicemapData->image)))
                                        {
                                            $serviceoffer['image']=url('img/businessimage/'.$servicemapData->image);
                                        }
                                        array_push($offers,$serviceoffer);
                                    }
                        }
                   }
                
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.salon_found');
                    $resultArray['data']['saloon_list']=$serviceMap1;
                    $resultArray['data']['category']=$category;
                    $resultArray['data']['offer']=$offers;
                    $resultArray['data']['city']=$favoriteCity;
                    return response()->json($resultArray); exit;
                }
                elseif(count($servicemapDatas)==0 && count($category)>0)
                {
                    $resultArray['status']='1';
                    $resultArray['message']=trans('Category List');
                    $resultArray['data']['category']=$category;
                    $resultArray['data']['city']=$favoriteCity;
                    return response()->json($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_salon_found');
                   return response()->json($resultArray); exit;
                }
        }

        public function sellerInfo(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                { 

                    $sellerinfo=DB::table('users')
                        ->leftjoin('business_infos','business_infos.user_id','=','users.id')
                        ->leftjoin('business_address','business_address.user_id','=','users.id')
                        ->leftjoin('booking_types','booking_types.user_id','=','users.id')
                        ->leftjoin('seller_business_services','seller_business_services.user_id','=','users.id')
                        ->leftjoin('business_images','business_images.user_id','=','users.id')
                        ->where('users.id',$sellerId)->first();
                        $muultiimages=DB::table('business_images')->where('user_id',$sellerId)->get();

                        $multiImage=array();
                        foreach ($muultiimages as $key => $muultiimag)
                        { 
                           if(!empty($muultiimag->image) && file_exists(public_path('img/businessimage/'.$muultiimag->image)))
                           {
                            $multiImage[$key]['multiimage']= url('img/businessimage/'.$muultiimag->image);
                           }
                        }

                        $seller['id']= isset($sellerinfo->user_id)?$sellerinfo->user_id:'';
                        $seller['business_name']= isset($sellerinfo->business_name)?$sellerinfo->business_name:'';
                        $seller['mobile_no']= isset($sellerinfo->mobile_no)?$sellerinfo->mobile_no:'';
                        $seller['address']= isset($sellerinfo->business_address)?$sellerinfo->business_address:'';
                        $seller['about']= isset($sellerinfo->about)?$sellerinfo->about:'';
                        $seller['city']= isset($sellerinfo->city)?$sellerinfo->city:'';
                        $seller['apartment']= isset($sellerinfo->apart_number)?$sellerinfo->apart_number:'';
                        $seller['zip_code']= isset($sellerinfo->zip_code)?$sellerinfo->zip_code:'';
                        $seller['latitude']= isset($sellerinfo->business_lat)?$sellerinfo->business_lat:'';
                        $seller['longitude']= isset($sellerinfo->business_long)?$sellerinfo->business_long:'';
                        if(!empty($sellerinfo->image) && file_exists(public_path('img/businessimage/'.$sellerinfo->image)))
                        {
                             $seller['image']= url('img/businessimage/'.$sellerinfo->image);
                        }

                        $businessHours=DB::table('business_hours')->where('user_id',$sellerId)->get();
                        if(count($businessHours)>0)
                        {
                         
                            $business=array(1=>array('day'=>'Monday', 'hour'=>array()),
                                        2=>array('day'=>'Tuesday', 'hour'=>array()),
                                       3=>array('day'=>'Wednesday', 'hour'=>array()),
                                        4=>array('day'=>'Thursday', 'hour'=>array()),
                                        5=>array('day'=>'Friday', 'hour'=>array()),
                                        6=>array('day'=>'Saturday', 'hour'=>array()),
                                        7=>array('day'=>'Sunday', 'hour'=>array()),
                                 );
                                foreach ($businessHours as $key => $businessHour)
                                {   
                                        
                                    // $business[$key]['day']=$businessHour->day;
                                    // $business[$key]['status']=$businessHour->status;
                                   // $a = array();
                                    if($businessHour->day=='Monday')
                                    {   $business[1]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[1]['hour'][] = $a;
                                        

                                    }
                                    if($businessHour->day=='Tuesday')
                                    {
                                        $business[2]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[2]['hour'][] = $a;
                                    }
                                    if($businessHour->day=='Wednesday')
                                    {
                                         $business[3]['status']=$businessHour->status;
                                         $a['start_time'] = $businessHour->start_time;
                                         $a['end_time'] = $businessHour->end_time;
                                         $business[3]['hour'][] = $a;
                                    }
                                    if($businessHour->day=='Thursday')
                                    {
                                        $business[4]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[4]['hour'][] = $a;
                                    }
                                    if($businessHour->day=='Friday')
                                    {
                                        $business[5]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[5]['hour'][] = $a;
                                    }
                                    if($businessHour->day=='Saturday')
                                    {
                                        $business[6]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[6]['hour'][] = $a;
                                    }
                                    if($businessHour->day=='Sunday')
                                    {
                                        $business[7]['status']=$businessHour->status;
                                        $a['start_time'] = $businessHour->start_time;
                                        $a['end_time'] = $businessHour->end_time;
                                        $business[7]['hour'][] = $a;
                                    }
                                }
                                $hours=array();
                                foreach ($business as $key => $value)
                                {

                                    array_push($hours, $value);
                                } 
                        }
                        else
                        {
                           $hours=[]; 
                        }
                        //Staff list

                        $sellersatff=DB::table('staff_members')->where('user_id',$sellerId)->get();
                         $stafmamber=array();
                        if(count($sellersatff)>0)
                        {
                            foreach ($sellersatff as $key => $satff)
                            {   
                                $stafmamberlist['id']=isset($satff->id)?$satff->id:'';
                                $stafmamberlist['name']=isset($satff->name)?$satff->name:'';
                                $stafmamberlist['position']=isset($satff->position)?$satff->position:'';
                                $stafmamberlist['staff_card_id']=isset($satff->staff_card_id)?$satff->staff_card_id:'';
                                $stafmamberlist['phone']=isset($satff->phone)?$satff->phone:'';
                                $stafmamberlist['experience']=isset($satff->experience)?$satff->experience:'';
                                if(!empty($satff->staff_image))
                                {
                                    $stafmamberlist['image']=url('/img/staffimage/'.$satff->staff_image);
                                }

                                $reviewdatas=DB::table('ratings')
                                        ->leftjoin('users','users.id','=','ratings.user_id')
                                        ->select('ratings.*','users.username')
                                        ->where('staff_id',$satff->id)->get();
                                $reviewArray=array();
                                $ratingcount=0;
                                if(count($reviewdatas)>0)
                                {
                                    foreach ($reviewdatas as $key => $reviews)
                                    {
                                       $ratingcount+=$reviews->rating;
                                    }
                                }
                                $count=count($reviewdatas);

                                $stafmamberlist['average']=0;
                                if($count!=0)
                                {
                                    $stafmamberlist['average']=$ratingcount/$count;
                                }

                                array_push($stafmamber, $stafmamberlist);
                            }
                        }
                        $servicelistdata2=DB::table('seller_business_services')
                                ->select('seller_business_services.type','seller_business_services.business_type_id','seller_business_services.id as serviceid','seller_business_services.person','seller_business_services.price','seller_business_services.service_type_id')
                                ->whereRaw("(seller_business_services.deleted_at IS null)")
                                ->where('seller_business_services.person',1)
                                ->where('seller_business_services.user_id',$sellerId)
                                ->get()->toArray();

                    $servicelistdata1=DB::table('seller_business_services')
                                ->select('seller_business_services.type','seller_business_services.business_type_id','seller_business_services.id as serviceid','seller_business_services.home','seller_business_services.price','seller_business_services.service_type_id')
                                 ->whereRaw("(seller_business_services.deleted_at IS null)")
                                ->where('seller_business_services.home',1)
                                ->where('seller_business_services.user_id',$sellerId)
                                ->get()->toArray();
                               $servicelistdata= array_merge($servicelistdata2,$servicelistdata1);
                              //  echo '<pre>'; print_r($servicelistdata);exit;
                       // $servicelistdata=DB::table('seller_business_services')->where('user_id',$sellerId)->whereRaw("(seller_business_services.deleted_at IS null)")->get();
                         $sellerservice=array();
                        if(count($servicelistdata)>0)
                        {
                            foreach ($servicelistdata as $k => $servicelist)
                            {   
                                $sellerservice[$k]['business_type_id']=isset($servicelist->business_type_id)?$servicelist->business_type_id:'';
                                if(isset($servicelist->person) && !empty($servicelist->person) && ($servicelist->person==1))
                               {
                                    $sellerservice[$k]['type']='person';
                               }
                               if(isset($servicelist->home) && !empty($servicelist->home) && ($servicelist->home==1))
                               {
                                    $sellerservice[$k]['type']='home';
                               }
                               // $service['type']=isset($servicelist->type)?$servicelist->type:'';
                                //$sellerservice[$k]['position']=isset($servicelist->position)?$servicelist->position:'';
                                if(isset($servicelist->person) && !empty($servicelist->person) && ($servicelist->person==1))
                                {
                                    $sellerservice[$k]['service_id']=isset($servicelist->service_type_id)?$servicelist->service_type_id:'';  
                                    $servicename=DB::table('business_services')->where('id',$servicelist->service_type_id)->first();
                                    if(!empty($servicename))
                                    {
                                       $sellerservice[$k]['service_name']=$servicename->service_name;
                                    }
                                }
                                if(isset($servicelist->home) && !empty($servicelist->home) && ($servicelist->home==1))
                                {
                                   $sellerservice[$k]['service_id']=isset($servicelist->service_type_id)?$servicelist->service_type_id:'';
                                    $servicename=DB::table('business_services')->where('id',$servicelist->service_type_id)->first();
                                    if(!empty($servicename))
                                    {
                                       $sellerservice[$k]['service_name']=$servicename->service_name;
                                    } 
                                }
                                
                                 $sellerservice[$k]['price']=isset($servicelist->price)?$servicelist->price:'';
                                 //$sellerservice[$k]['price_type']=isset($servicelist->price_type)?$servicelist->price_type:'';
                                // $sellerservice[$k]['duration']=isset($servicelist->duration)?$servicelist->duration:'';
                                //$sellerservice[$k]['special_offer']=isset($servicelist->special_offer)?$servicelist->special_offer:'';
                                 //$sellerservice[$k]['service_time']=isset($servicelist->service_time)?$servicelist->service_time:'';
                                // if(!empty($servicelist->service_time) && $servicelist->service_time==1)
                                // {
                                //      $sellerservice[$k]['service_multi_time']=isset($servicelist->in_time)?$servicelist->in_time:'';
                                //      $sellerservice[$k]['service_multi_week']=isset($servicelist->in_week)?$servicelist->in_week:'';
                                // }

                               // array_push($sellerservice, $service);
                            }
                        }

                        $ratings=DB::table('ratings')
                                    ->leftjoin('users','users.id','=','ratings.user_id')
                                    ->select('ratings.*','users.username','users.avatar_location')
                                    ->where('seller_id',$sellerId)->get();
                         $ratingdata=array();
                        if(count($ratings)>0)
                        {
                            foreach ($ratings as $k => $rating)
                            {   

                                $ratinginfo['user_name']=isset($rating->username)?$rating->username:'';
                                $ratinginfo['user_image']='';
                                if(!empty($rating->avatar_location) && file_exists(public_path('img/user/profile/'.$rating->avatar_location)))
                                {
                                    $ratinginfo['user_image']=url('img/user/profile/'.$rating->avatar_location);
                                }
                                $ratinginfo['commnet']=isset($rating->comment)?$rating->comment:'';
                                $ratinginfo['date_time']=isset($rating->created_at)?$rating->created_at:'';
                                $ratinginfo['rating']=isset($rating->rating)?$rating->rating:'';
                                array_push($ratingdata, $ratinginfo);
                            }
                        }

                        //favoritedata
                            $checkfavorite=DB::table('favorites')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."')")->first();
                            if(!empty($checkfavorite))
                            {
                                $isfavorite=true; 
                            }else
                            {
                                $isfavorite=false;
                            }
                        $seller['is_favorite']= $isfavorite;


                        $getlookbooks=DB::table('look_books')->where('user_id',$request->seller_id)->get();
                        $lookbooksArray=array();
                        foreach($getlookbooks as $l=>$lookbook)
                        {
                            $lookbooksArray[$l]['look_book_id']=$lookbook->id;  
                            $lookbooksArray[$l]['seller_id']=$lookbook->user_id;  
                            $lookbooksArray[$l]['image']=url('img/lookbook/'.$lookbook->look_book_image);  
                        }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.salon_found');
                        $resultArray['data']=$seller;
                        $resultArray['data']['hours']=$hours;
                        $resultArray['data']['staff']=$stafmamber;
                        $resultArray['data']['services']=$sellerservice;
                        $resultArray['data']['review']=$ratingdata;
                        $resultArray['data']['images']=$multiImage;
                        $resultArray['data']['lookbook']=$lookbooksArray;
                        return response()->json($resultArray); exit;
                }
        }

        public function serviceCategory(Request $request)
        {

            $category= isset($request->category_id)?$request->category_id:'';
            $latitude= isset($request->latitude)?$request->latitude:'';
            $longitude= isset($request->longitude)?$request->longitude:'';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                $radius = 200;

                $query = DB::table('business_address')
                ->join('business_infos','business_infos.user_id','=','business_address.user_id')
                ->join('business_images','business_images.user_id','=','business_address.user_id')
                ->join('users','users.id','=','business_address.user_id')
                ->join('seller_business_services','seller_business_services.user_id','=','business_address.user_id')
                ->selectRaw("*,
                            ( 6371 * acos( cos( radians(" . $latitude . ") ) *
                            cos( radians(business_address.business_lat) ) *
                            cos( radians(business_address.business_long) - radians(" . $longitude . ") ) + 
                            sin( radians(" . $latitude . ") ) *
                            sin( radians(business_address.business_lat) ) ) ) 
                            AS distance")
                
                ->having("distance", "<", $radius);
                if(!empty($category))
                {
                    $query->where('seller_business_services.business_type_id',$category);
                }

                $servicemapDatas=$query->orderBy("distance")
                                ->get();

                $serviceMap=array();
                $offers=array();
                if(count($servicemapDatas)>0)
                {
                    foreach ($servicemapDatas as $key => $servicemapData)
                    {
                        $serviceMap[$key]['seller_id']=!empty($servicemapData->user_id)? $servicemapData->user_id: '';
                        $serviceMap[$key]['name']=!empty($servicemapData->business_name)? $servicemapData->business_name: '';
                        $serviceMap[$key]['contact_no']=!empty($servicemapData->mobile_no)? $servicemapData->mobile_no: '';
                        $serviceMap[$key]['address']=!empty($servicemapData->business_address)? $servicemapData->business_address: '';
                        if(file_exists(public_path('img/businessimage/'.$servicemapData->image)))
                        {
                            $serviceMap[$key]['image']=url('img/businessimage/'.$servicemapData->image);
                        }
                       
                        $specialoffer=DB::table('seller_business_services')->where('user_id',$servicemapData->user_id)->where('special_offer','!=','')->first();
                        // if(count($specialoffer)>0)
                        // {   
                        //     foreach ($specialoffer as $k => $offer)
                        //     {
                                if(!empty($specialoffer->special_offer))
                                {
                                    $serviceoffer['id']=!empty($specialoffer->id)? $specialoffer->id: '';
                                    $serviceoffer['seller_id']=!empty($servicemapData->user_id)? $servicemapData->user_id: '';
                                    $serviceoffer['offer']=!empty($specialoffer->special_offer)? $specialoffer->special_offer: '';
                                    $serviceoffer['name']=!empty($servicemapData->business_name)? $servicemapData->business_name: '';
                                    $serviceoffer['address']=!empty($servicemapData->business_address)? $servicemapData->business_address: '';
                                    if(file_exists(public_path('img/businessimage/'.$servicemapData->image)))
                                    {
                                        $serviceoffer['image']=url('img/businessimage/'.$servicemapData->image);
                                    }
                                    array_push($offers,$serviceoffer);
                                }
                        //     }
                        // }
                   }
                
                    //echo '<pre>';print_r($serviceoffer);exit;
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.salon_found');
                    $resultArray['data']['saloon_list']=$serviceMap;
                    $resultArray['data']['offer']=$offers;
                    return response()->json($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_salon_found');
                    return response()->json($resultArray); exit;
                }
        }



        //User Booking

        public function serviceBookingList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                { 
                    $servicelistdata2=DB::table('seller_business_services')
                                ->leftjoin('business_types','business_types.id','=','seller_business_services.business_type_id')
                                ->select('business_types.id as bid','business_types.business_name','seller_business_services.type','seller_business_services.business_type_id','seller_business_services.id as serviceid','seller_business_services.person')
                                ->selectRaw("count(case when person = '1' then 1 end) as countservice")
                                ->whereRaw("(seller_business_services.deleted_at IS null)")
                                ->where('business_types.status',1)
                                ->where('seller_business_services.person',1)
                               // ->where('seller_business_services.home',1)
                                ->where('seller_business_services.user_id',$sellerId)
                                ->groupBy('business_type_id')
                                ->get()->toArray();

                    $servicelistdata1=DB::table('seller_business_services')
                                ->leftjoin('business_types','business_types.id','=','seller_business_services.business_type_id')
                                ->select('business_types.id as bid','business_types.business_name','seller_business_services.type','seller_business_services.business_type_id','seller_business_services.id as serviceid','seller_business_services.home')
                                ->selectRaw("count(case when home = '1' then 1 end) as countservice")
                                 ->whereRaw("(seller_business_services.deleted_at IS null)")
                                ->where('business_types.status',1)
                                ->where('seller_business_services.home',1)
                                ->where('seller_business_services.user_id',$sellerId)
                                ->groupBy('business_type_id')
                                ->get()->toArray();
                               $servicelistdata= array_merge($servicelistdata2,$servicelistdata1);
                               //echo '<pre>'; print_r($servicelistdata);exit;
                     $service=array();
                    if(count($servicelistdata)>0)
                    {
                        foreach ($servicelistdata as $k => $servicelist)
                        {   
                          
                           
                            $service[$k]['service_id']=isset($servicelist->serviceid)?$servicelist->serviceid:'';
                            $service[$k]['caregory_id']=isset($servicelist->bid)?$servicelist->bid:'';
                           if(isset($servicelist->person) && !empty($servicelist->person) && ($servicelist->person==1))
                           {
                                $service[$k]['type']='person';
                           }
                           if(isset($servicelist->home) && !empty($servicelist->home) && ($servicelist->home==1))
                           {
                                $service[$k]['type']='home';
                           }
                           
                            $service[$k]['category_name']=isset($servicelist->business_name)?$servicelist->business_name:'';
                            $service[$k]['count']=isset($servicelist->countservice)?$servicelist->countservice:'';
                        }
                    }
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.service_booking_list');
                        $resultArray['data']=$service;
                        return response()->json($resultArray); exit;
                }
        }

        public function categoryServices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'category_id'=>'required',
                'service_type'=>'required',
                'session_key'=>'required',
            ]);
            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                { 
                    $query=DB::table('seller_business_services');
                            if($request->service_type=='person')
                            {
                                $query->leftjoin('business_services','business_services.id','=','seller_business_services.service_type_id')
                                 ->where('seller_business_services.person',1);
                            }

                            if($request->service_type=='home')
                            {
                                $query->leftjoin('business_services','business_services.id','=','seller_business_services.service_type_id')
                                 ->where('seller_business_services.home',1);
                            }

                           $servicecategories= $query->select('seller_business_services.type','seller_business_services.id as serviccatid','business_services.service_name','seller_business_services.special_offer','seller_business_services.price','business_services.id as serviceId','seller_business_services.service_type_id','seller_business_services.service_image','seller_business_services.person','seller_business_services.home')
                            ->where('seller_business_services.user_id',$sellerId)
                            ->where('seller_business_services.price','!=', null)
                            ->whereRaw("(seller_business_services.deleted_at IS null)")
                           
                            ->where('seller_business_services.business_type_id',$request->category_id)
                            ->get();
                             //print_r($servicecategories);exit;
                     $serviceData=array();
                    if(count($servicecategories)>0)
                    {
                        foreach ($servicecategories as $k => $servicecat)
                        {   
                           $checkservice=DB::table('carts')->where('user_id',$userId)->where('service_id',$servicecat->serviceId)->where('status','Pending')->where('seller_id',$sellerId)->first();
                            $serviceData[$k]['business_service_id']=isset($servicecat->serviccatid)?$servicecat->serviccatid:'';
                            $serviceData[$k]['caregory_id']=isset($request->category_id)?$request->category_id:'';
                            $serviceData[$k]['service_cat_id']=isset($servicecat->service_type_id)?$servicecat->service_type_id:'';
                            $serviceData[$k]['person']=isset($servicecat->person)?$servicecat->person:0;
                            $serviceData[$k]['home']=isset($servicecat->home)?$servicecat->home:0;
                            $serviceData[$k]['type']=isset($request->service_type)?$request->service_type:'';
                            $serviceData[$k]['service_name']=isset($servicecat->service_name)?$servicecat->service_name:'';
                            $serviceData[$k]['offer']=isset($servicecat->special_offer)?$servicecat->special_offer:'';
                            $serviceData[$k]['price']=isset($servicecat->price)?$servicecat->price:'';
                            $serviceData[$k]['sale_price']='';
                            if(!empty($servicecat->special_offer))
                            {
                                $offer=($servicecat->price*$servicecat->special_offer)/100;
                                $total=$servicecat->price-$offer;
                                $serviceData[$k]['sale_price']=number_format($total,2);
                            }
                            $serviceData[$k]['service_image']='';
                            if(!empty($servicecat->service_image))
                            {

                                $serviceData[$k]['service_image']=url('img/serviceimage/'.$servicecat->service_image);
                            }
                            $serviceData[$k]['is_checked']=false;
                            if(!empty($checkservice) && $checkservice->service_type==$request->service_type)
                            {
                                $serviceData[$k]['is_checked']=true;
                            }
                        }
                    }
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.business_service_category_list');
                        $resultArray['data']=$serviceData;
                        return response()->json($resultArray); exit;
                }
        }

        public function addCart(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'category_id'=>'required',
                'service_type'=>'required',
                'session_key'=>'required',
                'service_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $serviceId = isset($request->service_id) && !empty($request->service_id) ? $request->service_id: '';
                $catId = isset($request->category_id) && !empty($request->category_id) ? $request->category_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $checkall=DB::table('carts')->where('user_id',$userId)->where('seller_id','!=',$sellerId)->where('status','Pending')->first();
                    if(!empty($checkall))
                    {
                        $resultArray['status']='1';
                        $resultArray['message']=trans('Please other seller service delete after new service');
                        $resultArray['seller_id']=$checkall->seller_id;
                        return response()->json($resultArray); exit;
                    }
                   
                   // echo '<pre>';print_r(json_decode($serviceId));exit;
                    $serviceids=json_decode($serviceId);
                    foreach ($serviceids  as $key => $value)
                    {
                        $checkservice=DB::table('carts')->where('user_id',$userId)->where('service_id',$value->service_id)->where('status','Pending')->first();
                        $checkservicetype=DB::table('carts')->where('user_id',$userId)->where('status','Pending')->first();

                        if(empty($checkservice))
                        {
                            if(!empty($checkservicetype))
                            {

                                if($request->service_type==$checkservicetype->service_type)
                                {
                                    DB::table('carts')->insert(['user_id'=>$userId,'seller_id'=>$sellerId,'cat_id'=>$catId,'service_id'=>$value->service_id,'service_type'=>$request->service_type,'service_price'=>'']);
                                }else
                                {
                                    $resultArray['status']='1';
                                    $resultArray['message']=trans('Category service type different please add same service type.');
                                    $resultArray['seller_id']=$sellerId;
                                    return response()->json($resultArray); exit;
                                }
                            }
                            else
                            {
                                DB::table('carts')->insert(['user_id'=>$userId,'seller_id'=>$sellerId,'cat_id'=>$catId,'service_id'=>$value->service_id,'service_type'=>$request->service_type,'service_price'=>'']);
                            }
                        }
                        else
                        {
                            if(!empty($checkservicetype))
                            {

                                if($request->service_type==$checkservicetype->service_type)
                                {
                                    $checkservice=DB::table('carts')->where('user_id',$userId)->where('service_id',$value->service_id)->where('status','Pending')->first();
                                    if(empty($checkservice))
                                    {
                                         DB::table('carts')->insert(['user_id'=>$userId,'seller_id'=>$sellerId,'cat_id'=>$catId,'service_id'=>$value->service_id,'service_type'=>$request->service_type,'service_price'=>$value->price]);
                                    }
                                   
                                }else
                                {
                                    $resultArray['status']=1;
                                    $resultArray['message']=trans('api.Category service type different please add same service type.');
                                    $resultArray['seller_id']=$sellerId;
                                    return response()->json($resultArray); exit;
                                }
                            }

                        }
                    }
                    $getservice=DB::table('carts')
                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->get();
                         //echo '<pre>';print_r($getservice);exit;
                    $serviceData=array();
                    foreach ($getservice as $key => $services)
                    {
                        if($services->service_type=='person')
                        {
                            $checkservice=DB::table('seller_business_services')->where('person',1)->where('deleted_at', '=', Null)->where('service_type_id',$services->service_id)->first();
                        }
                        if($services->service_type=='home')
                        {
                            $checkservice=DB::table('seller_business_services')->where('home',1)->where('deleted_at', '=', Null)->where('service_type_id',$services->service_id)->first();
                        }
                       
                        $serviceData[$key]['item_id']=$services->id;
                        $serviceData[$key]['service_name']=$services->service_name;
                        $serviceData[$key]['service_price']=isset($checkservice->service_price)?$checkservice->service_price:'';
                        $serviceData[$key]['offer']=isset($checkservice->special_offer)?$checkservice->special_offer:'';
                    }

                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Cart list data');
                        $resultArray['data']=$serviceData;
                        return response()->json($resultArray); exit;
                }
        }

        public function itemList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $getservice=DB::table('carts')
                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                        ->select('carts.*','business_services.service_name')
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->get();
                         //echo '<pre>';print_r($getservice);exit;
                    $serviceData=array();
                    foreach ($getservice as $key => $services)
                    {
                        if($services->service_type=='person')
                        {
                            $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$services->service_id)->where('deleted_at', '=', Null)->where('user_id', $services->seller_id)->first();
                        }
                        if($services->service_type=='home')
                        {
                            $checkservice=DB::table('seller_business_services')->where('home',1)->where('service_type_id',$services->service_id)->where('deleted_at', '=', Null)->where('user_id', $services->seller_id)->first();
                        }
                       
                        $serviceData[$key]['item_id']=$services->id;
                        $serviceData[$key]['service_name']=$services->service_name;
                        $serviceData[$key]['service_price']=isset($checkservice->price)?$checkservice->price:'';
                        $serviceData[$key]['offer']=isset($checkservice->special_offer)?$checkservice->special_offer:'';
                        $serviceData[$key]['sale_price']='';
                            if(!empty($checkservice->special_offer))
                            {
                                $offer=($checkservice->price*$checkservice->special_offer)/100;
                                $total=$checkservice->price-$offer;
                                $serviceData[$key]['sale_price']=number_format($total,2);
                            }
                    }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Cart item list data');
                        $resultArray['data']=$serviceData;
                        return response()->json($resultArray); exit;
                }
        }
        public function itemDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'item_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    DB::table('carts')
                        ->where('id',$request->item_id)
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->delete();
                        
                    DB::table('checkouts')
                        ->where('seller_id',$request->seller_id)
                        ->whereRaw("(checkouts.user_id='".$userId."' AND checkouts.status='Pending')")->delete();

                    $getservice=DB::table('carts')
                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                        ->select('carts.*','business_services.service_name')
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->get();
                         //echo '<pre>';print_r($getservice);exit;
                    $serviceData=array();
                    foreach ($getservice as $key => $services)
                    {
                        if($services->service_type=='person')
                        {
                            $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$services->service_id)->where('deleted_at', '=', Null)->first();
                        }
                        if($services->service_type=='home')
                        {
                            $checkservice=DB::table('seller_business_services')->where('home',1)->where('deleted_at', '=', Null)->where('service_type_id',$services->service_id)->first();
                        }
                       
                        $serviceData[$key]['item_id']=$services->id;
                        $serviceData[$key]['service_name']=$services->service_name;
                        $serviceData[$key]['service_price']=isset($checkservice->price)?$checkservice->price:'';
                        $serviceData[$key]['offer']=isset($checkservice->special_offer)?$checkservice->special_offer:'';
                        $serviceData[$key]['sale_price']='';
                            if(!empty($checkservice->special_offer))
                            {
                                $offer=($checkservice->price*$checkservice->special_offer)/100;
                                $total=$checkservice->price-$offer;
                                $serviceData[$key]['sale_price']=number_format($total,2);
                            }
                    }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Cart item list data');
                        $resultArray['data']=$serviceData;
                        return response()->json($resultArray); exit;
                }
        }

        public function otherSellerItemDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    DB::table('carts')
                        ->where('seller_id',$request->seller_id)
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->delete();

                    $getservice=DB::table('carts')
                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->get();
                         //echo '<pre>';print_r($getservice);exit;
                    $serviceData=array();
                    foreach ($getservice as $key => $services)
                    {
                        if($services->service_type=='person')
                        {
                            $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$services->service_id)->where('deleted_at', '=', Null)->first();
                        }
                        if($services->service_type=='home')
                        {
                            $checkservice=DB::table('seller_business_services')->where('home',1)->where('service_type_id',$services->service_id)->where('deleted_at', '=', Null)->first();
                        }
                       
                        $serviceData[$key]['item_id']=$services->id;
                        $serviceData[$key]['service_name']=$services->service_name;
                        $serviceData[$key]['service_price']=isset($checkservice->price)?$checkservice->price:'';
                        $serviceData[$key]['offer']=isset($checkservice->special_offer)?$checkservice->special_offer:'';
                        $serviceData[$key]['sale_price']='';
                            if(!empty($checkservice->special_offer))
                            {
                                $offer=($checkservice->price*$checkservice->special_offer)/100;
                                $total=$checkservice->price-$offer;
                                $serviceData[$key]['sale_price']=number_format($total,2);
                            }
                    }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Cart item list data');
                        $resultArray['data']=$serviceData;
                        return response()->json($resultArray); exit;
                }
        }

        public function serviceBookingTime(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $days = isset($request->day) && !empty($request->day) ? $request->day: '';
                $bookingTime = isset($request->time) && !empty($request->time) ? $request->time: '';
                $selectdate = isset($request->select_date) && !empty($request->select_date) ? $request->select_date: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $date = date('Y-m-d',strtotime('-1 day')); //today date
                    $weekOfdays = array();
                    for($i =1; $i <= 15; $i++)
                    {
                        $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
                        $weekOfdays[] = date('l : Y-m-d', strtotime($date));
                    }
                        $calendar=array();
                        foreach ($weekOfdays as $key => $value)
                        {
                            $datetime= explode(":", $value);
                            $calendar[$key]['day']=$datetime[0];
                            $calendar[$key]['date']=$datetime[1];
                         }

                        if(isset($days) && !empty($days))
                        {
                            $sellertime=DB::table('business_hours')->where('user_id',$sellerId)->where('day',$days)->where('status',1)->get();
                            if(empty($sellertime))
                            {
                                    $resultArray['status']='0';
                                    $resultArray['message']=trans('Business hours not found.');
                                    return response()->json($resultArray); exit;
                            }
                        }
                        else
                        {
                            $sellertime=DB::table('business_hours')->where('user_id',$sellerId)->where('day',date('l'))->where('status',1)->get();
                            if(empty($sellertime))
                            {
                                    $resultArray['status']='0';
                                    $resultArray['message']=trans('Business hours not found.');
                                    return response()->json($resultArray); exit;
                            }
                        }

                        $duration="59";

                        $timeslot=array();
                        if(count($sellertime)>0)
                        {
                            foreach ($sellertime as $s => $value)
                            {
                                if(!empty($value->start_time) && !empty($value->end_time))
                                {
                                    $start=$value->start_time;
                                    $end=$value->end_time;

                                    $start = new DateTime($start);
                                    $end = new DateTime($end);
                                    $start_time = $start->format('H:i');
                                    $end_time = $end->format('H:i');
                                    $i=0;
                                  
                                    while(strtotime($start_time) <= strtotime($end_time)){
                                        $start = $start_time;
                                        $end = date('H:i',strtotime('+'.$duration.' minutes',strtotime($start_time)));
                                        $start_time = date('H:i',strtotime('+'.$duration.' minutes',strtotime($start_time)));
                                        $i++;
                                        if(strtotime($start_time) <= strtotime($end_time)){
                                            $time[$i]['start'] = $start;
                                            $time[$i]['end'] = $end;
                                            
                                        }
                                    }
                                     array_push($timeslot, $time);
                                }
                            }
                        }

                        $slotTime1=array();
                            foreach ($timeslot as $s => $k)
                            {   
                                if(count($k)>0)
                                {
                                    foreach ($k as $key => $value)
                                    {
                                      $slotTime['start']=$value['start'];
                                        $slotTime['end']=$value['end'];
                                        array_push($slotTime1, $slotTime);
                                    }
                                }
                            }
                        $starttime='';
                        $endtime='';
                        if(!empty($bookingTime))
                        {
                            $btime=explode('-', $bookingTime);
                            $starttime=$btime[0];
                            $endtime=$btime[1];
                        }
                       
                        $checktime= DB::table('orders')->where('service_date',$selectdate)->where('start_time', $starttime)->where('end_time',$endtime)->where('order_status','Pending')->where('seller_id',$sellerId)->first();
                        if(!empty($checktime))
                        {
                            $staffsId=$checktime->staff_id;
                            $staffmember=DB::table('staff_members')->where('user_id',$sellerId)->where('id','!=',$staffsId)->get();
                        }
                        else
                        {
                            $staffmember=DB::table('staff_members')->where('user_id',$sellerId)->get();
                        }

                        $staffData=array();
                        if(count($staffmember)>0)
                        {
                            foreach ($staffmember as $key => $staffs)
                            {
                                $staffData[$key]['staff_id']=$staffs->id;
                                if(!empty($staffs->staff_image))
                                {
                                   $staffData[$key]['staff_image']=url('/img/staffimage/'.$staffs->staff_image); 
                                }
                                $staffData[$key]['name']=isset($staffs->name)?$staffs->name:'';
                                $staffData[$key]['phone_no']=isset($staffs->phone)?$staffs->phone:'';
                                $staffData[$key]['staff_card_id']=isset($staffs->staff_card_id)?$staffs->staff_card_id:'';
                            }
                        }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Time slot data found');
                        $resultArray['calendar']=$calendar;
                        $resultArray['time_slot']=$slotTime1;
                        $resultArray['staff']=$staffData;
                        return response()->json($resultArray); exit;
                }
        } 

        public function serviceBookingTimeChange(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
                'order_id'=>'required',
                'service_date'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $days = isset($request->day) && !empty($request->day) ? $request->day: '';
                $selectdate = isset($request->select_date) && !empty($request->select_date) ? $request->select_date: '';
                $bookingTime = isset($request->time) && !empty($request->time) ? $request->time: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                   $date =date('Y-m-d', strtotime('-1 day', strtotime( $request->service_date)));//today date
                    $weekOfdays = array();
                    for($i =1; $i <= 15; $i++)
                    {
                        $date = date('Y-m-d', strtotime('+1 day', strtotime($date)));
                        $weekOfdays[] = date('l : Y-m-d', strtotime($date));
                    }
                        $calendar=array();
                        foreach ($weekOfdays as $key => $value)
                        {
                            $datetime= explode(":", $value);
                            $calendar[$key]['day']=$datetime[0];
                            $calendar[$key]['date']=$datetime[1];
                         }

                        if(isset($days) && !empty($days))
                        {
                            $sellertime=DB::table('business_hours')->where('user_id',$sellerId)->where('day',$days)->get();
                        }
                        else
                        {
                            $sellertime=DB::table('business_hours')->where('user_id',$sellerId)->where('day',date('l'))->get();
                        }

                        $duration="59";

                        $timeslot=array();
                        if(count($sellertime)>0)
                        {
                            foreach ($sellertime as $s => $value)
                            {
                                if(!empty($value->start_time) && !empty($value->end_time))
                                {
                                    $start=$value->start_time;
                                    $end=$value->end_time;

                                    $start = new DateTime($start);
                                    $end = new DateTime($end);
                                    $start_time = $start->format('H:i');
                                    $end_time = $end->format('H:i');
                                    $i=0;
                                  
                                    while(strtotime($start_time) <= strtotime($end_time)){
                                        $start = $start_time;
                                        $end = date('H:i',strtotime('+'.$duration.' minutes',strtotime($start_time)));
                                        $start_time = date('H:i',strtotime('+'.$duration.' minutes',strtotime($start_time)));
                                        $i++;
                                        if(strtotime($start_time) <= strtotime($end_time)){
                                            $time[$i]['start'] = $start;
                                            $time[$i]['end'] = $end;
                                            
                                        }
                                    }
                                     array_push($timeslot, $time);
                                }
                            }
                        }

                        $slotTime1=array();
                        foreach ($timeslot as $s => $k)
                        {   
                            if(count($k)>0)
                            {
                                foreach ($k as $key => $value)
                                {
                                  $slotTime['start']=$value['start'];
                                    $slotTime['end']=$value['end'];
                                    array_push($slotTime1, $slotTime);
                                }
                            }
                        }
                        $starttime='';
                        $endtime='';
                        if(!empty($bookingTime))
                        {
                            $btime=explode('-', $bookingTime);
                            $starttime=$btime[0];
                            $endtime=$btime[1];
                        }
                     
                       //$checkstaff= DB::table('orders')->where('order_id',$request->order_id)->where('service_date',$request->service_date)->first();
                        $checktime= DB::table('orders')->where('service_date',$request->select_date)->where('start_time', $starttime)->where('end_time',$endtime)->where('order_status','Pending')->where('seller_id',$sellerId)->first();
                        //print_r($checktime);exit;
                        if(!empty($checktime))
                        {
                            if($checktime->user_id==$userId)
                            {
                                $staffmember=DB::table('staff_members')->where('user_id',$sellerId)->get();
                            }
                            else
                            {
                                $staffsId=$checktime->staff_id;
                                $staffmember=DB::table('staff_members')->where('user_id',$sellerId)->where('id','!=',$staffsId)->get();
                            }
                            
                        }
                        else
                        {
                            $staffmember=DB::table('staff_members')->where('user_id',$sellerId)->get();
                        }
                        
                       
                        $staffData=array();
                        if(count($staffmember)>0)
                        {
                            foreach ($staffmember as $key => $staffs)
                            {
                                $staffData[$key]['staff_id']=$staffs->id;
                                if(!empty($staffs->staff_image))
                                {
                                   $staffData[$key]['staff_image']=url('/img/staffimage/'.$staffs->staff_image); 
                                }
                                $staffData[$key]['name']=isset($staffs->name)?$staffs->name:'';
                                $staffData[$key]['phone_no']=isset($staffs->phone)?$staffs->phone:'';
                                $staffData[$key]['staff_card_id']=isset($staffs->staff_card_id)?$staffs->staff_card_id:'';
                            }
                        }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Time slot data found');
                        $resultArray['calendar']=$calendar;
                        $resultArray['time_slot']=$slotTime1;
                        $resultArray['staff']=$staffData;
                        return response()->json($resultArray); exit;
                }
        }
        public function timeSlotBookingUpdate(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
                'date'=>'required',
                'start_time'=>'required',
                'end_time'=>'required',
                'staff_id'=>'required',
                'order_id'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $chekorderData=DB::table('checkouts')
                            ->leftjoin('orders','orders.order_id','=','checkouts.order_id')
                            ->whereRaw("(checkouts.user_id='".$userId."' AND checkouts.seller_id='".$sellerId."' AND checkouts.order_id='".$request->order_id."')")
                            ->select('checkouts.*','orders.payment_type')
                            ->first();
                        if(!empty($chekorderData))
                        {
                            DB::table('checkouts')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND order_id='".$request->order_id."')")
                                ->update(
                                            [
                                                'date'=>$request->date,
                                                'start_time'=>$request->start_time,
                                                'end_time'=>$request->end_time,
                                                'staff_id'=>$request->staff_id
                                            ]
                                        );

                                //Order update
                                DB::table('orders')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND order_id='".$request->order_id."')")
                                ->update(
                                            [
                                                'service_date'=>$request->date,
                                                'start_time'=>$request->start_time,
                                                'end_time'=>$request->end_time,
                                                'staff_id'=>$request->staff_id
                                            ]
                                        );
                                
                                $checkout=DB::table('checkouts')
                                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND order_id='".$request->order_id."')")->first();
                                    $storeInfo=DB::table('business_infos')
                                                    ->leftjoin('business_address','business_address.user_id','=','business_infos.user_id')
                                                    ->select('business_infos.business_name','business_address.business_address','business_address.city','business_address.zip_code')
                                                    ->where('business_infos.user_id',$sellerId)
                                                    ->first();

                                    $checkoutArray['store_name']=isset($storeInfo->business_name)?$storeInfo->business_name:'';
                                    $checkoutArray['store_address']=isset($storeInfo->business_address)?$storeInfo->business_address:'';
                                    $checkoutArray['store_city']=isset($storeInfo->city)?$storeInfo->city:'';
                                    $checkoutArray['store_zipcode']=isset($storeInfo->zip_code)?$storeInfo->zip_code:'';
                                    if(!empty($checkout))
                                    {
                                        $checkoutArray['day']=date('l', strtotime($checkout->date));
                                        $checkoutArray['date']=$checkout->date;
                                        $checkoutArray['start_time']=$checkout->start_time;
                                        $checkoutArray['end_time']=$checkout->end_time;
                                    }
                                    else
                                    {
                                        $resultArray['status']='0';
                                        $resultArray['message']=trans('api.data_not_found');
                                        return response()->json($resultArray); exit;
                                    }

                                    
                                    $cartdatas=DB::table('carts')
                                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                                        ->whereRaw("(carts.user_id='".$userId."' AND carts.order_id='".$request->order_id."')")->get();
                                    if(count($cartdatas)>0)
                                    {
                                        $servicename=array();
                                        $price=0;
                                        $servicenames=array();
                                        foreach ($cartdatas as $k => $cartdata)
                                        {
                                            $checkoutArray['service_type']=$cartdata->service_type;
                                            if($cartdata->service_type=='person')
                                            {
                                                $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                                            }
                                            if($cartdata->service_type=='home')
                                            {
                                                $checkservice=DB::table('seller_business_services')->where('home',1)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                                            }
                                            $price+= isset($checkservice->price)?$checkservice->price:0;
                                            $service['service_name']=$cartdata->service_name;
                                            array_push($servicename, $service);
                                        }
                                    }
                                $checkoutArray['price']=$price;
                                $checkoutArray['payment_type']=isset($chekorderData->payment_type)?$chekorderData->payment_type:'';

                                 $staffdata=DB::table('staff_members')->where('id',$chekorderData->staff_id)->first();
                                if(!empty($staffdata))
                                {
                                    $checkoutArray['staff_id']=!empty($staffdata->id) ? $staffdata->id: '';
                                    $checkoutArray['staff_name']=!empty($staffdata->name) ? $staffdata->name: '';
                                    $checkoutArray['staff_phone']=!empty($staffdata->staff_phone) ? $staffdata->staff_phone: '';
                                    $checkoutArray['staff_bio']=!empty($staffdata->bio) ? $staffdata->bio: '';
                                    $checkoutArray['staff_experience']=!empty($staffdata->experience) ? $staffdata->experience: '';
                                    $checkoutArray['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                                }

                                $resultArray['status']=1;
                                $resultArray['message']=trans('api.Order update successfully');
                                $resultArray['data']=$checkoutArray;
                                $resultArray['service_name']=$servicename;
                                return response()->json($resultArray); exit;
                        }
                        else
                        {
                            $resultArray['status']='0';
                            $resultArray['message']=trans('api.Order data not found');
                            return response()->json($resultArray); exit;
                        }
                }
        }  

        public function sellerStaffInfo(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'staff_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $staffId = isset($request->staff_id) && !empty($request->staff_id) ? $request->staff_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $staffinfos=DB::table('staff_members')->where('user_id',$sellerId)->where('id',$staffId)->first();
                        $dataStaff['name']=isset($staffinfos->name)?$staffinfos->name:'';
                        $dataStaff['position']=isset($staffinfos->position)?$staffinfos->position:'';
                        $dataStaff['staff_card_id']=isset($staffinfos->staff_card_id)?$staffinfos->staff_card_id:'';
                        $dataStaff['phone']=isset($staffinfos->phone)?$staffinfos->phone:'';
                        $dataStaff['experience']=isset($staffinfos->experience)?$staffinfos->experience:'';
                        if(!empty($staffinfos->staff_image))
                        {
                            $dataStaff['image']=url('/img/staffimage/'.$staffinfos->staff_image);
                        }

                        $dataStaff['totalbooking']=0;

                        $reviewdatas=DB::table('ratings')
                                ->leftjoin('users','users.id','=','ratings.user_id')
                                ->select('ratings.*','users.username')
                                ->where('staff_id',$staffId)->get();
                        $reviewArray=array();
                        $ratingcount=0;
                        foreach ($reviewdatas as $key => $reviews)
                        {
                           $reviewArray[$key]['rating']= $reviews->rating;
                           $reviewArray[$key]['comment']= isset($reviews->comment)?$reviews->comment:'no comment';
                           $reviewArray[$key]['name']= isset($reviews->username)?$reviews->username:'';
                           $ratingcount+=$reviews->rating;
                        }
                        $count=count($reviewdatas);
                        $reviewData['total']=$ratingcount;
                        $reviewData['average']=0;
                        if($count!=0)
                        {
                            $reviewData['average']=$ratingcount/$count;
                        }
                        
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Staff information data');
                        $resultArray['about']=$dataStaff;
                        $resultArray['review']=$reviewArray;
                        $resultArray['reviewtotal']=$reviewData;
                        $resultArray['bio']=isset($staffinfos->bio)?$staffinfos->bio:'';
                        return response()->json($resultArray); exit;
                }
        }

        public function favorite(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $checkfavorite=DB::table('favorites')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."')")->first();
                    if(empty($checkfavorite))
                    {
                        DB::table('favorites')->insert([
                                                'user_id'=>$userId,
                                                'seller_id'=>$sellerId
                                                ]);
                        $message='Favorite';
                        $isfavorite=true; 
                    }else
                    {
                        DB::table('favorites')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."')")->delete();
                        $isfavorite=false;
                        $message='Unfavorite';
                    }

                        $resultArray['status']='1';
                        $resultArray['message']=$message;
                        $resultArray['is_favorite']=$isfavorite;
                        return response()->json($resultArray); exit;
                }
        }

        public function favoriteList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $favoriteLists=DB::table('favorites')
                                ->leftjoin('business_infos','business_infos.user_id','=','favorites.seller_id')
                                ->leftjoin('business_address','business_address.user_id','=','favorites.seller_id')
                                ->where('favorites.user_id',$userId)
                                ->select('business_address as businessAddress','business_infos.business_name','business_address.city','business_address.zip_code','business_address.business_lat','business_address.business_long','favorites.seller_id')
                                ->get();
                               
                    if(count($favoriteLists)>0)
                    {
                        $favoritedata=array();
                        foreach ($favoriteLists as $key => $favoriteList)
                        {
                            $favoritedata[$key]['seller_id']=isset($favoriteList->seller_id)?$favoriteList->seller_id:'';
                            $favoritedata[$key]['business_name']=isset($favoriteList->business_name)?$favoriteList->business_name:'';
                            $favoritedata[$key]['address']=isset($favoriteList->businessAddress)?$favoriteList->businessAddress:'';
                            $favoritedata[$key]['city']=isset($favoriteList->city)?$favoriteList->city:'';
                            $favoritedata[$key]['zip_code']=isset($favoriteList->zip_code)?$favoriteList->zip_code:'';
                            $favoritedata[$key]['latitude']=isset($favoriteList->business_lat)?$favoriteList->business_lat:'';
                            $favoritedata[$key]['longitude']=isset($favoriteList->business_long)?$favoriteList->business_long:'';
                            $favoriteimage=DB::table('business_images')->where('user_id',$favoriteList->seller_id)->first();
                            $favoritedata[$key]['image']='';
                            if(!empty($favoriteimage->image) && file_exists(public_path('img/businessimage/'.$favoriteimage->image)))
                            {
                                $favoritedata[$key]['image']= url('img/businessimage/'.$favoriteimage->image);
                            }
                        }
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.favorite_list');
                        $resultArray['data']=$favoritedata;
                        return response()->json($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']=0;
                        $resultArray['message']=trans('api.favorite_not_found');
                        return response()->json($resultArray); exit;
                    }
                        
                }
        }

        public function orderCancel(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $orderId = isset($request->order_id) && !empty($request->order_id) ? $request->order_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $checkall=DB::table('orders')->where('user_id',$userId)->where('order_id','=',$orderId)->where('order_status','Pending')->first();
                    if(!empty($checkall))
                    {
                      
                        if($checkall->service_date>=date('Y-m-d'))
                        {
                            $datedatetime=$checkall->service_date.' '.$checkall->start_time;
                        
                            $new_time = date('Y-m-d H:i',strtotime('-2 hour',strtotime($datedatetime)));

                            if(date('Y-m-d H:i')<=$new_time)
                            {
                               DB::table('orders')->where('user_id',$userId)->where('order_id','=',$orderId)->where('order_status','Pending')->update(['order_status'=>'Cancel']);

                                  //seller Notification
                                    $deviceId=DB::table('user_devices')->where('user_id',$checkall->seller_id)->first();
                                    $device_id=isset($deviceId->device_id)?$deviceId->device_id:'';
                                    $title='Order cancel';
                                    $message='Order cancel from user your order id is '.$orderId;
                                    $orderstatus='Cancel';
                                    DB::table('notifications')->insert([
                                       'user_id'=>$checkall->seller_id,
                                       'title'=> $title,
                                       'message'=> $message,
                                       'type'=> $orderstatus,
                                        ]);
                                   
                                        $this->postpushnotification($device_id,$title,$message,$orderId,$orderstatus);
                                    
                                    

                                $resultArray['status']='1';
                                $resultArray['message']=trans('api.Order cancel successfully');
                                return response()->json($resultArray); exit;
                            }
                            else
                            {
                                $resultArray['status']=0;
                                $resultArray['message']=trans('api.Order not canceled 2 hours before canceled');
                                return response()->json($resultArray); exit;
                            }
                        }
                        else
                        {
                            $resultArray['status']=0;
                            $resultArray['message']=trans('api.Order not canceled Please contact for seller');
                            return response()->json($resultArray); exit;
                        }
                    }
                    else
                    {
                        $resultArray['status']=0;
                        $resultArray['message']=trans('api.Order not found');
                        return response()->json($resultArray); exit;
                    }
                }
        }

        public function timeSlotBooking(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
                'date'=>'required',
                'start_time'=>'required',
                'end_time'=>'required',
                'staff_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $chekdata=DB::table('checkouts')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND  status='Pending')")->first();
                    if(empty($chekdata))
                    {

                        DB::table('checkouts')->insert([
                                            'user_id'=>$userId,
                                            'seller_id'=>$sellerId,
                                            'date'=>$request->date,
                                            'start_time'=>$request->start_time,
                                            'end_time'=>$request->end_time,
                                            'staff_id'=>$request->staff_id,
                                            ]);
                    }
                    else
                    {
                        DB::table('checkouts')->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND  status='Pending')")->update([
                                        'date'=>$request->date,
                                        'start_time'=>$request->start_time,
                                        'end_time'=>$request->end_time,
                                        'staff_id'=>$request->staff_id,
                                    ]);
                    }

                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.Checkout data add successfully');
                        return response()->json($resultArray); exit;
                }
        }

        public function checkout(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {

                    $checkout=DB::table('checkouts')
                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND status='Pending')")->first();
                    $storeInfo=DB::table('business_infos')
                                    ->leftjoin('business_address','business_address.user_id','=','business_infos.user_id')
                                    ->select('business_infos.business_name','business_address.business_address','business_address.city','business_address.zip_code')
                                    ->where('business_infos.user_id',$sellerId)
                                    ->first();

                    $checkoutArray['store_name']=isset($storeInfo->business_name)?$storeInfo->business_name:'';
                    $checkoutArray['store_address']=isset($storeInfo->business_address)?$storeInfo->business_address:'';
                    $checkoutArray['store_city']=isset($storeInfo->city)?$storeInfo->city:'';
                    $checkoutArray['store_zipcode']=isset($storeInfo->zip_code)?$storeInfo->zip_code:'';
                    if(!empty($checkout))
                    {
                        $checkoutArray['day']=date('l', strtotime($checkout->date));
                        $checkoutArray['date']=$checkout->date;
                        $checkoutArray['start_time']=$checkout->start_time;
                        $checkoutArray['end_time']=$checkout->end_time;
                    }
                    else
                    {
                        $resultArray['status']=0;
                        $resultArray['message']='Data not found.';
                        return response()->json($resultArray); exit;
                    }

                    
                    $cartdatas=DB::table('carts')
                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                        ->whereRaw("(carts.user_id='".$userId."' AND carts.status='Pending')")->get();
                    if(count($cartdatas)>0)
                    {
                        $servicename=array();
                        $price=0;
                        $saleprice=0;
                        $servicenames=array();
                        foreach ($cartdatas as $k => $cartdata)
                        {
                            $checkoutArray['service_type']=$cartdata->service_type;
                            if($cartdata->service_type=='person')
                            {
                                $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                            }
                            if($cartdata->service_type=='home')
                            {
                                $checkservice=DB::table('seller_business_services')->where('home',1)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                            }

                            if(!empty($checkservice->special_offer))
                            {
                                $offer=($checkservice->price*$checkservice->special_offer)/100;
                                $total=$checkservice->price-$offer;
                                $saleprice+= number_format($total,2);
                            }
                            $price+= isset($checkservice->price)?$checkservice->price:0;
                            $service['service_name']=$cartdata->service_name;
                            array_push($servicename, $service);
                        }
                    }

                        $checkoutArray['price']=$price;
                        $checkoutArray['sale_price']=$saleprice;

                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Checkout list data found');
                        $resultArray['data']=$checkoutArray;
                        $resultArray['service_name']=$servicename;
                        return response()->json($resultArray); exit;
                }
        }

        public function placeOrder(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'seller_id'=>'required',
                'session_key'=>'required',
                'amount'=>'required',
                'transaction_id'=>'required',
                'payment_type'=>'required',
                'payment_status'=>'required',
                'total_amount'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id: '';
                $totalAmount = isset($request->total_amount) && !empty($request->total_amount) ? $request->total_amount: '';
                $discount = isset($request->discount_amount) && !empty($request->discount_amount) ? $request->discount_amount: '';
                $cuponCode = isset($request->coupon_code) && !empty($request->coupon_code) ? $request->coupon_code: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $checkout=DB::table('checkouts')
                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND status='Pending')")->first();
                        $orderId='US'.mt_rand(1000000000, (int) 9999999999);
                        DB::table('orders')->insert([
                                            'user_id'=>$userId,
                                            'seller_id'=>$sellerId,
                                            'service_date'=>$checkout->date,
                                            'start_time'=>$checkout->start_time,
                                            'end_time'=>$checkout->end_time,
                                            'staff_id'=>$checkout->staff_id,
                                            'order_id'=>$orderId,
                                            'trans_id'=>$request->transaction_id,
                                            'amount'=>$request->amount,
                                            'order_date'=>date('Y-m-d'),
                                            'coupon_code'=>$cuponCode,
                                            'discount_amount'=>$discount,
                                            'total_amount'=>$totalAmount,
                                            'payment_type'=>$request->payment_type,
                                            'payment_status'=>$request->payment_status
                                            ]);

                        $cartitems=DB::table('carts')
                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND status='Pending')")->get();

                            foreach ($cartitems as $key => $cartitem)
                            {
                                if($cartitem->service_type=='person')
                                {
                                   $sprice=DB::table('seller_business_services')->where('service_type_id',$cartitem->service_id)->where('person',1)->where('deleted_at', '=', Null)->where('user_id',$sellerId)->first();
                                   $saleprice=$sprice->price;
                                    if(!empty($sprice->special_offer))
                                    {
                                        $offer=($sprice->price*$sprice->special_offer)/100;
                                        $total=$sprice->price-$offer;
                                        $saleprice=number_format($total,2);
                                    }
                                   DB::table('carts')->where('id',$cartitem->id)->update(['service_price'=>$saleprice]) ;
                                }
                                if($cartitem->service_type=='home')
                                {
                                   $sprice=DB::table('seller_business_services')->where('service_type_id',$cartitem->service_id)->where('home',1)->where('deleted_at', '=', Null)->where('user_id',$sellerId)->first();
                                   $saleprice=$sprice->price;
                                    if(!empty($sprice->special_offer))
                                    {
                                        $offer=($sprice->price*$sprice->special_offer)/100;
                                        $total=$sprice->price-$offer;
                                        $saleprice=number_format($total,2);
                                    } 
                                   DB::table('carts')->where('id',$cartitem->id)->update(['service_price'=>$saleprice]) ;
                                }
                            }

                        DB::table('checkouts')
                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND status='Pending')")->update(['order_id'=>$orderId,'status'=>'Complete']);
                         DB::table('carts')
                        ->whereRaw("(user_id='".$userId."' AND seller_id='".$sellerId."' AND status='Pending')")->update(['order_id'=>$orderId,'status'=>'Complete']);

                        $checkout2=DB::table('checkouts')
                                 ->leftjoin('orders','orders.order_id','=','checkouts.order_id')
                                    ->whereRaw("(checkouts.user_id='".$userId."' AND checkouts.seller_id='".$sellerId."' AND checkouts.order_id='".$orderId."')")
                                    ->select('checkouts.*','orders.payment_type')
                                    ->first();

                                    $storeInfo=DB::table('business_infos')
                                                    ->leftjoin('business_address','business_address.user_id','=','business_infos.user_id')
                                                    ->select('business_infos.business_name','business_address.business_address','business_address.city','business_address.zip_code')
                                                    ->where('business_infos.user_id',$sellerId)
                                                    ->first();

                                    $checkoutArray['store_name']=isset($storeInfo->business_name)?$storeInfo->business_name:'';
                                    $checkoutArray['store_address']=isset($storeInfo->business_address)?$storeInfo->business_address:'';
                                    $checkoutArray['store_city']=isset($storeInfo->city)?$storeInfo->city:'';
                                    $checkoutArray['store_zipcode']=isset($storeInfo->zip_code)?$storeInfo->zip_code:'';
                                    if(!empty($checkout2))
                                    {
                                        $checkoutArray['day']=date('l', strtotime($checkout2->date));
                                        $checkoutArray['date']=$checkout2->date;
                                        $checkoutArray['start_time']=$checkout2->start_time;
                                        $checkoutArray['end_time']=$checkout2->end_time;
                                    }
                                    else
                                    {
                                        $resultArray['status']=0;
                                        $resultArray['message']=trans('api.data_not_found');
                                        return response()->json($resultArray); exit;
                                    }

                                    
                                    $cartdatas=DB::table('carts')
                                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                                        ->whereRaw("(carts.user_id='".$userId."' AND carts.order_id='".$orderId."')")->get();
                                    if(count($cartdatas)>0)
                                    {
                                        $servicename=array();
                                        $price=0;
                                        $servicenames=array();
                                        foreach ($cartdatas as $k => $cartdata)
                                        {
                                            $checkoutArray['service_type']=$cartdata->service_type;
                                            if($cartdata->service_type=='person')
                                            {
                                                $checkservice=DB::table('seller_business_services')->where('person',1)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                                            }
                                            if($cartdata->service_type=='home')
                                            {
                                                $checkservice=DB::table('seller_business_services')->where('home',0)->where('service_type_id',$cartdata->service_id)->where('user_id',$sellerId)->where('deleted_at', '=', Null)->first();
                                            }
                                            $price+= isset($checkservice->price)?$checkservice->price:0;
                                            $service['service_name']=$cartdata->service_name;
                                            array_push($servicename, $service);
                                        }
                                    }
                                $checkoutArray['price']=$price;
                                $checkoutArray['payment_type']=isset($checkout2->payment_type)?$checkout2->payment_type:'cash';

                                 $staffdata=DB::table('staff_members')->where('id',$checkout2->staff_id)->first();
                                if(!empty($staffdata))
                                {
                                    $checkoutArray['staff_id']=!empty($staffdata->id) ? $staffdata->id: '';
                                    $checkoutArray['staff_name']=!empty($staffdata->name) ? $staffdata->name: '';
                                    $checkoutArray['staff_phone']=!empty($staffdata->staff_phone) ? $staffdata->staff_phone: '';
                                    $checkoutArray['staff_bio']=!empty($staffdata->bio) ? $staffdata->bio: '';
                                    $checkoutArray['staff_experience']=!empty($staffdata->experience) ? $staffdata->experience: '';
                                    $checkoutArray['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                                }
                            //seller Notification
                        $deviceId=DB::table('user_devices')->where('user_id',$sellerId)->first();
                        $device_id=isset($deviceId->device_id)?$deviceId->device_id:'';
                        $title='New order';
                        $message='New order recieved successfully';
                        $orderstatus='order';
                     
                            $this->postpushnotification($device_id,$title,$message,$orderId,$orderstatus);
                                                      
                             DB::table('notifications')->insert([
                                       'user_id'=>$sellerId,
                                       'title'=> $title,
                                       'message'=> $message,
                                       'type'=> 'order',
                                        ]);

                        $resultArray['status']=1;
                        $resultArray['data']=$checkoutArray;
                        $resultArray['service_name']=$servicename;
                        $resultArray['message']=trans('api.Order successfully');
                        return response()->json($resultArray); exit;
                }
        }


        public function orderHistory(Request $request)
        {
           $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';

            $appoinment_date = isset($request->appoinment_date) && !empty($request->appoinment_date) ? $request->appoinment_date : '' ;

            //$appoinment_date = "2021-08-3";

            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);


           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
               if(!empty($appoinment_date))
               {

                    $appoinmentLists=DB::table('orders')
                                ->select('orders.*')
                                ->where("orders.order_date",$appoinment_date)
                                ->where('orders.user_id',$userid)
                                ->orderBy('orders.service_date','desc')
                                ->get();
                }
               else  
               {
                    $appoinmentLists=DB::table('orders')
                                ->select('orders.*')
                                ->where('orders.user_id',$userid)
                                ->orderBy('orders.service_date','desc')
                                ->get();
               }

                $allData=array();
               
                foreach ($appoinmentLists as $key => $appoinmentList)
                {
                    
                    $serviceData['order_id']=!empty($appoinmentList->order_id) ? $appoinmentList->order_id:'';
                    $serviceData['order_date']=!empty($appoinmentList->order_date) ? $appoinmentList->order_date: '';
                    $serviceData['service_date']=!empty($appoinmentList->service_date) ? $appoinmentList->service_date: '';
                     $serviceData['trans_id']=!empty($appoinmentList->trans_id) ? $appoinmentList->trans_id: '';
                    $serviceData['start_time']=!empty($appoinmentList->start_time) ? $appoinmentList->start_time: '';
                    $serviceData['end_time']=!empty($appoinmentList->end_time) ? $appoinmentList->end_time: '';
                    $serviceData['payment_status']=!empty($appoinmentList->payment_status) ? $appoinmentList->payment_status: '';
                    $serviceData['payment_type']=!empty($appoinmentList->payment_type) ? $appoinmentList->payment_type: '';
                    $serviceData['order_status']=!empty($appoinmentList->order_status) ? $appoinmentList->order_status: '';
                    $serviceData['amount']=!empty($appoinmentList->amount) ? $appoinmentList->amount: '';
                    //Staff data
                    $staffdata=DB::table('staff_members')->where('id',$appoinmentList->staff_id)->first();
                    if(!empty($staffdata))
                    {
                        $serviceData['staff_id']=!empty($staffdata->id) ? $staffdata->id: '';
                        $serviceData['staff_name']=!empty($staffdata->name) ? $staffdata->name: '';
                        $serviceData['staff_phone']=!empty($staffdata->staff_phone) ? $staffdata->staff_phone: '';
                        $serviceData['staff_bio']=!empty($staffdata->bio) ? $staffdata->bio: '';
                        $serviceData['staff_experience']=!empty($staffdata->experience) ? $staffdata->experience: '';
                        $serviceData['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                    }
                    $sellerinformation=DB::table('business_infos')
                                ->leftjoin('business_address','business_address.user_id','=','business_infos.user_id')
                                ->where('business_infos.user_id',$appoinmentList->seller_id)
                                ->select('business_address as businessAddress','business_infos.business_name','business_address.city','business_address.zip_code','business_address')
                                ->first();
                        $serviceData['seller_id']=isset($appoinmentList->seller_id)?$appoinmentList->seller_id:'';
                        $serviceData['business_name']=isset($sellerinformation->business_name)?$sellerinformation->business_name:'';
                        $serviceData['address']=isset($sellerinformation->businessAddress)?$sellerinformation->businessAddress:'';
                        $serviceData['city']=isset($sellerinformation->city)?$sellerinformation->city:'';
                        $serviceData['zip_code']=isset($sellerinformation->zip_code)?$sellerinformation->zip_code:'';
                               

                    $cartdatas=DB::table('carts')
                            ->leftjoin('business_services','business_services.id','=','carts.service_id')
                            ->leftjoin('seller_business_services','seller_business_services.service_type_id','=','carts.service_id')
                            ->leftjoin('business_types','business_types.id','=','carts.cat_id')
                            ->where('carts.status','Complete')
                            ->where('carts.seller_id',$appoinmentList->seller_id)
                            ->where('seller_business_services.user_id',$appoinmentList->seller_id)
                             ->whereRaw("(seller_business_services.deleted_at IS null)")
                            ->select('carts.*','seller_business_services.*','business_services.service_name','business_types.business_name')
                            ->where('order_id',$appoinmentList->order_id)->get();
                          //  echo '<pre>'; print_r($cartdatas);
                            $serviceDatasingle=array();
                            foreach ($cartdatas as $c => $cartdatas)
                            {
                                $mutiservice='';
                                if($cartdatas->time_type==1)
                                {
                                    $mutiservice=$cartdatas->in_time.','.$cartdatas->in_week;
                                }
                                $serviceData1['service_type']=isset($cartdatas->service_type)?$cartdatas->service_type:'';

                                $serviceData1['business_name']=isset($cartdatas->business_name)?$cartdatas->business_name:'';
                                $serviceData1['service_name']=isset($cartdatas->service_name)?$cartdatas->service_name:'';
                                $serviceData1['service_image']=url('img/serviceimage/'.$cartdatas->service_image);
                                $serviceData1['time_type']=isset($cartdatas->time_type)?$cartdatas->time_type:'';
                                $serviceData1['price_type']=isset($cartdatas->price_type)?$cartdatas->price_type:'';
                                $serviceData1['price']=isset($cartdatas->service_price)?$cartdatas->service_price:'';
                                $serviceData1['duration']=isset($cartdatas->duration)?$cartdatas->duration:'';
                                $serviceData1['multi_time']=$mutiservice;
                                array_push($serviceDatasingle, $serviceData1);
                            }
                            $serviceData['service_info']=$serviceDatasingle ;
                            array_push($allData, $serviceData);
                }
              
                if(!empty($allData))
                {
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.order_history_list');
                    $resultArray['data']=$allData;
                    return response()->json($resultArray); exit;
                }

                else {

                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_order_data');
                    return response()->json($resultArray); exit;
                }
            } 
        }

        public function userRatingList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $ratingservice=DB::table('orders')
                                ->join('users','users.id','=','orders.seller_id')
                                ->join('business_infos','business_infos.user_id','=','orders.seller_id')
                                ->join('business_address','business_address.user_id','=','orders.seller_id')
                                ->where('orders.user_id',$userid)
                                ->where('orders.order_status','Complete')
                                ->select('orders.*','business_infos.business_name','business_address.business_address','business_address.city','business_address.zip_code','users.username','users.avatar_location')
                                ->get();

                    
                    if(count($ratingservice)>0)
                    {
                        $ratingArray=array();
                        foreach ($ratingservice as $key => $rating)
                        {
                            $checkrating=DB::table('ratings')->where('order_id',$rating->order_id)->first();
                            $ratingArray[$key]['rating']=0;
                            if(!empty($checkrating) && $rating->order_id== $checkrating->order_id)
                            {
                                $ratingArray[$key]['rating']=isset($checkrating->rating)?$checkrating->rating:'';
                                $ratingArray[$key]['commnet']=isset($checkrating->comment)?$checkrating->comment:'';
                            }
                                $ratingArray[$key]['user_id']=$rating->user_id;
                                $ratingArray[$key]['seller_id']=$rating->seller_id;
                                $ratingArray[$key]['staff_id']=$rating->staff_id;
                                $ratingArray[$key]['order_id']=$rating->order_id;
                                $ratingArray[$key]['store_name']=isset($rating->business_name)?$rating->business_name:'';
                                $ratingArray[$key]['address']=isset($rating->business_address)?$rating->business_address:'';
                                $ratingArray[$key]['city']=isset($rating->city)?$rating->city:'';
                                $ratingArray[$key]['zip_code']=isset($rating->zip_code)?$rating->zip_code:'';
                                $ratingArray[$key]['user_name']=isset($rating->username)?$rating->username:'';
                                $ratingArray[$key]['comment']=isset($rating->comment)?$rating->comment:'';
                                 $ratingArray[$key]['image']='';
                                if(!empty($rating->avatar_location) && file_exists(public_path('img/business/profile/'.$rating->avatar_location)))
                                {
                                    $ratingArray[$key]['image']=url('img/business/profile/',$rating->avatar_location);
                                }
                        }
                            $resultArray['status']=1;
                            $resultArray['message']=trans('api.rating_list_data');
                            $resultArray['data']=$ratingArray;
                            return response()->json($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.data_not_found');
                        return response()->json($resultArray); exit;
                    }
            }
        }

        public function addRating(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
                'seller_id'=>'required',
                'staff_id'=>'required',
                'order_id'=>'required',
                'rating'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $comment = isset($request->comment) && !empty($request->comment) ? $request->comment : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                DB::table('ratings')->insert([
                                    'user_id'=>$userid,
                                    'seller_id'=>$request->seller_id,
                                    'staff_id'=>$request->staff_id,
                                    'order_id'=>$request->order_id,
                                    'rating'=>$request->rating,
                                    'comment'=>$comment,
                                    ]);
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.rating_add_successfully');
                        return response()->json($resultArray); exit;
            }
        }

        public function notificationList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
           $limit = $request->limit ? $request->limit : 10;
           $page = $request->page && $request->page > 0 ? $request->page : 1;

            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $notificationlist=DB::table('notifications')->where('user_id',$userid)->orderBy('id','desc')->paginate($limit);
                $unreadmessage=DB::table('notifications')->where('user_id',$userid)->where('is_read',0)->count();
                $notificationData=array();
                foreach ($notificationlist as $key => $value)
                {
                    $notificationData[$key]['id']=isset($value->id)?$value->id:'';
                    $notificationData[$key]['title']=isset($value->title)?$value->title:'';
                    $notificationData[$key]['message']=isset($value->message)?$value->message:'';
                    $notificationData[$key]['type']=isset($value->type)?$value->type:'';
                    $notificationData[$key]['is_read']=isset($value->is_read)?$value->is_read:'';
                    $notificationData[$key]['created_at']=isset($value->created_at)?$value->created_at:'';
                }

                $resultArray['status']=1;
                $resultArray['message']=trans('api.Notification list');
                $resultArray['data']=$notificationData;
                $resultArray['unread']=$unreadmessage;
                $resultArray['current_page']=$notificationlist->currentPage();
                $resultArray['total_page']=$notificationlist->lastPage();
                echo json_encode($resultArray); exit;     
            }
            
        }
        public function notificationRead(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
                'notification_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $notificationlist=DB::table('notifications')
                                ->where('id',$request->notification_id)
                                ->update(
                                    ['is_read'=>1]
                                );
                $unreadmessage=DB::table('notifications')->where('user_id',$userid)->where('is_read',0)->count();
             
                $resultArray['status']=1;
                $resultArray['message']=trans('api.Notification read successfully');
                $resultArray['unread']=$unreadmessage;
                echo json_encode($resultArray); exit;     
            }

        }
        public function notificationDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
                'notification_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {

                if(!empty($request->notification_id))
                {
                    $notificationdelete= explode(',', $request->notification_id);

                    foreach ($notificationdelete as $key => $delete)
                    {
                        DB::table('notifications')
                                ->where('id',$delete)
                                ->delete();
                   }
                }
                $unreadmessage=DB::table('notifications')->where('user_id',$userid)->where('is_read',0)->count();
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.Notification delete successfully');
                    $resultArray['unread']=$unreadmessage;
                    echo json_encode($resultArray); exit;     
            }

        }

        public function userDiscouontList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
                'seller_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {

                $discountList=DB::table('discounts')->where('user_id',$sellerId)->where('start_date','<=',date('Y-m-d'))->where('end_date','>=',date('Y-m-d'))->get();
                $discountArray=array();
                if(count($discountList)>0)
                {
                    foreach ($discountList as $key => $discount)
                    {
                        $data['id']=$discount->id;
                        $data['user_id']=$discount->user_id;
                        $data['min_order_value']=$discount->min_order_value;
                        $data['max_discount']=$discount->max_discount;
                        $data['coupon_code']=$discount->coupon;
                        $data['percentage']=$discount->percentage;
                        $data['start_date']=$discount->start_date;
                        $data['end_date']=$discount->end_date;
                        array_push($discountArray, $data);
                    }
                }
               
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.Discount list');
                    $resultArray['data']=$discountArray;
                    echo json_encode($resultArray); exit;     
            }
        }

        function postpushnotification($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
            if(!empty($device_id))
            {
              $fields = array(
                 'to' => $device_id,
                  'data' =>array('title' => $title, 'message' => $message,'urlToken' => $urlToken,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus),
                'notification'=>array('title'=>$title,'body'=>$message,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus)
                );

                $response = $this->sendPushNotification($fields);
                return true;
            }
        }

        function sendPushNotification($fields = array(), $usertype=Null)
        {
             //echo '<pre>';print_r($fields); //exit;
              $API_ACCESS_KEY = 'AAAAfCJQ4L0:APA91bFz__v7ZXMDFUudEzA0y_C04gx1iiPSCeaGStcj_hrOx7oNfKl5lwGFqZxzKAqDjgedJy14GdxF_LRuXUZn7fTTcMztP4wkSxYMsPRltXCov-ldRUtFN5FyWoNB5i5qbSi9La2k';

              $headers = array
              (
                'Authorization: key=' . $API_ACCESS_KEY,
                'Content-Type: application/json'
              );

              $ch = curl_init();
              curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
              curl_setopt( $ch,CURLOPT_POST, true );
              curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
              curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
              // Execute post
              $result = curl_exec($ch);
              //print_r($result);//die;
              sleep(5);
              if ($result === FALSE) {
                  die('Curl failed: ' . curl_error($ch));
              }
              // Close connection
              curl_close($ch);
              return $result;    
        }
        function iospush($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
            $tokenLength = strlen($device_id);
            if (!empty($device_id)) {
                $apnsHost = 'gateway.push.apple.com';
                //$apnsHost = 'gateway.sandbox.push.apple.com';
               //$apnsCert = public_path('buskalock.pem');
                $apnsCert = public_path('pushcertBuskalo.pem');
                $sound = 'default';
                $apnsPort = 2195;
                $apnsPass = '';
                $token = $device_id;
                $payload['aps'] = array('title' => $title, 'alert' => $message, 'badge' => '1', 'sound' => 'default','order_id'=>$orderid,'orderstatus'=>$orderstatus);
                $output = json_encode($payload);
                $token = pack('H*', str_replace(' ', '', $token));
                $apnsMessage = chr(0) . chr(0) . chr(32) . $token . chr(0) . chr(strlen($output)) . $output;
                $streamContext = stream_context_create();
                stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
                stream_context_set_option($streamContext, 'ssl', 'passphrase', $apnsPass);
                $apns = @stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error, $errorString, 2, STREAM_CLIENT_CONNECT, $streamContext);
                //fwrite($apns, $apnsMessage);
                $result = @fwrite($apns, $apnsMessage, strlen($apnsMessage)); //fwrite($apns, $apnsMessage);
                @fclose($apns);
                if (!$result) {
                    $a = 'Message not delivered' . PHP_EOL;
                } else {
                    $a = 'Message successfully delivered' . PHP_EOL;
                }
                $log = "User: " . $_SERVER['REMOTE_ADDR'] . ' - ' . date("F j, Y, g:i a") . PHP_EOL .
                    "Attempt: " . (!empty($result) ? 'Success' : 'Failed') . PHP_EOL .
                    "Pass: " . $result . PHP_EOL .
                    "apns: " . $apns . PHP_EOL .
                    "apnsMessage: " . $apnsMessage . PHP_EOL .
                    "device_id:" .$device_id . PHP_EOL .
                    "Pass: " . $a . PHP_EOL .
                    "-------------------------" . PHP_EOL;
                  //  return $result; 
               // echo "<pre>"; print_r($apns); die;
                return $log;
                //Save string to log, use FILE_APPEND to append.
                //file_put_contents(content_url().'/log/log_'.date("j.n.Y").'.txt', $log, FILE_APPEND);
                //exit;
            }
        }


     
        public function updatesql(Request $request)
        {
            
            $getdata1= DB::table('business_hours')
                            ->get();
            $getdata2= DB::table('social_accounts')->whereIn('user_id',['59','60','61'])->delete();

            $getdata3= DB::table('users')
                        ->leftjoin('mobile_session','mobile_session.user_id','=','users.id')
                        ->get();
            echo '<pre>'; print_r($getdata1);
        }
      
}   