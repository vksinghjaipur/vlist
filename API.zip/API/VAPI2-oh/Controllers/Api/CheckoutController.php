<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Auth\User;
use App\Models\UserSetting;
use App\Models\UserBillingAddress;
use App\Models\Product\AddCart;
use App\Models\Product\Order;
use App\Models\Product\OrderItem;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class CheckoutController extends APIController
{
    
    public function checkout(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

            $getitems= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->get();
            $itemlist=array();
            $subtotal=0;
            foreach ($getitems as $key => $getitem)
            {   
                $itemlist[$key]['item_id']=$getitem->id;
                $itemlist[$key]['product_id']=$getitem->p_id;
                $itemlist[$key]['quantity']=$getitem->quantity;
                $itemlist[$key]['price']=$getitem->getProductDetail->price*$getitem->quantity;
                $subtotal+=$getitem->getProductDetail->price*$getitem->quantity;
                $itemlist[$key]['product_name']=$getitem->getProductDetail->name;
                $itemlist[$key]['product_description']=$getitem->getProductDetail->description;
                if(isset($getitem->getProductDetail->singleImages->image) && !empty($getitem->getProductDetail->singleImages->image))
                {
                    $itemlist[$key]['product_image']=url('img/products_image/'.$getitem->getProductDetail->singleImages->image);
                }
            }   
                //Billing address get
                $getaddress= UserBillingAddress::where('user_id',$request->user_id)->get();
                $address1=array();
                if(count($getaddress)>0)
                {
                    //echo '<pre>'; print_r($getaddress);exit;
                    foreach($getaddress as $k=>$address)
                    {
                        $address1[$k]['address_id']=$address->id;
                        $address1[$k]['user_id']=$address->user_id;
                        $address1[$k]['address_title']=$address->address_title;
                        $address1[$k]['first_name']=$address->first_name;
                        $address1[$k]['last_name']=$address->last_name;
                        $address1[$k]['email']=$address->email;
                        $address1[$k]['phone_no']=$address->phone_no;
                        $address1[$k]['address']=$address->address;
                        $address1[$k]['country']=$address->country;
                        $address1[$k]['state']=$address->state;
                        $address1[$k]['city']=$address->city;
                        $address1[$k]['zip_code']=$address->zip_code;
                    }
                }

                $resultArray['status']='1';
                $resultArray['message']=trans('api.cart_item_delete');
                $resultArray['cart_item']=$itemlist;
                $resultArray['count']=count($getitems);
                $resultArray['sub_total']=$subtotal;
                $resultArray['address']=$address1;
                return response()->json($resultArray); exit;
    }


    public function billingAddress(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'email'=>'required',
                'phone_no'=>'required',
                'zip_code'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $addaddress= UserBillingAddress::where('user_id',$request->user_id)->where('id',$request->address_id)->first();
        $message=trans('api.address_update');
        if(empty($addaddress))
        {
            $addaddress= new UserBillingAddress;
            $message=trans('api.address_add');
        }
            $addaddress->user_id=$request->user_id;
            $addaddress->address_title=$request->address_title;
            $addaddress->first_name=$request->first_name;
            $addaddress->last_name=$request->last_name;
            $addaddress->email=$request->email;
            $addaddress->phone_no=$request->phone_no;
            $addaddress->address=$request->address;
            $addaddress->country=$request->country;
            $addaddress->state=$request->state;
            $addaddress->city=$request->city;
            $addaddress->zip_code=$request->zip_code;
            $addaddress->save();

                $resultArray['status']='1';
                $resultArray['message']=$message;
                return response()->json($resultArray); exit;
    }

    public function billingAddressDelete(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'address_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        UserBillingAddress::where('id',$request->address_id)->where('user_id',$request->user_id)->delete();

                $resultArray['status']='1';
                $resultArray['message']=trans('api.address_delete');
                return response()->json($resultArray); exit;
    }

    public function saveOrder(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'payment_method'=>'required',
                'shipping_address'=>'required',
                'total_amount'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
                $orderId='US'.mt_rand(1000000000, (int) 9999999999);
                $orderdata= new Order;
                $orderdata->user_id=$request->user_id;
                $orderdata->total_amount=$request->total_amount;
                $orderdata->discount=$request->discount;
                $orderdata->shipping_address=$request->shipping_address;
                $orderdata->shipping_charge=isset($request->shipping_charge)?$request->shipping_charge:'0';
                $orderdata->payment_method=$request->payment_method;
                $orderdata->order_id=$orderId;
                $orderdata->trans_id=rand(111111,9999999);
                $orderdata->payment_status=1;
                $orderdata->payment_date=date('Y-m-d');
                $orderdata->save();
                
            $getitems= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->get();
            foreach ($getitems as $key => $getitem)
            {   
                $orderitem= new OrderItem;
                $orderitem->user_id=$request->user_id;
                $orderitem->item_id=$orderdata->id;
                $orderitem->p_id=$getitem->p_id;
                $orderitem->price=$getitem->getProductDetail->price;
                $orderitem->quantity=$getitem->quantity;
                $orderitem->save();
                AddCart::where('id',$getitem->id)->update(['order_id'=>$orderId,'status'=>'complete']);
            }   
                $addaddress= UserBillingAddress::where('user_id',$request->user_id)->where('id',$request->shipping_address)->first();
                
                $orderplace['tracking_number']=$orderId;
                $orderplace['delivery_date']=date('Y-m-d',strtotime('+2 day'));
                $orderplace['address']=$addaddress->address;
                $orderplace['country']=$addaddress->country;
                $orderplace['state']=$addaddress->state;
                $orderplace['city']=$addaddress->city;
                $orderplace['zip_code']=$addaddress->zip_code;
                $orderplace['phone_no']=$addaddress->phone_no;
                $resultArray['status']='1';
                $resultArray['message']=trans('api.order_save');
                $resultArray['orderplace']=$orderplace;
                return response()->json($resultArray); exit;
    }
}   