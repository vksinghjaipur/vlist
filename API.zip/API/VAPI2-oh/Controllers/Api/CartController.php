<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Lookbook;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Models\Product\AddCart;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsConfirmation;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class CartController extends APIController
{
    public function addCart(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'product_id'=>'required',
                'quantity'=>'required',
                'price'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

        $checkproduct= AddCart::where('user_id',$request->user_id)->where('p_id',$request->product_id)->where('status','pending')->first();
        if(empty($checkproduct))
        {
            $carts= new AddCart;
            $carts->user_id=$request->user_id;
            $carts->p_id=$request->product_id;
            $carts->quantity=$request->quantity;
            $carts->price=$request->price;
            $carts->status='pending';
            $carts->save();
            $message= trans('api.cart_add_item');
        }else
        {
            $checkproduct->quantity=$request->quantity;
            $checkproduct->price=$request->price;
            $checkproduct->save();
            $message= trans('api.cart_update_item');
        }
        $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();

        $updateitems= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->where('p_id',$request->product_id)->first();
            $cart_item['item_id']=$updateitems->id;
            $cart_item['product_id']=$updateitems->p_id;
            $cart_item['price']=$updateitems->getProductDetail->price;
            $cart_item['price_total']=$updateitems->getProductDetail->price*$updateitems->quantity;
            $cart_item['product_description']=isset($updateitems->getProductDetail->description)?$updateitems->getProductDetail->description:'no description';
            if(isset($updateitems->getProductDetail->singleImages->image) && !empty($updateitems->getProductDetail->singleImages->image))
            {
                $cart_item['product_image']=url('img/products_image/'.$updateitems->getProductDetail->singleImages->image);
            }
            $cart_item['product_name']=$updateitems->getProductDetail->name;
            $cart_item['quantity']=$updateitems->quantity;

            $resultArray['status']='1';
            $resultArray['message']=$message;
            $resultArray['cart_item']=$cart_item;
            $resultArray['count']=$getitemsCount;
            return response()->json($resultArray); exit;
    }

    public function cartList(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $getitems= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->get();
            $itemlist=array();
            $subtotal=0;
            foreach ($getitems as $key => $getitem)
            {   
                $itemlist[$key]['item_id']=$getitem->id;
                $itemlist[$key]['product_id']=$getitem->p_id;
                $itemlist[$key]['quantity']=$getitem->quantity;
                $itemlist[$key]['price']=$getitem->getProductDetail->price;
                $itemlist[$key]['price_total']=$getitem->getProductDetail->price*$getitem->quantity;
                $subtotal+=$getitem->getProductDetail->price*$getitem->quantity;
                $itemlist[$key]['product_name']=$getitem->getProductDetail->name;
                $itemlist[$key]['product_description']=$getitem->getProductDetail->description;
                if(isset($getitem->getProductDetail->singleImages->image) && !empty($getitem->getProductDetail->singleImages->image))
                {
                    $itemlist[$key]['product_image']=url('img/products_image/'.$getitem->getProductDetail->singleImages->image);
                }
            }

            $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();

            if(count($itemlist)>0)
            {
                $resultArray['status']='1';
                $resultArray['message']=trans('api.cart_data');
                $resultArray['cart_item']=$itemlist;
                $resultArray['count']=$getitemsCount;
                $resultArray['sub_total']=$subtotal;
                return response()->json($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.cart_empty');
                return response()->json($resultArray); exit;
            }
    }

    public function cartItemDelete(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'item_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';

            DB::table('product_cart')->where('id',$request->item_id)->whereRaw("(product_cart.user_id='".$userId."' AND product_cart.status='pending')")->delete();

            $getitems= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->get();
            $itemlist=array();
            $subtotal=0;
            foreach ($getitems as $key => $getitem)
            {   
                $itemlist[$key]['item_id']=$getitem->id;
                $itemlist[$key]['product_id']=$getitem->p_id;
                $itemlist[$key]['quantity']=$getitem->quantity;
                $itemlist[$key]['price']=$getitem->getProductDetail->price;
                $itemlist[$key]['price_total']=$getitem->getProductDetail->price*$getitem->quantity;
                $subtotal+=$getitem->getProductDetail->price*$getitem->quantity;
                $itemlist[$key]['product_name']=$getitem->getProductDetail->name;
                $itemlist[$key]['product_description']=$getitem->getProductDetail->description;
                if(isset($getitem->getProductDetail->singleImages->image) && !empty($getitem->getProductDetail->singleImages->image))
                {
                    $itemlist[$key]['product_image']=url('img/products_image/'.$getitem->getProductDetail->singleImages->image);
                }
            }
             $getitemsCount= AddCart::with('getProductDetail')->where('user_id',$request->user_id)->where('status','pending')->count();
            if(count($itemlist)>0)
            {
                $resultArray['status']='1';
                $resultArray['message']=trans('api.cart_item_delete');
                $resultArray['cart_item']=$itemlist;
                $resultArray['count']=$getitemsCount;
                $resultArray['sub_total']=$subtotal;
                return response()->json($resultArray); exit;
            }
            else
            {
                $resultArray['status']='1';
                $resultArray['message']=trans('api.cart_item_delete');
                $resultArray['count']=$getitemsCount;
                return response()->json($resultArray); exit;
            }         
    }
}   