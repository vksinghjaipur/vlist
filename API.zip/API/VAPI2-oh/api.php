<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

/*Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});*/

Route::group(['namespace' => 'Api'], function () {
        /*Account Controller Start*/

        Route::post('logout', 'AccountController@logout');
        Route::post('guestUser', 'AccountController@guestUser');
        Route::post('register', 'AccountController@register');
        Route::post('login', 'AccountController@login');
        Route::post('updatePhoneNumber', 'AccountController@updatePhoneNumber');
        Route::post('updatePassword', 'AccountController@updatePassword');
        Route::post('userSetting', 'AccountController@userSetting');
        Route::post('userSettingList', 'AccountController@userSettingList');
        Route::post('userProfileImage', 'AccountController@userProfileImage');
        Route::post('updateProfile', 'AccountController@updateProfile');
        Route::post('forget','AccountController@forgetPassword');
        Route::post('forgetPassword','AccountController@forgetPasswordUpdate');
        Route::post('resendOtp','AccountController@resendOtp');
        Route::post('verifyCode','AccountController@verifyCode');
        Route::post('requestVerifyCode', 'AccountController@requestVerifyCode');
       

    
      //social Login
        Route::post('emailUpdate', 'AccountController@emailUpdate');
        Route::post('socialLogin', 'AccountController@socialLogin');
        Route::post('isCheckedSocial', 'AccountController@isCheckedSocial');

        /* Account Controller End */

       /* AppController Start */
        //card route
        Route::post('pages', 'AppController@pages');
        Route::post('addCard', 'AppController@addCard');
        Route::post('cardUpdate', 'AppController@cardUpdate');
        Route::post('cardList', 'AppController@cardList');
        Route::post('cardDelete', 'AppController@cardDelete');
      
        //Business api
        Route::post('businessInfo', 'AppController@businessInfo');
        Route::post('businessAddress', 'AppController@businessAddress');
        Route::post('businessTravel', 'AppController@businessTravel');
        Route::post('businessHours', 'AppController@businessHours');
        Route::post('businessDays', 'AppController@businessDays');
        Route::post('showbusinessHour', 'AppController@showbusinessHour');
        Route::post('businessImage', 'AppController@businessImage');
        Route::post('businessType', 'AppController@businessType');
        Route::post('sellerBusinessType', 'AppController@sellerBusinessType');
        Route::post('businessServices', 'AppController@businessServices');
        Route::post('businessSubservices', 'AppController@businessSubservices');
        Route::post('SellerBusinessServices', 'AppController@SellerBusinessServices');
        Route::post('businessStaticPages','AppController@businessStaticPages');
        Route::get('subscription','AppController@subscription');
        Route::post('certificateDelete','AppController@certificateDelete');
        //Seller Rating
        Route::post('sellerRating','AppController@sellerRating');
          //save business type
        Route::post('selectbusinessType', 'AppController@selectbusinessType');
        Route::post('deletebusinessType', 'AppController@deletebusinessType');
        Route::post('image', 'AppController@image');
        Route::post('customerList', 'AppController@customerList');
        Route::post('customerInfo', 'AppController@customerInfo');
        Route::post('sales', 'AppController@sales');
        //Route::post('serviceDelete', 'AppController@serviceDelete');

        /* AppController End */

        //User Rating
        Route::post('userRatingList','UserController@userRatingList');
        Route::post('addRating','UserController@addRating');


        //user List Show
        Route::post('userSettingShow', 'AppController@userSettingShow');
        //booking Type
        Route::post('bookingType','AppController@bookingType');

      
        

        //Order Management
        Route::post('appoinmentListsecond', 'AppController@appoinmentListsecond');
        Route::post('orderStatus', 'AppController@orderStatus');
        Route::post('orderDetail', 'AppController@orderDetail');

        //service list
        Route::post('editSingleService', 'AppController@editSingleService');
        //save business type service
        Route::post('addMultiService', 'AppController@addMultiService');
        Route::post('ShowServices', 'AppController@ShowServices');
        Route::post('DeleteServices', 'AppController@DeleteServices');
        Route::post('serviceDetails', 'AppController@serviceDetails');

        //staff members
        Route::post('addStaffMember', 'AppController@addStaffMember');
        Route::post('EditStaffMember', 'AppController@EditStaffMember');
        Route::post('StaffMemberList', 'AppController@StaffMemberList');
        Route::post('StaffMemberDelete', 'AppController@StaffMemberDelete');
        Route::post('StaffMemberDetail', 'AppController@StaffMemberDetail');
        Route::post('reSendInvitationCode', 'AppController@reSendInvitationCode');
        Route::post('staffBioAdd', 'AppController@staffBioAdd');
        Route::post('staffAboutAdd', 'AppController@staffAboutAdd');


        //Gift Card
        Route::post('addGiftCard', 'AppController@addGiftCard');
        Route::post('giftCardList', 'AppController@giftCardList');
        Route::post('giftCardDelete', 'AppController@giftCardDelete');
        Route::post('giftCardDelete', 'AppController@giftCardDelete');

        //home search
        Route::post('serviceList', 'AppController@serviceList');
        Route::post('home', 'UserController@home');

        Route::post('searchCities', 'AppController@searchCities');
       
       
       //get Plan
        Route::get('getPlans','AppController@getPlans');

        
        Route::post('sellerInfo', 'UserController@sellerInfo');
        Route::post('sellerStaffInfo', 'UserController@sellerStaffInfo');
        Route::post('serviceCategory', 'UserController@serviceCategory');

        //booking service
        Route::post('serviceBooking', 'UserController@serviceBookingList');
        Route::post('categoryServices', 'UserController@categoryServices');
        Route::post('cart', 'UserController@addCart');
        Route::post('itemList', 'UserController@itemList');
        Route::post('timeSlotBooking', 'UserController@timeSlotBooking');
        Route::post('checkout', 'UserController@checkout');
        Route::post('placeOrder', 'UserController@placeOrder');
        Route::post('itemDelete', 'UserController@itemDelete');
        Route::post('otherSellerItemDelete', 'UserController@otherSellerItemDelete');
        Route::post('serviceBookingTime', 'UserController@serviceBookingTime');
        Route::post('serviceBookingTimeChange', 'UserController@serviceBookingTimeChange');
        Route::post('timeSlotBookingUpdate', 'UserController@timeSlotBookingUpdate');
        Route::post('favorite','UserController@favorite');
        Route::post('favoriteList','UserController@favoriteList');
        Route::post('orderHistory','UserController@orderHistory');
        Route::post('orderCancel','UserController@orderCancel');

        //discount
        Route::post('addDiscount', 'AppController@addDiscount');
        Route::post('discountList', 'AppController@discountList');
        Route::post('discountDelete', 'AppController@discountDelete');
        Route::post('userDiscouontList', 'UserController@userDiscouontList');

        //Notification
        Route::post('notificationList','UserController@notificationList');
        Route::post('notificationDelete','UserController@notificationDelete');
        Route::post('notificationRead','UserController@notificationRead');
        Route::post('notificationSetting','AppController@notificationSetting');

        //Product Management
        Route::post('product/getProduct','ProductController@getProduct');
        Route::post('product/productDetail','ProductController@productDetail');
        Route::post('product/categoryFilter','ProductController@categoryFilter');
        Route::post('product/favorite','ProductController@favorite');
        Route::post('product/favoriteList','ProductController@favoriteList');
        Route::post('product/comment','ProductController@comment');

        Route::post('product/addCart','CartController@addCart');
        Route::post('product/cartList','CartController@cartList');
        Route::post('product/cartItemDelete','CartController@cartItemDelete');
        Route::post('product/checkout','CheckoutController@checkout');
        Route::post('product/billingAddress','CheckoutController@billingAddress');
        Route::post('product/billingAddress/delete','CheckoutController@billingAddressDelete');
        Route::post('product/saveOrder','CheckoutController@saveOrder');
        Route::post('product/myOrder','OrderController@myOrder');
        Route::post('product/orderDetail','OrderController@orderDetail');
        Route::post('product/returnOrder','OrderController@returnOrder');
        Route::post('product/returnRequest','OrderController@returnRequest');
        Route::post('product/cancelOrder','OrderController@cancelOrder');
        Route::post('product/orderCancelRequest','OrderController@orderCancelRequest');
        Route::post('product/reviewStore','OrderController@reviewStore');
        Route::post('product/reviewList','OrderController@reviewList');
        Route::get('product/myCoupons','OrderController@myCoupons');
        


        //Look Book Controller
        Route::post('lookBookCreate', 'LookBookController@lookBookCreate');
        Route::post('getSubServices', 'LookBookController@getSubServices');
        Route::post('storeLookbook', 'LookBookController@storeLookbook');
        Route::post('getSellerLookBook', 'LookBookController@getSellerLookBook');
        Route::post('getSellerLookBookDetail', 'LookBookController@getSellerLookBookDetail');
        Route::post('lookBookDetailFilter', 'LookBookController@lookBookDetailFilter');
        Route::post('getAddFavourites', 'LookBookController@getAddFavourites');

        Route::post('getLookBook', 'ProductController@getLookBook');
        Route::post('getLookBookDetal', 'ProductController@getLookBookDetal');



        //Booking Controller
        Route::post('bookingList', 'BookingController@bookingList');

        //remove  description
        Route::get('updatesql','UserController@updatesql');
        Route::group(['middleware' => ['auth:api']], function () {
        Route::group(['prefix' => 'auth'], function () {
        Route::post('logout', 'AuthController@logout');
        Route::get('me', 'AuthController@me');

     });
   });
});
