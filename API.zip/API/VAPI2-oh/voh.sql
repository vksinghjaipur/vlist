-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 18, 2023 at 02:27 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ohcut`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_cards`
--

DROP TABLE IF EXISTS `add_cards`;
CREATE TABLE IF NOT EXISTS `add_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `card_holder` varchar(255) DEFAULT NULL,
  `card_number` bigint(20) DEFAULT NULL,
  `cvv` int(11) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_cards`
--

INSERT INTO `add_cards` (`id`, `user_id`, `card_holder`, `card_number`, `cvv`, `zip_code`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 8, 'shoukin', 656565656, 145, '5645', '2022-05-06 09:56:56', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
CREATE TABLE IF NOT EXISTS `blogs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `publish_datetime` datetime NOT NULL,
  `featured_image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cannonical_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0 => InActive, 1 => Published, 2 => Draft, 3 => Scheduled',
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` (`id`, `name`, `publish_datetime`, `featured_image`, `content`, `meta_title`, `cannonical_link`, `slug`, `meta_description`, `meta_keywords`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'eum optio quam', '2010-10-29 13:13:36', NULL, 'Sapiente necessitatibus ducimus eaque ratione dicta voluptatem. A eos quod amet explicabo excepturi autem repudiandae. Illum eos ipsa est ut. Odit beatae asperiores qui laudantium corrupti ut adipisci.', 'expedita nisi vitae', 'http://www.smitham.com/possimus-quia-ut-autem-qui', 'aut-nihil-aliquid-commodi-aspernatur', 'Quia eius distinctio assumenda perspiciatis quis. Eum qui velit voluptates et maxime. Beatae nisi in dolore nemo omnis soluta tempora. Architecto quasi ipsam sit nesciunt nam non rerum.', 'quis', 3, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(2, 'eos perferendis voluptatem', '2009-10-27 19:30:45', NULL, 'Nostrum sit earum culpa quia commodi possimus. Labore et modi fugiat veritatis deserunt deserunt officia. Et quia ut et deleniti impedit excepturi.', 'quas ea asperiores', 'http://www.satterfield.com/occaecati-laudantium-sit-dolore', 'et-voluptates-repellendus-quo-consequatur-eaque', 'Repellat consectetur ut accusamus repudiandae magnam aut aperiam. Id ab porro illo necessitatibus dolorum. Vitae minus quia vel. Fugiat ut tenetur ea corrupti voluptatem magni molestiae.', 'nulla', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(3, 'praesentium quos sapiente', '2009-04-15 23:01:17', NULL, 'Dolores recusandae aut sit minima qui cupiditate quas. Delectus atque nihil ex odio similique consequatur consectetur et. Reiciendis omnis eveniet vero similique.', 'qui officia non', 'http://www.ernser.com/', 'aperiam-et-tempore-eum-voluptate', 'Maiores deserunt sunt eos asperiores accusamus. Omnis quia dolore fugit est quo voluptas eum. Voluptatum quam aut est ut quos commodi unde.', 'voluptates', 2, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'nihil quo est', '1971-08-19 20:25:25', NULL, 'Inventore ducimus nulla exercitationem voluptates. Quis vero voluptatem provident dolores et rerum. Eum eos quam occaecati modi.', 'ut doloremque doloribus', 'http://johns.com/et-tempora-eius-dolore-ab-et-in-temporibus', 'cumque-est-sequi-consequatur', 'Est a maxime ut dolorem. Atque sint maiores accusamus quis praesentium eos. Nesciunt dolores incidunt eum odit eligendi. Quod molestiae aut debitis officiis aperiam qui et.', 'et', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(5, 'sit voluptates ducimus', '2005-06-08 11:01:57', NULL, 'Asperiores ex rerum quasi exercitationem qui eos. Ea error quia quis at ad sequi. Eum aut sed sunt qui qui dolorem.', 'autem saepe quo', 'http://ferry.biz/', 'et-nesciunt-velit-in-provident-atque-explicabo-est', 'Magnam qui laboriosam ducimus quia dolorum aut. Est numquam vitae similique dolorum eius. Eveniet dolorum qui aut nam.', 'a', 3, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(6, 'tenetur nulla doloremque', '1987-09-06 10:48:49', NULL, 'Quibusdam id perspiciatis beatae quis nulla. Exercitationem quam saepe tenetur quia quaerat magni. Excepturi est omnis odit aliquid. Aut nulla consequatur sit modi quibusdam ut natus.', 'sed dicta cumque', 'http://www.walker.com/voluptas-officiis-rerum-et-laboriosam-ducimus-ut-ut.html', 'aut-provident-ut-nobis-quo-est-voluptatem', 'Et temporibus temporibus unde esse sunt saepe. Porro occaecati enim quam assumenda expedita. Repudiandae natus aliquid exercitationem ipsa rerum.', 'iure', 2, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(7, 'aut minus quos', '2009-12-22 12:12:43', NULL, 'Quaerat sunt repellat aut voluptatibus consequuntur voluptate blanditiis. Nesciunt expedita quibusdam sed fugiat occaecati fugit. Facere ut dicta nihil amet dolore nihil sed.', 'optio tempore qui', 'http://okuneva.com/', 'dolor-aspernatur-mollitia-cum-dolorum-sit-sit-et', 'Nostrum commodi non error. Harum ipsam dolorem ut voluptas aut magni itaque nihil. Similique officiis libero architecto molestiae nesciunt voluptate. Nihil quas quidem eligendi similique.', 'dolore', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(8, 'voluptatem error atque', '2008-12-05 02:58:23', NULL, 'Omnis sint quisquam assumenda ratione autem molestiae rerum. Fuga eveniet dolor ex voluptas sed accusantium. Sit qui nam ut aut ipsam pariatur.', 'veniam molestias placeat', 'http://www.howe.org/id-est-sed-aut-sunt-saepe-autem', 'quae-quia-dolorem-id-vel', 'Magnam nesciunt deleniti rerum excepturi asperiores dolorem. Perferendis dicta molestiae rem officia alias officiis vel. Hic quis aperiam id voluptatem esse. Quod non ut suscipit.', 'temporibus', 2, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(9, 'quia a et', '2020-09-09 21:22:41', NULL, 'Eum rem enim perspiciatis porro. Tempore quia et est a ut beatae. Cumque magni ipsa vero molestiae molestiae.', 'blanditiis aut ut', 'http://kutch.com/', 'id-in-minus-tenetur-ut-voluptates-dolorem-est', 'Adipisci aliquam laudantium repudiandae. Quae error repudiandae quibusdam rerum. Laboriosam sunt a est velit. Explicabo praesentium nemo nesciunt.', 'quis', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(10, 'sit corporis eaque', '1982-08-19 04:04:18', NULL, 'Cum voluptate voluptatem optio ut optio soluta expedita. Dolores quod nemo asperiores dolorum dolor. Ea dicta adipisci iste ullam.', 'non ipsa assumenda', 'https://schroeder.com/cum-illo-voluptate-nisi-ad.html', 'vel-deleniti-est-iure', 'Omnis fugit est neque et. Autem cum ea ut et. Et aut dignissimos error est quis ipsum rerum. Qui exercitationem quis voluptatem dignissimos.', 'ipsa', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
CREATE TABLE IF NOT EXISTS `blog_categories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_categories`
--

INSERT INTO `blog_categories` (`id`, `name`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'dolor consequatur cum12', 0, 5, 1, '2021-04-22 06:32:18', '2021-05-26 06:44:14', NULL),
(2, 'qui commodi illum', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(3, 'cum consectetur totam', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'sit vero vel', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(5, 'eos pariatur porro', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(6, 'reiciendis non consequatur', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(7, 'voluptas iusto rerum', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(8, 'neque dignissimos neque', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(9, 'dolore hic sunt', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(10, 'voluptates totam ullam', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `blog_map_categories`
--

DROP TABLE IF EXISTS `blog_map_categories`;
CREATE TABLE IF NOT EXISTS `blog_map_categories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `blog_id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_map_categories_blog_id_index` (`blog_id`),
  KEY `blog_map_categories_category_id_index` (`category_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_map_categories`
--

INSERT INTO `blog_map_categories` (`id`, `blog_id`, `category_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6),
(7, 7, 7),
(8, 8, 8),
(9, 9, 9),
(10, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `blog_map_tags`
--

DROP TABLE IF EXISTS `blog_map_tags`;
CREATE TABLE IF NOT EXISTS `blog_map_tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `blog_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_map_tags_blog_id_index` (`blog_id`),
  KEY `blog_map_tags_tag_id_index` (`tag_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_map_tags`
--

INSERT INTO `blog_map_tags` (`id`, `blog_id`, `tag_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(4, 4, 4),
(5, 5, 5),
(6, 6, 6),
(7, 7, 7),
(8, 8, 8),
(9, 9, 9),
(10, 10, 10);

-- --------------------------------------------------------

--
-- Table structure for table `blog_tags`
--

DROP TABLE IF EXISTS `blog_tags`;
CREATE TABLE IF NOT EXISTS `blog_tags` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blog_tags`
--

INSERT INTO `blog_tags` (`id`, `name`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'aliquid', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(2, 'ea', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(3, 'doloribus', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'eum', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(5, 'numquam', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(6, 'perspiciatis', 0, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(7, 'est', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(8, 'ut', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(9, 'molestias', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(10, 'quaerat', 1, 5, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `booking_types`
--

DROP TABLE IF EXISTS `booking_types`;
CREATE TABLE IF NOT EXISTS `booking_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `in_person` tinyint(1) NOT NULL DEFAULT '0',
  `at_home` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `business_address`
--

DROP TABLE IF EXISTS `business_address`;
CREATE TABLE IF NOT EXISTS `business_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `business_address` varchar(255) DEFAULT NULL,
  `apart_number` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `business_lat` varchar(255) DEFAULT NULL,
  `business_long` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_address`
--

INSERT INTO `business_address` (`id`, `user_id`, `business_address`, `apart_number`, `city`, `zip_code`, `business_lat`, `business_long`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'Shyam Nagar', 'Taxi Pandey road lines, Vivek Vihar, Shyam Nagar', 'Jaipur', '302019', '26.88813901741031', '75.76106529682875', '2022-05-06 09:08:42', '2022-06-21 11:55:07', NULL),
(2, 2, '10, Gujar Ki Thadi, Shanthi Nagar, Mansarovar, Jaipur, Rajasthan 302020, India', 'Mansarovar', 'Jaipur', '302020', '26.878622590864115', '75.76703321188688', '2022-05-20 12:10:44', '2022-06-21 11:31:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business_hours`
--

DROP TABLE IF EXISTS `business_hours`;
CREATE TABLE IF NOT EXISTS `business_hours` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `day` varchar(50) DEFAULT NULL,
  `start_time` varchar(20) DEFAULT NULL,
  `end_time` varchar(20) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_hours`
--

INSERT INTO `business_hours` (`id`, `user_id`, `day`, `start_time`, `end_time`, `status`, `created_at`, `updated_at`) VALUES
(1, 9, 'Monday', '08:39AM', '06:45PM', 1, '2022-05-06 09:11:55', NULL),
(2, 9, 'Tuesday', '08:39AM', '08:40PM', 1, '2022-05-06 09:11:55', NULL),
(3, 9, 'Wednesday', '08:41AM', '07:41PM', 1, '2022-05-06 09:11:55', NULL),
(4, 9, 'Thursday', '08:40AM', '08:41PM', 1, '2022-05-06 09:11:55', NULL),
(5, 9, 'Friday', '08:41AM', '08:41PM', 1, '2022-05-06 09:11:55', NULL),
(6, 9, 'Saturday', '08:41AM', '08:41PM', 1, '2022-05-06 09:11:55', NULL),
(7, 9, 'Sunday', '', '', 0, '2022-05-06 09:11:55', NULL),
(8, 4, 'Monday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(9, 4, 'Monday', '04:00PM', '09:30PM', 1, '2022-05-20 12:18:09', NULL),
(10, 4, 'Tuesday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(11, 4, 'Tuesday', '04:00PM', '09:30PM', 1, '2022-05-20 12:18:09', NULL),
(12, 4, 'Wednesday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(13, 4, 'Thursday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(14, 4, 'Friday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(15, 4, 'Saturday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL),
(16, 4, 'Sunday', '10:00AM', '02:00PM', 1, '2022-05-20 12:18:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business_images`
--

DROP TABLE IF EXISTS `business_images`;
CREATE TABLE IF NOT EXISTS `business_images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_images`
--

INSERT INTO `business_images` (`id`, `user_id`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 9, '86777.jpg', 1, '2022-05-06 09:12:30', NULL),
(2, 9, '55913.jpg', 1, '2022-05-06 09:12:30', NULL),
(3, 4, '30574.jpeg', 1, '2022-05-20 12:19:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business_infos`
--

DROP TABLE IF EXISTS `business_infos`;
CREATE TABLE IF NOT EXISTS `business_infos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `official_id` varchar(255) DEFAULT NULL,
  `certificate` varchar(255) DEFAULT NULL,
  `about` text,
  `facebook_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `google_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_infos`
--

INSERT INTO `business_infos` (`id`, `user_id`, `business_name`, `official_id`, `certificate`, `about`, `facebook_url`, `instagram_url`, `google_url`) VALUES
(1, 9, 'jaipur salon', 'jaipu4', '47401.docx|53309.pdf', NULL, '', '', ''),
(2, 4, 'Oh Cut Business', '458321AFD', '31739.pdf', NULL, 'www.facebook.com', 'https://www.instagram.com/', 'www.google.com');

-- --------------------------------------------------------

--
-- Table structure for table `business_services`
--

DROP TABLE IF EXISTS `business_services`;
CREATE TABLE IF NOT EXISTS `business_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_id` int(11) DEFAULT NULL,
  `service_name` varchar(255) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `special_offer` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_services`
--

INSERT INTO `business_services` (`id`, `business_id`, `service_name`, `price`, `special_offer`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Cut (Short Hair)', NULL, NULL, 1, '2022-04-21 05:53:37', '2022-05-02 07:07:29', NULL),
(2, 1, 'Cut (Middle Hair)', NULL, NULL, 1, '2022-04-21 05:53:49', '2022-05-02 07:06:26', NULL),
(3, 1, 'Cut (Long Hair)', NULL, NULL, 1, '2022-04-21 05:54:00', '2022-05-02 07:07:08', NULL),
(4, 1, 'Firm (Short Hair)', NULL, NULL, 1, '2022-04-21 05:54:14', '2022-05-02 07:09:36', NULL),
(5, 1, 'Firm (Middle Hair)', NULL, NULL, 1, '2022-04-21 05:54:25', '2022-05-02 07:10:12', NULL),
(6, 1, 'Firm (Long Hair)', NULL, NULL, 1, '2022-04-21 06:02:53', '2022-05-02 07:10:39', NULL),
(7, 1, 'Dying (Short Hair)', NULL, NULL, 1, '2022-04-21 06:03:12', '2022-05-02 07:14:00', NULL),
(8, 1, 'Dying (Middle Hair)', NULL, NULL, 1, '2022-04-21 06:03:26', '2022-05-02 07:14:29', NULL),
(9, 1, 'Dying (Long Hair)', NULL, NULL, 1, '2022-04-21 06:03:39', '2022-05-02 07:15:02', NULL),
(10, 1, 'Styling (Short Hair)', NULL, NULL, 1, '2022-05-02 06:09:59', '2022-05-02 07:16:38', NULL),
(11, 1, 'Styling (Middle Hair)', NULL, NULL, 1, '2022-05-02 06:11:21', '2022-05-02 07:17:19', NULL),
(12, 1, 'Styling (Long Hair)', NULL, NULL, 1, '2022-05-02 06:13:34', '2022-05-02 07:17:40', NULL),
(13, 2, 'Cut (Short Hair)', NULL, NULL, 1, '2022-05-02 06:14:00', '2022-05-02 07:22:59', NULL),
(14, 2, 'Cut (Middle Hair)', NULL, NULL, 1, '2022-05-02 06:17:17', '2022-05-02 07:23:32', NULL),
(15, 2, 'Cut (Long Hair)', NULL, NULL, 1, '2022-05-02 06:17:42', '2022-05-02 07:23:53', NULL),
(16, 2, 'Shaving', NULL, NULL, 1, '2022-05-02 06:19:01', '2022-05-02 07:24:36', NULL),
(17, 2, 'Combo', NULL, NULL, 1, '2022-05-02 06:20:22', '2022-05-02 07:24:50', NULL),
(18, 3, 'Manicure', NULL, NULL, 1, '2022-05-02 06:20:43', '2022-05-02 07:27:00', NULL),
(19, 3, 'Pedicure', NULL, NULL, 1, '2022-05-02 06:23:26', '2022-05-02 07:27:24', NULL),
(20, 4, 'Body (Laser)', NULL, NULL, 1, '2022-05-02 06:27:11', '2022-05-02 07:28:55', NULL),
(21, 4, 'Body (Body Shape)', NULL, NULL, 1, '2022-05-02 06:27:28', '2022-05-02 07:29:34', NULL),
(22, 4, 'Face (Laser)', NULL, NULL, 1, '2022-05-02 06:33:24', '2022-05-02 07:30:16', NULL),
(23, 4, 'Face (Botox)', NULL, NULL, 1, '2022-05-02 06:33:49', '2022-05-02 08:05:17', NULL),
(24, 4, 'Face (Filler)', NULL, NULL, 1, '2022-05-02 06:34:19', '2022-05-02 08:06:09', NULL),
(25, 5, 'Face', NULL, NULL, 1, '2022-05-02 08:07:35', NULL, NULL),
(26, 5, 'Body', NULL, NULL, 1, '2022-05-02 08:07:54', NULL, NULL),
(27, 6, 'Foot spa', NULL, NULL, 1, '2022-05-02 08:12:18', NULL, NULL),
(28, 6, 'Body spa', NULL, NULL, 1, '2022-05-02 08:13:09', NULL, NULL),
(29, 7, 'Morning', NULL, NULL, 1, '2022-05-02 08:14:55', NULL, NULL),
(30, 7, 'Afternoon', NULL, NULL, 1, '2022-05-02 08:15:12', NULL, NULL),
(31, 7, 'Night', NULL, NULL, 1, '2022-05-02 08:15:36', NULL, NULL),
(32, 8, 'Morning', NULL, NULL, 1, '2022-05-02 08:16:01', NULL, NULL),
(33, 8, 'Afternoon', NULL, NULL, 1, '2022-05-02 08:16:09', NULL, NULL),
(34, 8, 'Night', NULL, NULL, 1, '2022-05-02 08:16:17', NULL, NULL),
(35, 9, 'Home Training', NULL, NULL, 1, '2022-05-02 08:19:13', NULL, NULL),
(36, 9, 'Virtual Training', NULL, NULL, 1, '2022-05-02 08:19:37', NULL, NULL),
(37, 9, 'Group Training', NULL, NULL, 1, '2022-05-02 08:20:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `business_travels`
--

DROP TABLE IF EXISTS `business_travels`;
CREATE TABLE IF NOT EXISTS `business_travels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `travel_service` tinyint(1) NOT NULL DEFAULT '0',
  `min_travel_fee` varchar(255) DEFAULT NULL,
  `max_travel_distance` varchar(255) DEFAULT NULL,
  `travel_policy` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_travels`
--

INSERT INTO `business_travels` (`id`, `user_id`, `travel_service`, `min_travel_fee`, `max_travel_distance`, `travel_policy`) VALUES
(1, 9, 0, '50', '50', 'The other credit that I have will thinking working you for and rest past the your'),
(2, 4, 1, '2', '20', 'Our travel services will be available only day time.');

-- --------------------------------------------------------

--
-- Table structure for table `business_types`
--

DROP TABLE IF EXISTS `business_types`;
CREATE TABLE IF NOT EXISTS `business_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `business_name` varchar(255) DEFAULT NULL,
  `business_image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `business_types`
--

INSERT INTO `business_types` (`id`, `business_name`, `business_image`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Hair Salon', '1651728199hair-salon.png', 1, '2022-04-21 05:53:23', '2022-05-05 05:23:19', NULL),
(2, 'Barber', '1651728213barbar.png', 1, '2022-04-21 06:02:34', '2022-05-05 05:23:33', NULL),
(3, 'Nail Salon', '1651728275nail-salon.png', 1, '2022-05-02 06:06:08', '2022-05-05 05:24:35', NULL),
(4, 'Beauty Salon', '1651728294beauty-salon.png', 1, '2022-05-02 06:08:41', '2022-05-05 05:24:54', NULL),
(5, 'Massage', '1651728306massage.png', 1, '2022-05-02 06:12:47', '2022-05-05 05:25:06', NULL),
(6, 'Day spa', '1651728322day-spa.png', 1, '2022-05-02 06:16:23', '2022-05-05 05:25:22', NULL),
(7, 'Yoga', '1651728345yoga.png', 1, '2022-05-02 06:18:44', '2022-05-05 05:25:45', NULL),
(8, 'Pilates', '1651728357pilates.png', 1, '2022-05-02 06:22:27', '2022-05-05 05:25:57', NULL),
(9, 'Personal training', '1651728375personal-training.png', 1, '2022-05-02 06:33:03', '2022-05-05 05:26:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE KEY `cache_key_unique` (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

DROP TABLE IF EXISTS `carts`;
CREATE TABLE IF NOT EXISTS `carts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `business_service_id` int(11) NOT NULL,
  `service_type` varchar(250) DEFAULT NULL,
  `service_price` varchar(11) DEFAULT NULL,
  `status` enum('Pending','Complete') NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `user_id`, `seller_id`, `cat_id`, `service_id`, `business_service_id`, `service_type`, `service_price`, `status`, `order_id`, `created_at`) VALUES
(1, 8, 9, 1, 2, 0, 'person', '47.60', 'Complete', 'US1892257684', '2022-05-13 09:14:20'),
(2, 8, 9, 1, 3, 0, 'person', '27.00', 'Complete', 'US1892257684', '2022-05-13 09:14:20'),
(3, 8, 9, 1, 1, 0, 'person', '40.50', 'Complete', 'US1892257684', '2022-05-13 09:14:20'),
(4, 10, 9, 1, 2, 0, 'person', '47.60', 'Complete', 'US4288989945', '2022-05-18 13:11:39'),
(5, 10, 9, 1, 3, 0, 'person', '27.00', 'Complete', 'US4288989945', '2022-05-18 13:11:39'),
(6, 8, 4, 1, 1, 0, 'home', '', 'Pending', NULL, '2022-06-01 13:06:42'),
(7, 8, 4, 1, 2, 0, 'home', '', 'Pending', NULL, '2022-06-01 13:06:42');

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

DROP TABLE IF EXISTS `checkouts`;
CREATE TABLE IF NOT EXISTS `checkouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `start_time` varchar(255) NOT NULL,
  `end_time` varchar(255) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `status` enum('Pending','Complete') NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checkouts`
--

INSERT INTO `checkouts` (`id`, `user_id`, `seller_id`, `date`, `start_time`, `end_time`, `staff_id`, `status`, `order_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 8, 9, '2022-05-13', '08:41', '09:40', 1, 'Complete', 'US1892257684', '2022-05-13 09:14:48', '2022-05-13 09:14:54', NULL),
(2, 10, 9, '2022-05-20', '11:38', '12:37', 1, 'Complete', 'US4288989945', '2022-05-18 13:11:55', '2022-05-18 13:12:11', NULL),
(3, 8, 4, '2022-06-01', '10:00', '10:59', 2, 'Pending', NULL, '2022-06-01 13:07:47', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

DROP TABLE IF EXISTS `cities`;
CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cities_name` varchar(191) CHARACTER SET latin1 DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=483 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `cities_name`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Adelanto', 1, '2022-05-03 11:34:22', '2022-05-03 06:04:22', NULL),
(2, 'Agoura Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(3, 'Alameda', 1, '2022-05-03 11:14:16', NULL, NULL),
(4, 'Albany', 1, '2022-05-03 11:14:16', NULL, NULL),
(5, 'Alhambra', 1, '2022-05-03 11:14:16', NULL, NULL),
(6, 'Aliso Viejo', 1, '2022-05-03 11:14:16', NULL, NULL),
(7, 'Alturas', 1, '2022-05-03 11:14:16', NULL, NULL),
(8, 'Amador City', 1, '2022-05-03 11:14:16', NULL, NULL),
(9, 'American Canyon', 1, '2022-05-03 11:14:16', NULL, NULL),
(10, 'Anaheim', 1, '2022-05-03 11:14:16', NULL, NULL),
(11, 'Anderson', 1, '2022-05-03 11:14:16', NULL, NULL),
(12, 'Angels Camp', 1, '2022-05-03 11:14:16', NULL, NULL),
(13, 'Antioch', 1, '2022-05-03 11:14:16', NULL, NULL),
(14, 'Apple Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(15, 'Arcadia', 1, '2022-05-03 11:14:16', NULL, NULL),
(16, 'Arcata', 1, '2022-05-03 11:14:16', NULL, NULL),
(17, 'Arroyo Grande', 1, '2022-05-03 11:14:16', NULL, NULL),
(18, 'Artesia', 1, '2022-05-03 11:14:16', NULL, NULL),
(19, 'Arvin', 1, '2022-05-03 11:14:16', NULL, NULL),
(20, 'Atascadero', 1, '2022-05-03 11:14:16', NULL, NULL),
(21, 'Atherton', 1, '2022-05-03 11:14:16', NULL, NULL),
(22, 'Atwater', 1, '2022-05-03 11:14:16', NULL, NULL),
(23, 'Auburn', 1, '2022-05-03 11:14:16', NULL, NULL),
(24, 'Avalon', 1, '2022-05-03 11:14:16', NULL, NULL),
(25, 'Avenal', 1, '2022-05-03 11:14:16', NULL, NULL),
(26, 'Azusa', 1, '2022-05-03 11:14:16', NULL, NULL),
(27, 'Bakersfield', 1, '2022-05-03 11:14:16', NULL, NULL),
(28, 'Baldwin Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(29, 'Banning', 1, '2022-05-03 11:14:16', NULL, NULL),
(30, 'Barstow', 1, '2022-05-03 11:14:16', NULL, NULL),
(31, 'Beaumont', 1, '2022-05-03 11:14:16', NULL, NULL),
(32, 'Bell', 1, '2022-05-03 11:14:16', NULL, NULL),
(33, 'Bell Gardens', 1, '2022-05-03 11:14:16', NULL, NULL),
(34, 'Bellflower', 1, '2022-05-03 11:14:16', NULL, NULL),
(35, 'Belmont', 1, '2022-05-03 11:14:16', NULL, NULL),
(36, 'Belvedere', 1, '2022-05-03 11:14:16', NULL, NULL),
(37, 'Benicia', 1, '2022-05-03 11:14:16', NULL, NULL),
(38, 'Berkeley', 1, '2022-05-03 11:14:16', NULL, NULL),
(39, 'Beverly Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(40, 'Big Bear Lake', 1, '2022-05-03 11:14:16', NULL, NULL),
(41, 'Biggs', 1, '2022-05-03 11:14:16', NULL, NULL),
(42, 'Bishop', 1, '2022-05-03 11:14:16', NULL, NULL),
(43, 'Blue Lake', 1, '2022-05-03 11:14:16', NULL, NULL),
(44, 'Blythe', 1, '2022-05-03 11:14:16', NULL, NULL),
(45, 'Bradbury', 1, '2022-05-03 11:14:16', NULL, NULL),
(46, 'Brawley', 1, '2022-05-03 11:14:16', NULL, NULL),
(47, 'Brea', 1, '2022-05-03 11:14:16', NULL, NULL),
(48, 'Brentwood', 1, '2022-05-03 11:14:16', NULL, NULL),
(49, 'Brisbane', 1, '2022-05-03 11:14:16', NULL, NULL),
(50, 'Buellton', 1, '2022-05-03 11:14:16', NULL, NULL),
(51, 'Buena Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(52, 'Burbank', 1, '2022-05-03 11:14:16', NULL, NULL),
(53, 'Burlingame', 1, '2022-05-03 11:14:16', NULL, NULL),
(54, 'Calabasas', 1, '2022-05-03 11:14:16', NULL, NULL),
(55, 'Calexico', 1, '2022-05-03 11:14:16', NULL, NULL),
(56, 'California City', 1, '2022-05-03 11:14:16', NULL, NULL),
(57, 'Calimesa', 1, '2022-05-03 11:14:16', NULL, NULL),
(58, 'Calipatria', 1, '2022-05-03 11:14:16', NULL, NULL),
(59, 'Calistoga', 1, '2022-05-03 11:14:16', NULL, NULL),
(60, 'Camarillo', 1, '2022-05-03 11:14:16', NULL, NULL),
(61, 'Campbell', 1, '2022-05-03 11:14:16', NULL, NULL),
(62, 'Canyon Lake', 1, '2022-05-03 11:14:16', NULL, NULL),
(63, 'Capitola', 1, '2022-05-03 11:14:16', NULL, NULL),
(64, 'Carlsbad', 1, '2022-05-03 11:14:16', NULL, NULL),
(65, 'Carmel-by-the-Sea', 1, '2022-05-03 11:14:16', NULL, NULL),
(66, 'Carpinteria', 1, '2022-05-03 11:14:16', NULL, NULL),
(67, 'Carson', 1, '2022-05-03 11:14:16', NULL, NULL),
(68, 'Cathedral City', 1, '2022-05-03 11:14:16', NULL, NULL),
(69, 'Ceres', 1, '2022-05-03 11:14:16', NULL, NULL),
(70, 'Cerritos', 1, '2022-05-03 11:14:16', NULL, NULL),
(71, 'Chico', 1, '2022-05-03 11:14:16', NULL, NULL),
(72, 'Chino', 1, '2022-05-03 11:14:16', NULL, NULL),
(73, 'Chino Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(74, 'Chowchilla', 1, '2022-05-03 11:14:16', NULL, NULL),
(75, 'Chula Vista', 1, '2022-05-03 11:14:16', NULL, NULL),
(76, 'Citrus Heights', 1, '2022-05-03 11:14:16', NULL, NULL),
(77, 'Claremont', 1, '2022-05-03 11:14:16', NULL, NULL),
(78, 'Clayton', 1, '2022-05-03 11:14:16', NULL, NULL),
(79, 'Clearlake', 1, '2022-05-03 11:14:16', NULL, NULL),
(80, 'Cloverdale', 1, '2022-05-03 11:14:16', NULL, NULL),
(81, 'Clovis', 1, '2022-05-03 11:14:16', NULL, NULL),
(82, 'Coachella', 1, '2022-05-03 11:14:16', NULL, NULL),
(83, 'Coalinga', 1, '2022-05-03 11:14:16', NULL, NULL),
(84, 'Colfax', 1, '2022-05-03 11:14:16', NULL, NULL),
(85, 'Colma', 1, '2022-05-03 11:14:16', NULL, NULL),
(86, 'Colton', 1, '2022-05-03 11:14:16', NULL, NULL),
(87, 'Colusa', 1, '2022-05-03 11:14:16', NULL, NULL),
(88, 'Commerce', 1, '2022-05-03 11:14:16', NULL, NULL),
(89, 'Compton', 1, '2022-05-03 11:14:16', NULL, NULL),
(90, 'Concord', 1, '2022-05-03 11:14:16', NULL, NULL),
(91, 'Corcoran', 1, '2022-05-03 11:14:16', NULL, NULL),
(92, 'Corning', 1, '2022-05-03 11:14:16', NULL, NULL),
(93, 'Corona', 1, '2022-05-03 11:14:16', NULL, NULL),
(94, 'Coronado', 1, '2022-05-03 11:14:16', NULL, NULL),
(95, 'Corte Madera', 1, '2022-05-03 11:14:16', NULL, NULL),
(96, 'Costa Mesa', 1, '2022-05-03 11:14:16', NULL, NULL),
(97, 'Cotati', 1, '2022-05-03 11:14:16', NULL, NULL),
(98, 'Covina', 1, '2022-05-03 11:14:16', NULL, NULL),
(99, 'Crescent City', 1, '2022-05-03 11:14:16', NULL, NULL),
(100, 'Cudahy', 1, '2022-05-03 11:14:16', NULL, NULL),
(101, 'Culver City', 1, '2022-05-03 11:14:16', NULL, NULL),
(102, 'Cupertino', 1, '2022-05-03 11:14:16', NULL, NULL),
(103, 'Cypress', 1, '2022-05-03 11:14:16', NULL, NULL),
(104, 'Daly City', 1, '2022-05-03 11:14:16', NULL, NULL),
(105, 'Dana Point', 1, '2022-05-03 11:14:16', NULL, NULL),
(106, 'Danville', 1, '2022-05-03 11:14:16', NULL, NULL),
(107, 'Davis', 1, '2022-05-03 11:14:16', NULL, NULL),
(108, 'Del Mar', 1, '2022-05-03 11:14:16', NULL, NULL),
(109, 'Del Rey Oaks', 1, '2022-05-03 11:14:16', NULL, NULL),
(110, 'Delano', 1, '2022-05-03 11:14:16', NULL, NULL),
(111, 'Desert Hot Springs', 1, '2022-05-03 11:14:16', NULL, NULL),
(112, 'Diamond Bar', 1, '2022-05-03 11:14:16', NULL, NULL),
(113, 'Dinuba', 1, '2022-05-03 11:14:16', NULL, NULL),
(114, 'Dixon', 1, '2022-05-03 11:14:16', NULL, NULL),
(115, 'Dorris', 1, '2022-05-03 11:14:16', NULL, NULL),
(116, 'Dos Palos', 1, '2022-05-03 11:14:16', NULL, NULL),
(117, 'Downey', 1, '2022-05-03 11:14:16', NULL, NULL),
(118, 'Duarte', 1, '2022-05-03 11:14:16', NULL, NULL),
(119, 'Dublin', 1, '2022-05-03 11:14:16', NULL, NULL),
(120, 'Dunsmuir', 1, '2022-05-03 11:14:16', NULL, NULL),
(121, 'East Palo Alto', 1, '2022-05-03 11:14:16', NULL, NULL),
(122, 'Eastvale', 1, '2022-05-03 11:14:16', NULL, NULL),
(123, 'El Cajon', 1, '2022-05-03 11:14:16', NULL, NULL),
(124, 'El Centro', 1, '2022-05-03 11:14:16', NULL, NULL),
(125, 'El Cerrito', 1, '2022-05-03 11:14:16', NULL, NULL),
(126, 'El Monte', 1, '2022-05-03 11:14:16', NULL, NULL),
(127, 'El Segundo', 1, '2022-05-03 11:14:16', NULL, NULL),
(128, 'Elk Grove', 1, '2022-05-03 11:14:16', NULL, NULL),
(129, 'Emeryville', 1, '2022-05-03 11:14:16', NULL, NULL),
(130, 'Encinitas', 1, '2022-05-03 11:14:16', NULL, NULL),
(131, 'Escalon', 1, '2022-05-03 11:14:16', NULL, NULL),
(132, 'Escondido', 1, '2022-05-03 11:14:16', NULL, NULL),
(133, 'Etna', 1, '2022-05-03 11:14:16', NULL, NULL),
(134, 'Eureka', 1, '2022-05-03 11:14:16', NULL, NULL),
(135, 'Exeter', 1, '2022-05-03 11:14:16', NULL, NULL),
(136, 'Fairfax', 1, '2022-05-03 11:14:16', NULL, NULL),
(137, 'Fairfield', 1, '2022-05-03 11:14:16', NULL, NULL),
(138, 'Farmersville', 1, '2022-05-03 11:14:16', NULL, NULL),
(139, 'Ferndale', 1, '2022-05-03 11:14:16', NULL, NULL),
(140, 'Fillmore', 1, '2022-05-03 11:14:16', NULL, NULL),
(141, 'Firebaugh', 1, '2022-05-03 11:14:16', NULL, NULL),
(142, 'Folsom', 1, '2022-05-03 11:14:16', NULL, NULL),
(143, 'Fontana', 1, '2022-05-03 11:14:16', NULL, NULL),
(144, 'Fort Bragg', 1, '2022-05-03 11:14:16', NULL, NULL),
(145, 'Fort Jones', 1, '2022-05-03 11:14:16', NULL, NULL),
(146, 'Fortuna', 1, '2022-05-03 11:14:16', NULL, NULL),
(147, 'Foster City', 1, '2022-05-03 11:14:16', NULL, NULL),
(148, 'Fountain Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(149, 'Fowler', 1, '2022-05-03 11:14:16', NULL, NULL),
(150, 'Fremont', 1, '2022-05-03 11:14:16', NULL, NULL),
(151, 'Fresno', 1, '2022-05-03 11:14:16', NULL, NULL),
(152, 'Fullerton', 1, '2022-05-03 11:14:16', NULL, NULL),
(153, 'Galt', 1, '2022-05-03 11:14:16', NULL, NULL),
(154, 'Garden Grove', 1, '2022-05-03 11:14:16', NULL, NULL),
(155, 'Gardena', 1, '2022-05-03 11:14:16', NULL, NULL),
(156, 'Gilroy', 1, '2022-05-03 11:14:16', NULL, NULL),
(157, 'Glendale', 1, '2022-05-03 11:14:16', NULL, NULL),
(158, 'Glendora', 1, '2022-05-03 11:14:16', NULL, NULL),
(159, 'Goleta', 1, '2022-05-03 11:14:16', NULL, NULL),
(160, 'Gonzales', 1, '2022-05-03 11:14:16', NULL, NULL),
(161, 'Grand Terrace', 1, '2022-05-03 11:14:16', NULL, NULL),
(162, 'Grass Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(163, 'Greenfield', 1, '2022-05-03 11:14:16', NULL, NULL),
(164, 'Gridley', 1, '2022-05-03 11:14:16', NULL, NULL),
(165, 'Grover Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(166, 'Guadalupe', 1, '2022-05-03 11:14:16', NULL, NULL),
(167, 'Gustine', 1, '2022-05-03 11:14:16', NULL, NULL),
(168, 'Half Moon Bay', 1, '2022-05-03 11:14:16', NULL, NULL),
(169, 'Hanford', 1, '2022-05-03 11:14:16', NULL, NULL),
(170, 'Hawaiian Gardens', 1, '2022-05-03 11:14:16', NULL, NULL),
(171, 'Hawthorne', 1, '2022-05-03 11:14:16', NULL, NULL),
(172, 'Hayward', 1, '2022-05-03 11:14:16', NULL, NULL),
(173, 'Healdsburg', 1, '2022-05-03 11:14:16', NULL, NULL),
(174, 'Hemet', 1, '2022-05-03 11:14:16', NULL, NULL),
(175, 'Hercules', 1, '2022-05-03 11:14:16', NULL, NULL),
(176, 'Hermosa Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(177, 'Hesperia', 1, '2022-05-03 11:14:16', NULL, NULL),
(178, 'Hidden Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(179, 'Highland', 1, '2022-05-03 11:14:16', NULL, NULL),
(180, 'Hillsborough', 1, '2022-05-03 11:14:16', NULL, NULL),
(181, 'Hollister', 1, '2022-05-03 11:14:16', NULL, NULL),
(182, 'Holtville', 1, '2022-05-03 11:14:16', NULL, NULL),
(183, 'Hughson', 1, '2022-05-03 11:14:16', NULL, NULL),
(184, 'Huntington Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(185, 'Huntington Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(186, 'Huron', 1, '2022-05-03 11:14:16', NULL, NULL),
(187, 'Imperial', 1, '2022-05-03 11:14:16', NULL, NULL),
(188, 'Imperial Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(189, 'Indian Wells', 1, '2022-05-03 11:14:16', NULL, NULL),
(190, 'Indio', 1, '2022-05-03 11:14:16', NULL, NULL),
(191, 'Industry', 1, '2022-05-03 11:14:16', NULL, NULL),
(192, 'Inglewood', 1, '2022-05-03 11:14:16', NULL, NULL),
(193, 'Ione', 1, '2022-05-03 11:14:16', NULL, NULL),
(194, 'Irvine', 1, '2022-05-03 11:14:16', NULL, NULL),
(195, 'Irwindale', 1, '2022-05-03 11:14:16', NULL, NULL),
(196, 'Isleton', 1, '2022-05-03 11:14:16', NULL, NULL),
(197, 'Jackson', 1, '2022-05-03 11:14:16', NULL, NULL),
(198, 'Jurupa Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(199, 'Kerman', 1, '2022-05-03 11:14:16', NULL, NULL),
(200, 'King City', 1, '2022-05-03 11:14:16', NULL, NULL),
(201, 'Kingsburg', 1, '2022-05-03 11:14:16', NULL, NULL),
(202, 'La Ca?ada Flintridge', 1, '2022-05-03 11:14:16', NULL, NULL),
(203, 'La Habra', 1, '2022-05-03 11:14:16', NULL, NULL),
(204, 'La Habra Heights', 1, '2022-05-03 11:14:16', NULL, NULL),
(205, 'La Mesa', 1, '2022-05-03 11:14:16', NULL, NULL),
(206, 'La Mirada', 1, '2022-05-03 11:14:16', NULL, NULL),
(207, 'La Palma', 1, '2022-05-03 11:14:16', NULL, NULL),
(208, 'La Puente', 1, '2022-05-03 11:14:16', NULL, NULL),
(209, 'La Quinta', 1, '2022-05-03 11:14:16', NULL, NULL),
(210, 'La Verne', 1, '2022-05-03 11:14:16', NULL, NULL),
(211, 'Lafayette', 1, '2022-05-03 11:14:16', NULL, NULL),
(212, 'Laguna Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(213, 'Laguna Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(214, 'Laguna Niguel', 1, '2022-05-03 11:14:16', NULL, NULL),
(215, 'Laguna Woods', 1, '2022-05-03 11:14:16', NULL, NULL),
(216, 'Lake Elsinore', 1, '2022-05-03 11:14:16', NULL, NULL),
(217, 'Lake Forest', 1, '2022-05-03 11:14:16', NULL, NULL),
(218, 'Lakeport', 1, '2022-05-03 11:14:16', NULL, NULL),
(219, 'Lakewood', 1, '2022-05-03 11:14:16', NULL, NULL),
(220, 'Lancaster', 1, '2022-05-03 11:14:16', NULL, NULL),
(221, 'Larkspur', 1, '2022-05-03 11:14:16', NULL, NULL),
(222, 'Lathrop', 1, '2022-05-03 11:14:16', NULL, NULL),
(223, 'Lawndale', 1, '2022-05-03 11:14:16', NULL, NULL),
(224, 'Lemon Grove', 1, '2022-05-03 11:14:16', NULL, NULL),
(225, 'Lemoore', 1, '2022-05-03 11:14:16', NULL, NULL),
(226, 'Lincoln', 1, '2022-05-03 11:14:16', NULL, NULL),
(227, 'Lindsay', 1, '2022-05-03 11:14:16', NULL, NULL),
(228, 'Live Oak', 1, '2022-05-03 11:14:16', NULL, NULL),
(229, 'Livermore', 1, '2022-05-03 11:14:16', NULL, NULL),
(230, 'Livingston', 1, '2022-05-03 11:14:16', NULL, NULL),
(231, 'Lodi', 1, '2022-05-03 11:14:16', NULL, NULL),
(232, 'Loma Linda', 1, '2022-05-03 11:14:16', NULL, NULL),
(233, 'Lomita', 1, '2022-05-03 11:14:16', NULL, NULL),
(234, 'Lompoc', 1, '2022-05-03 11:14:16', NULL, NULL),
(235, 'Long Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(236, 'Loomis', 1, '2022-05-03 11:14:16', NULL, NULL),
(237, 'Los Alamitos', 1, '2022-05-03 11:14:16', NULL, NULL),
(238, 'Los Altos', 1, '2022-05-03 11:14:16', NULL, NULL),
(239, 'Los Altos Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(240, 'Los Angeles', 1, '2022-05-03 11:14:16', NULL, NULL),
(241, 'Los Banos', 1, '2022-05-03 11:14:16', NULL, NULL),
(242, 'Los Gatos', 1, '2022-05-03 11:14:16', NULL, NULL),
(243, 'Loyalton', 1, '2022-05-03 11:14:16', NULL, NULL),
(244, 'Lynwood', 1, '2022-05-03 11:14:16', NULL, NULL),
(245, 'Madera', 1, '2022-05-03 11:14:16', NULL, NULL),
(246, 'Malibu', 1, '2022-05-03 11:14:16', NULL, NULL),
(247, 'Mammoth Lakes', 1, '2022-05-03 11:14:16', NULL, NULL),
(248, 'Manhattan Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(249, 'Manteca', 1, '2022-05-03 11:14:16', NULL, NULL),
(250, 'Maricopa', 1, '2022-05-03 11:14:16', NULL, NULL),
(251, 'Marina', 1, '2022-05-03 11:14:16', NULL, NULL),
(252, 'Martinez', 1, '2022-05-03 11:14:16', NULL, NULL),
(253, 'Marysville', 1, '2022-05-03 11:14:16', NULL, NULL),
(254, 'Maywood', 1, '2022-05-03 11:14:16', NULL, NULL),
(255, 'McFarland', 1, '2022-05-03 11:14:16', NULL, NULL),
(256, 'Mendota', 1, '2022-05-03 11:14:16', NULL, NULL),
(257, 'Menifee', 1, '2022-05-03 11:14:16', NULL, NULL),
(258, 'Menlo Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(259, 'Merced', 1, '2022-05-03 11:14:16', NULL, NULL),
(260, 'Mill Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(261, 'Millbrae', 1, '2022-05-03 11:14:16', NULL, NULL),
(262, 'Milpitas', 1, '2022-05-03 11:14:16', NULL, NULL),
(263, 'Mission Viejo', 1, '2022-05-03 11:14:16', NULL, NULL),
(264, 'Modesto', 1, '2022-05-03 11:14:16', NULL, NULL),
(265, 'Monrovia', 1, '2022-05-03 11:14:16', NULL, NULL),
(266, 'Montague', 1, '2022-05-03 11:14:16', NULL, NULL),
(267, 'Montclair', 1, '2022-05-03 11:14:16', NULL, NULL),
(268, 'Monte Sereno', 1, '2022-05-03 11:14:16', NULL, NULL),
(269, 'Montebello', 1, '2022-05-03 11:14:16', NULL, NULL),
(270, 'Monterey', 1, '2022-05-03 11:14:16', NULL, NULL),
(271, 'Monterey Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(272, 'Moorpark', 1, '2022-05-03 11:14:16', NULL, NULL),
(273, 'Moraga', 1, '2022-05-03 11:14:16', NULL, NULL),
(274, 'Moreno Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(275, 'Morgan Hill', 1, '2022-05-03 11:14:16', NULL, NULL),
(276, 'Morro Bay', 1, '2022-05-03 11:14:16', NULL, NULL),
(277, 'Mount Shasta', 1, '2022-05-03 11:14:16', NULL, NULL),
(278, 'Mountain View', 1, '2022-05-03 11:14:16', NULL, NULL),
(279, 'Murrieta', 1, '2022-05-03 11:14:16', NULL, NULL),
(280, 'Napa', 1, '2022-05-03 11:14:16', NULL, NULL),
(281, 'National City', 1, '2022-05-03 11:14:16', NULL, NULL),
(282, 'Needles', 1, '2022-05-03 11:14:16', NULL, NULL),
(283, 'Nevada City', 1, '2022-05-03 11:14:16', NULL, NULL),
(284, 'Newark', 1, '2022-05-03 11:14:16', NULL, NULL),
(285, 'Newman', 1, '2022-05-03 11:14:16', NULL, NULL),
(286, 'Newport Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(287, 'Norco', 1, '2022-05-03 11:14:16', NULL, NULL),
(288, 'Norwalk', 1, '2022-05-03 11:14:16', NULL, NULL),
(289, 'Novato', 1, '2022-05-03 11:14:16', NULL, NULL),
(290, 'Oakdale', 1, '2022-05-03 11:14:16', NULL, NULL),
(291, 'Oakland', 1, '2022-05-03 11:14:16', NULL, NULL),
(292, 'Oakley', 1, '2022-05-03 11:14:16', NULL, NULL),
(293, 'Oceanside', 1, '2022-05-03 11:14:16', NULL, NULL),
(294, 'Ojai', 1, '2022-05-03 11:14:16', NULL, NULL),
(295, 'Ontario', 1, '2022-05-03 11:14:16', NULL, NULL),
(296, 'Orange', 1, '2022-05-03 11:14:16', NULL, NULL),
(297, 'Orange Cove', 1, '2022-05-03 11:14:16', NULL, NULL),
(298, 'Orinda', 1, '2022-05-03 11:14:16', NULL, NULL),
(299, 'Orland', 1, '2022-05-03 11:14:16', NULL, NULL),
(300, 'Oroville', 1, '2022-05-03 11:14:16', NULL, NULL),
(301, 'Oxnard', 1, '2022-05-03 11:14:16', NULL, NULL),
(302, 'Pacific Grove', 1, '2022-05-03 11:14:16', NULL, NULL),
(303, 'Pacifica', 1, '2022-05-03 11:14:16', NULL, NULL),
(304, 'Palm Desert', 1, '2022-05-03 11:14:16', NULL, NULL),
(305, 'Palm Springs', 1, '2022-05-03 11:14:16', NULL, NULL),
(306, 'Palmdale', 1, '2022-05-03 11:14:16', NULL, NULL),
(307, 'Palo Alto', 1, '2022-05-03 11:14:16', NULL, NULL),
(308, 'Palos Verdes Estates', 1, '2022-05-03 11:14:16', NULL, NULL),
(309, 'Paradise', 1, '2022-05-03 11:14:16', NULL, NULL),
(310, 'Paramount', 1, '2022-05-03 11:14:16', NULL, NULL),
(311, 'Parlier', 1, '2022-05-03 11:14:16', NULL, NULL),
(312, 'Pasadena', 1, '2022-05-03 11:14:16', NULL, NULL),
(313, 'Paso Robles', 1, '2022-05-03 11:14:16', NULL, NULL),
(314, 'Patterson', 1, '2022-05-03 11:14:16', NULL, NULL),
(315, 'Perris', 1, '2022-05-03 11:14:16', NULL, NULL),
(316, 'Petaluma', 1, '2022-05-03 11:14:16', NULL, NULL),
(317, 'Pico Rivera', 1, '2022-05-03 11:14:16', NULL, NULL),
(318, 'Piedmont', 1, '2022-05-03 11:14:16', NULL, NULL),
(319, 'Pinole', 1, '2022-05-03 11:14:16', NULL, NULL),
(320, 'Pismo Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(321, 'Pittsburg', 1, '2022-05-03 11:14:16', NULL, NULL),
(322, 'Placentia', 1, '2022-05-03 11:14:16', NULL, NULL),
(323, 'Placerville', 1, '2022-05-03 11:14:16', NULL, NULL),
(324, 'Pleasant Hill', 1, '2022-05-03 11:14:16', NULL, NULL),
(325, 'Pleasanton', 1, '2022-05-03 11:14:16', NULL, NULL),
(326, 'Plymouth', 1, '2022-05-03 11:14:16', NULL, NULL),
(327, 'Point Arena', 1, '2022-05-03 11:14:16', NULL, NULL),
(328, 'Pomona', 1, '2022-05-03 11:14:16', NULL, NULL),
(329, 'Port Hueneme', 1, '2022-05-03 11:14:16', NULL, NULL),
(330, 'Porterville', 1, '2022-05-03 11:14:16', NULL, NULL),
(331, 'Portola', 1, '2022-05-03 11:14:16', NULL, NULL),
(332, 'Portola Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(333, 'Poway', 1, '2022-05-03 11:14:16', NULL, NULL),
(334, 'Rancho Cordova', 1, '2022-05-03 11:14:16', NULL, NULL),
(335, 'Rancho Cucamonga', 1, '2022-05-03 11:14:16', NULL, NULL),
(336, 'Rancho Mirage', 1, '2022-05-03 11:14:16', NULL, NULL),
(337, 'Rancho Palos Verdes', 1, '2022-05-03 11:14:16', NULL, NULL),
(338, 'Rancho Santa Margarita', 1, '2022-05-03 11:14:16', NULL, NULL),
(339, 'Red Bluff', 1, '2022-05-03 11:14:16', NULL, NULL),
(340, 'Redding', 1, '2022-05-03 11:14:16', NULL, NULL),
(341, 'Redlands', 1, '2022-05-03 11:14:16', NULL, NULL),
(342, 'Redondo Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(343, 'Redwood City', 1, '2022-05-03 11:14:16', NULL, NULL),
(344, 'Reedley', 1, '2022-05-03 11:14:16', NULL, NULL),
(345, 'Rialto', 1, '2022-05-03 11:14:16', NULL, NULL),
(346, 'Richmond', 1, '2022-05-03 11:14:16', NULL, NULL),
(347, 'Ridgecrest', 1, '2022-05-03 11:14:16', NULL, NULL),
(348, 'Rio Dell', 1, '2022-05-03 11:14:16', NULL, NULL),
(349, 'Rio Vista', 1, '2022-05-03 11:14:16', NULL, NULL),
(350, 'Ripon', 1, '2022-05-03 11:14:16', NULL, NULL),
(351, 'Riverbank', 1, '2022-05-03 11:14:16', NULL, NULL),
(352, 'Riverside', 1, '2022-05-03 11:14:16', NULL, NULL),
(353, 'Rocklin', 1, '2022-05-03 11:14:16', NULL, NULL),
(354, 'Rohnert Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(355, 'Rolling Hills', 1, '2022-05-03 11:14:16', NULL, NULL),
(356, 'Rolling Hills Estates', 1, '2022-05-03 11:14:16', NULL, NULL),
(357, 'Rosemead', 1, '2022-05-03 11:14:16', NULL, NULL),
(358, 'Roseville', 1, '2022-05-03 11:14:16', NULL, NULL),
(359, 'Ross', 1, '2022-05-03 11:14:16', NULL, NULL),
(360, 'Sacramento', 1, '2022-05-03 11:14:16', NULL, NULL),
(361, 'Salinas', 1, '2022-05-03 11:14:16', NULL, NULL),
(362, 'San Anselmo', 1, '2022-05-03 11:14:16', NULL, NULL),
(363, 'San Bernardino', 1, '2022-05-03 11:14:16', NULL, NULL),
(364, 'San Bruno', 1, '2022-05-03 11:14:16', NULL, NULL),
(365, 'San Carlos', 1, '2022-05-03 11:14:16', NULL, NULL),
(366, 'San Clemente', 1, '2022-05-03 11:14:16', NULL, NULL),
(367, 'San Diego', 1, '2022-05-03 11:14:16', NULL, NULL),
(368, 'San Dimas', 1, '2022-05-03 11:14:16', NULL, NULL),
(369, 'San Fernando', 1, '2022-05-03 11:14:16', NULL, NULL),
(370, 'San Francisco', 1, '2022-05-03 11:14:16', NULL, NULL),
(371, 'San Gabriel', 1, '2022-05-03 11:14:16', NULL, NULL),
(372, 'San Jacinto', 1, '2022-05-03 11:14:16', NULL, NULL),
(373, 'San Joaquin', 1, '2022-05-03 11:14:16', NULL, NULL),
(374, 'San Jose', 1, '2022-05-03 11:14:16', NULL, NULL),
(375, 'San Juan Bautista', 1, '2022-05-03 11:14:16', NULL, NULL),
(376, 'San Juan Capistrano', 1, '2022-05-03 11:14:16', NULL, NULL),
(377, 'San Leandro', 1, '2022-05-03 11:14:16', NULL, NULL),
(378, 'San Luis Obispo', 1, '2022-05-03 11:14:16', NULL, NULL),
(379, 'San Marcos', 1, '2022-05-03 11:14:16', NULL, NULL),
(380, 'San Marino', 1, '2022-05-03 11:14:16', NULL, NULL),
(381, 'San Mateo', 1, '2022-05-03 11:14:16', NULL, NULL),
(382, 'San Pablo', 1, '2022-05-03 11:14:16', NULL, NULL),
(383, 'San Rafael', 1, '2022-05-03 11:14:16', NULL, NULL),
(384, 'San Ramon', 1, '2022-05-03 11:14:16', NULL, NULL),
(385, 'Sand City', 1, '2022-05-03 11:14:16', NULL, NULL),
(386, 'Sanger', 1, '2022-05-03 11:14:16', NULL, NULL),
(387, 'Santa Ana', 1, '2022-05-03 11:14:16', NULL, NULL),
(388, 'Santa Barbara', 1, '2022-05-03 11:14:16', NULL, NULL),
(389, 'Santa Clara', 1, '2022-05-03 11:14:16', NULL, NULL),
(390, 'Santa Clarita', 1, '2022-05-03 11:14:16', NULL, NULL),
(391, 'Santa Cruz', 1, '2022-05-03 11:14:16', NULL, NULL),
(392, 'Santa Fe Springs', 1, '2022-05-03 11:14:16', NULL, NULL),
(393, 'Santa Maria', 1, '2022-05-03 11:14:16', NULL, NULL),
(394, 'Santa Monica', 1, '2022-05-03 11:14:16', NULL, NULL),
(395, 'Santa Paula', 1, '2022-05-03 11:14:16', NULL, NULL),
(396, 'Santa Rosa', 1, '2022-05-03 11:14:16', NULL, NULL),
(397, 'Santee', 1, '2022-05-03 11:14:16', NULL, NULL),
(398, 'Saratoga', 1, '2022-05-03 11:14:16', NULL, NULL),
(399, 'Sausalito', 1, '2022-05-03 11:14:16', NULL, NULL),
(400, 'Scotts Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(401, 'Seal Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(402, 'Seaside', 1, '2022-05-03 11:14:16', NULL, NULL),
(403, 'Sebastopol', 1, '2022-05-03 11:14:16', NULL, NULL),
(404, 'Selma', 1, '2022-05-03 11:14:16', NULL, NULL),
(405, 'Shafter', 1, '2022-05-03 11:14:16', NULL, NULL),
(406, 'Shasta Lake', 1, '2022-05-03 11:14:16', NULL, NULL),
(407, 'Sierra Madre', 1, '2022-05-03 11:14:16', NULL, NULL),
(408, 'Signal Hill', 1, '2022-05-03 11:14:16', NULL, NULL),
(409, 'Simi Valley', 1, '2022-05-03 11:14:16', NULL, NULL),
(410, 'Solana Beach', 1, '2022-05-03 11:14:16', NULL, NULL),
(411, 'Soledad', 1, '2022-05-03 11:14:16', NULL, NULL),
(412, 'Solvang', 1, '2022-05-03 11:14:16', NULL, NULL),
(413, 'Sonoma', 1, '2022-05-03 11:14:16', NULL, NULL),
(414, 'Sonora', 1, '2022-05-03 11:14:16', NULL, NULL),
(415, 'South El Monte', 1, '2022-05-03 11:14:16', NULL, NULL),
(416, 'South Gate', 1, '2022-05-03 11:14:16', NULL, NULL),
(417, 'South Lake Tahoe', 1, '2022-05-03 11:14:16', NULL, NULL),
(418, 'South Pasadena', 1, '2022-05-03 11:14:16', NULL, NULL),
(419, 'South San Francisco', 1, '2022-05-03 11:14:16', NULL, NULL),
(420, 'St. Helena', 1, '2022-05-03 11:14:16', NULL, NULL),
(421, 'Stanton', 1, '2022-05-03 11:14:16', NULL, NULL),
(422, 'Stockton', 1, '2022-05-03 11:14:16', NULL, NULL),
(423, 'Suisun City', 1, '2022-05-03 11:14:16', NULL, NULL),
(424, 'Sunnyvale', 1, '2022-05-03 11:14:16', NULL, NULL),
(425, 'Susanville', 1, '2022-05-03 11:14:16', NULL, NULL),
(426, 'Sutter Creek', 1, '2022-05-03 11:14:16', NULL, NULL),
(427, 'Taft', 1, '2022-05-03 11:14:16', NULL, NULL),
(428, 'Tehachapi', 1, '2022-05-03 11:14:16', NULL, NULL),
(429, 'Tehama', 1, '2022-05-03 11:14:16', NULL, NULL),
(430, 'Temecula', 1, '2022-05-03 11:14:16', NULL, NULL),
(431, 'Temple City', 1, '2022-05-03 11:14:16', NULL, NULL),
(432, 'Thousand Oaks', 1, '2022-05-03 11:14:16', NULL, NULL),
(433, 'Tiburon', 1, '2022-05-03 11:14:16', NULL, NULL),
(434, 'Torrance', 1, '2022-05-03 11:14:16', NULL, NULL),
(435, 'Tracy', 1, '2022-05-03 11:14:16', NULL, NULL),
(436, 'Trinidad', 1, '2022-05-03 11:14:16', NULL, NULL),
(437, 'Truckee', 1, '2022-05-03 11:14:16', NULL, NULL),
(438, 'Tulare', 1, '2022-05-03 11:14:16', NULL, NULL),
(439, 'Tulelake', 1, '2022-05-03 11:14:16', NULL, NULL),
(440, 'Turlock', 1, '2022-05-03 11:14:16', NULL, NULL),
(441, 'Tustin', 1, '2022-05-03 11:14:16', NULL, NULL),
(442, 'Twentynine Palms', 1, '2022-05-03 11:14:16', NULL, NULL),
(443, 'Ukiah', 1, '2022-05-03 11:14:16', NULL, NULL),
(444, 'Union City', 1, '2022-05-03 11:14:16', NULL, NULL),
(445, 'Upland', 1, '2022-05-03 11:14:16', NULL, NULL),
(446, 'Vacaville', 1, '2022-05-03 11:14:16', NULL, NULL),
(447, 'Vallejo', 1, '2022-05-03 11:14:16', NULL, NULL),
(448, 'Ventura', 1, '2022-05-03 11:14:16', NULL, NULL),
(449, 'Vernon', 1, '2022-05-03 11:14:16', NULL, NULL),
(450, 'Victorville', 1, '2022-05-03 11:14:16', NULL, NULL),
(451, 'Villa Park', 1, '2022-05-03 11:14:16', NULL, NULL),
(452, 'Visalia', 1, '2022-05-03 11:14:16', NULL, NULL),
(453, 'Vista', 1, '2022-05-03 11:14:16', NULL, NULL),
(454, 'Walnut', 1, '2022-05-03 11:14:16', NULL, NULL),
(455, 'Walnut Creek', 1, '2022-05-03 11:14:16', NULL, NULL),
(456, 'Wasco', 1, '2022-05-03 11:14:16', NULL, NULL),
(457, 'Waterford', 1, '2022-05-03 11:14:16', NULL, NULL),
(458, 'Watsonville', 1, '2022-05-03 11:14:16', NULL, NULL),
(459, 'Weed', 1, '2022-05-03 11:14:16', NULL, NULL),
(460, 'West Covina', 1, '2022-05-03 11:14:16', NULL, NULL),
(461, 'West Hollywood', 1, '2022-05-03 11:14:16', NULL, NULL),
(462, 'West Sacramento', 1, '2022-05-03 11:14:16', NULL, NULL),
(463, 'Westlake Village', 1, '2022-05-03 11:14:16', NULL, NULL),
(464, 'Westminster', 1, '2022-05-03 11:14:16', NULL, NULL),
(465, 'Westmorland', 1, '2022-05-03 11:14:16', NULL, NULL),
(466, 'Wheatland', 1, '2022-05-03 11:14:16', NULL, NULL),
(467, 'Whittier', 1, '2022-05-03 11:14:16', NULL, NULL),
(468, 'Wildomar', 1, '2022-05-03 11:14:16', NULL, NULL),
(469, 'Williams', 1, '2022-05-03 11:14:16', NULL, NULL),
(470, 'Willits', 1, '2022-05-03 11:14:16', NULL, NULL),
(471, 'Willows', 1, '2022-05-03 11:14:16', NULL, NULL),
(472, 'Windsor', 1, '2022-05-03 11:14:16', NULL, NULL),
(473, 'Winters', 1, '2022-05-03 11:14:16', NULL, NULL),
(474, 'Woodlake', 1, '2022-05-03 11:14:16', NULL, NULL),
(475, 'Woodland', 1, '2022-05-03 11:14:16', NULL, NULL),
(476, 'Woodside', 1, '2022-05-03 11:14:16', NULL, NULL),
(477, 'Yorba Linda', 1, '2022-05-03 11:14:16', NULL, NULL),
(478, 'Yountville', 1, '2022-05-03 11:14:16', NULL, NULL),
(479, 'Yreka', 1, '2022-05-03 11:14:16', NULL, NULL),
(480, 'Yuba City', 1, '2022-05-03 11:14:16', NULL, NULL),
(481, 'Yucaipa', 1, '2022-05-03 11:14:16', NULL, NULL),
(482, 'Yucca Valley', 1, '2022-05-03 11:14:16', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `commission`
--

DROP TABLE IF EXISTS `commission`;
CREATE TABLE IF NOT EXISTS `commission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `commission` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `commission`
--

INSERT INTO `commission` (`id`, `commission`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 7, NULL, '2022-05-10 13:32:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
CREATE TABLE IF NOT EXISTS `contactus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(300) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `description` varchar(300) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `descriptiontable`
--

DROP TABLE IF EXISTS `descriptiontable`;
CREATE TABLE IF NOT EXISTS `descriptiontable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `description` varchar(400) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `discounts`
--

DROP TABLE IF EXISTS `discounts`;
CREATE TABLE IF NOT EXISTS `discounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `min_order_value` varchar(255) DEFAULT NULL,
  `max_discount` varchar(255) DEFAULT NULL,
  `coupon` varchar(255) DEFAULT NULL,
  `percentage` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `discounts`
--

INSERT INTO `discounts` (`id`, `user_id`, `min_order_value`, `max_discount`, `coupon`, `percentage`, `start_date`, `end_date`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, '200', '20', 'RJSG12', '10', '2022-05-24', '2022-06-24', 1, '2022-05-24 12:37:24', '2022-06-01 12:23:02', NULL),
(2, 1, '500', '100', 'RJSG658', '20', '2022-05-31', '2022-07-01', 1, '2022-06-01 12:23:31', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE IF NOT EXISTS `email_templates` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `email_templates`
--

INSERT INTO `email_templates` (`id`, `title`, `slug`, `content`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Quibusdam cupiditate reprehenderit consequatur quibusdam voluptas.', 'quibusdam-cupiditate-reprehenderit-consequatur-quibusdam-voluptas', 'Sed sed doloribus non maiores quis ipsum corrupti. Excepturi quo consequuntur amet pariatur quam dolorem nulla aperiam. Corrupti soluta consequatur sunt consequuntur facere incidunt blanditiis. Est sapiente reiciendis eum vel eveniet voluptas.', 0, 1, NULL, '2021-04-16 03:38:00', NULL, NULL),
(2, 'Consectetur ut dolor ipsa nesciunt.', 'consectetur-ut-dolor-ipsa-nesciunt', 'Nihil expedita occaecati laudantium corrupti ipsam sit pariatur et. Quo dolorem quia est non dolores incidunt dolorum optio. Numquam ut voluptates consequatur temporibus.', 0, 2, NULL, '2021-04-13 13:51:52', NULL, NULL),
(3, 'Consequatur nam amet fuga.', 'consequatur-nam-amet-fuga', 'Ducimus nobis consequatur in veritatis in architecto nihil. Est doloribus et quia ab perferendis. Perferendis sit dolor eaque non omnis.', 1, 1, NULL, '2021-04-15 06:38:49', NULL, NULL),
(4, 'Et ex occaecati est.', 'et-ex-occaecati-est', 'Totam voluptates velit doloribus aliquam et cum. Aut error accusamus quasi ipsum minima et voluptatum. Ut nihil vero dolore fugit. Adipisci et quod veritatis velit veniam error in dolores. Ut tenetur voluptatibus nulla esse.', 1, 1, NULL, '2021-04-12 19:30:04', NULL, NULL),
(5, 'Tenetur possimus corporis ad nostrum.', 'tenetur-possimus-corporis-ad-nostrum', 'Sed quam doloribus sint eius sint esse. Corporis repellendus mollitia sint quasi in iure ullam est.', 0, 2, NULL, '2021-04-12 10:31:52', NULL, NULL),
(6, 'Velit mollitia vel sint consectetur.', 'velit-mollitia-vel-sint-consectetur', 'Unde numquam aut excepturi ut dolor. Ad repellat voluptas ducimus. Sint beatae quis et ipsam vitae at.', 0, 1, NULL, '2021-04-21 05:17:27', NULL, NULL),
(7, 'Et eum architecto.', 'et-eum-architecto', 'Esse quos nisi voluptatem voluptate officiis natus natus. Maxime sit autem quis facere in modi. Est magnam quos et et qui officiis perferendis. Sint nemo nisi quia qui.', 1, 2, NULL, '2021-04-13 13:35:31', NULL, NULL),
(8, 'Sed repudiandae unde eveniet sapiente.', 'sed-repudiandae-unde-eveniet-sapiente', 'Est quam laudantium quam ea dolor ut molestiae veniam. Culpa quis et eligendi cum. Et itaque quasi ut eaque ipsa quia.', 1, 1, NULL, '2021-04-15 21:08:57', NULL, NULL),
(9, 'Et rerum et ut.', 'et-rerum-et-ut', 'Quasi autem ea quas aperiam temporibus. Eos non consequatur autem aut autem quia. Maxime est fugit aut nisi sit quia. Fugit facilis reprehenderit sint odio natus eius.', 1, 1, NULL, '2021-04-12 10:42:24', NULL, NULL),
(10, 'Vel ea repudiandae est.', 'vel-ea-repudiandae-est', 'Deleniti illum ut minus at temporibus explicabo consequatur. Soluta voluptatem aut odio sequi non. Perferendis blanditiis incidunt voluptatum officiis quidem placeat optio. Quaerat et perspiciatis asperiores aliquid.', 1, 2, NULL, '2021-04-13 10:50:38', NULL, NULL),
(11, 'Delectus facilis fugiat in eaque.', 'delectus-facilis-fugiat-in-eaque', 'Molestiae id voluptas impedit minus. Dolor labore esse rerum sed deserunt. Cupiditate repellat cumque numquam nam rerum necessitatibus.', 0, 2, NULL, '2021-04-21 05:38:47', NULL, NULL),
(12, 'Quis architecto eum ea.', 'quis-architecto-eum-ea', 'Qui quae culpa commodi ducimus et. Dolores ratione quo quaerat nostrum ea. Quas quasi dolorem est architecto sit tenetur quis. Quidem dolorem praesentium minima molestiae temporibus eveniet earum et.', 0, 2, NULL, '2021-04-18 11:51:25', NULL, NULL),
(13, 'Minima magnam numquam voluptas et.', 'minima-magnam-numquam-voluptas-et', 'Molestiae ducimus qui hic eius. Dolore temporibus rerum ipsum facilis autem. Magni cumque aspernatur fugit unde et. Pariatur laboriosam eos repellendus amet soluta. Ea repudiandae et quod saepe qui deserunt.', 1, 2, NULL, '2021-04-19 07:08:21', NULL, NULL),
(14, 'Est voluptatem eveniet optio quod debitis.', 'est-voluptatem-eveniet-optio-quod-debitis', 'Laudantium maxime beatae amet porro. Deserunt iusto voluptatem nihil explicabo ipsa.', 0, 1, NULL, '2021-04-21 10:13:46', NULL, NULL),
(15, 'Suscipit totam autem.', 'suscipit-totam-autem', 'Quod molestias eligendi omnis dolorem. Id aspernatur laudantium id veritatis dolores optio. Inventore itaque optio adipisci ut soluta a vel.', 0, 2, NULL, '2021-04-16 12:09:00', NULL, NULL),
(16, 'Quae commodi et.', 'quae-commodi-et', 'Esse id et minus recusandae sint. Ut omnis occaecati laborum corporis quas eius sequi.', 1, 1, NULL, '2021-04-19 19:53:11', NULL, NULL),
(17, 'Voluptas et aut qui beatae.', 'voluptas-et-aut-qui-beatae', 'Sed et amet voluptas neque quis. Qui minus corporis doloremque fugit. Eius neque facilis praesentium id mollitia aspernatur et.', 0, 1, NULL, '2021-04-15 04:34:22', NULL, NULL),
(18, 'Fugiat deserunt eos molestias voluptas.', 'fugiat-deserunt-eos-molestias-voluptas', 'Nobis aut amet quas id. Enim esse quae accusamus minima.', 0, 2, NULL, '2021-04-19 22:48:41', NULL, NULL),
(19, 'Deleniti vitae hic ut.', 'deleniti-vitae-hic-ut', 'Aut id commodi molestiae eum accusamus. Mollitia sequi voluptas sed et beatae omnis. Doloremque aut aut dolorem harum. Aspernatur quaerat dolores eligendi modi molestiae.', 1, 2, NULL, '2021-04-16 03:50:46', NULL, NULL),
(20, 'Reprehenderit consequatur consequatur quam.', 'reprehenderit-consequatur-consequatur-quam', 'Explicabo et quia commodi necessitatibus totam earum. Commodi doloremque sint iusto aut voluptatem culpa. Unde itaque dicta sunt perferendis eos possimus cum.', 1, 1, NULL, '2021-04-20 01:48:15', NULL, NULL),
(21, 'Sapiente praesentium sed rerum ipsam.', 'sapiente-praesentium-sed-rerum-ipsam', 'Atque odit est necessitatibus eius provident eos. Dolore repellat atque sit aut quod dicta non. Tenetur reprehenderit rerum unde et. Quaerat repellat pariatur voluptatem repellat et adipisci aspernatur. Deserunt quis nobis perferendis et.', 1, 2, NULL, '2021-04-18 18:01:28', NULL, NULL),
(22, 'Consequuntur autem molestias.', 'consequuntur-autem-molestias', 'Autem voluptate ducimus eveniet. Ut numquam ducimus reprehenderit. Nisi dolorum quas fuga aperiam assumenda.', 1, 2, NULL, '2021-04-13 08:00:38', NULL, NULL),
(23, 'Esse sunt sed et.', 'esse-sunt-sed-et', 'Veritatis suscipit repudiandae ut omnis et aliquid. Rem provident et praesentium dolorem enim est est. Reiciendis vel tempore in magnam doloribus ab eius.', 1, 1, NULL, '2021-04-20 23:10:54', NULL, NULL),
(24, 'Nostrum nihil dolorem dolor.', 'nostrum-nihil-dolorem-dolor', 'Consequatur consequatur ut velit a. Quod necessitatibus eos vero sequi tempora eaque et quae. Velit ea ex tempora sit voluptatem.', 0, 2, NULL, '2021-04-13 13:41:51', NULL, NULL),
(25, 'Veritatis ea quaerat dolores.', 'veritatis-ea-quaerat-dolores', 'Magni corporis quia iste illum culpa. Quo magni deleniti dolor voluptatibus ea. Asperiores earum quis cupiditate iure veritatis. Quos corrupti dolore expedita facilis omnis in distinctio. Harum nostrum molestias enim eum dolorum.', 1, 1, NULL, '2021-04-13 17:49:25', NULL, NULL),
(26, 'Quis ex sit sequi.', 'quis-ex-sit-sequi', 'Maiores expedita cum aut est voluptatem voluptas molestiae. Ducimus quia mollitia omnis. Voluptate illum rerum repellendus aut maxime. Id tenetur vel est vitae itaque expedita rerum.', 1, 2, NULL, '2021-04-16 06:42:48', NULL, NULL),
(27, 'Reiciendis ratione quam ut aspernatur consequatur.', 'reiciendis-ratione-quam-ut-aspernatur-consequatur', 'Qui cumque expedita rerum doloribus. Quasi id placeat quis. Culpa nihil molestias aliquid consectetur aut.', 0, 1, NULL, '2021-04-15 17:39:57', NULL, NULL),
(28, 'Tempore omnis architecto excepturi quam.', 'tempore-omnis-architecto-excepturi-quam', 'Placeat adipisci aut blanditiis facilis iusto incidunt et. Laboriosam vitae quibusdam et non ad a qui. Eius nulla enim dolore omnis eveniet excepturi.', 1, 1, NULL, '2021-04-20 14:43:23', NULL, NULL),
(29, 'Est deleniti aliquid repellat possimus ut.', 'est-deleniti-aliquid-repellat-possimus-ut', 'Accusamus praesentium numquam sed est accusantium ea voluptas. Qui perferendis quod provident maxime et qui a. Asperiores ea deleniti voluptatem maxime deserunt.', 0, 1, NULL, '2021-04-15 16:46:44', NULL, NULL),
(30, 'Perspiciatis qui dignissimos voluptatem maiores modi.', 'perspiciatis-qui-dignissimos-voluptatem-maiores-modi', 'Libero ipsam soluta nihil aut culpa ut quod qui. In maiores impedit laudantium rem quis. Consectetur sed libero consequatur voluptates totam.', 0, 2, NULL, '2021-04-15 17:23:41', NULL, NULL),
(31, 'Et ratione laborum omnis.', 'et-ratione-laborum-omnis', 'Illo libero culpa quae deleniti. Repudiandae illo mollitia temporibus. Nihil vel est nemo rerum amet.', 0, 2, NULL, '2021-04-14 17:55:20', NULL, NULL),
(32, 'Adipisci ea labore.', 'adipisci-ea-labore', 'Et occaecati expedita voluptatem unde. Similique possimus animi excepturi aliquid quod quisquam commodi. Et facilis eaque corrupti.', 0, 1, NULL, '2021-04-15 12:56:44', NULL, NULL),
(33, 'Fugit voluptas hic sed omnis sit.', 'fugit-voluptas-hic-sed-omnis-sit', 'Commodi ut temporibus amet omnis molestias autem. Sunt vitae molestiae id dolore. Ex non sint aut corrupti. Est labore alias nulla corrupti quia numquam cum veniam.', 1, 1, NULL, '2021-04-19 03:02:36', NULL, NULL),
(34, 'Sed qui a nihil eum repellendus.', 'sed-qui-a-nihil-eum-repellendus', 'Assumenda odit molestiae perspiciatis quis. Quam qui ab quo nulla neque. Accusamus velit blanditiis hic voluptates. Sit nemo vitae ipsa. Maxime voluptas quidem velit quasi iusto quis perspiciatis at.', 1, 1, NULL, '2021-04-21 02:08:20', NULL, NULL),
(35, 'Ut praesentium vitae facere expedita.', 'ut-praesentium-vitae-facere-expedita', 'Nostrum quasi aliquid earum officia voluptatem natus dolor. Qui corporis voluptatem ex incidunt.', 1, 2, NULL, '2021-04-14 00:46:32', NULL, NULL),
(36, 'Ex aliquam repudiandae similique nobis doloremque.', 'ex-aliquam-repudiandae-similique-nobis-doloremque', 'Dicta atque ratione praesentium magni magnam alias et. Aliquid illum ad voluptas nobis sapiente consequatur doloribus. Pariatur sed qui delectus minus enim dolor dolore est.', 0, 2, NULL, '2021-04-20 07:08:19', NULL, NULL),
(37, 'Rerum enim dolor minus et quia.', 'rerum-enim-dolor-minus-et-quia', 'Molestiae nihil aspernatur esse est. Architecto ea odio sit non eos ut ea.', 1, 1, NULL, '2021-04-19 05:28:34', NULL, NULL),
(38, 'Optio impedit vero inventore aut.', 'optio-impedit-vero-inventore-aut', 'Illum in illo laudantium blanditiis sunt magni reprehenderit enim. Nemo aut sapiente voluptatem nihil magnam. Id et eos laudantium consectetur sit.', 1, 1, NULL, '2021-04-15 21:02:59', NULL, NULL),
(39, 'Mollitia voluptatem nemo.', 'mollitia-voluptatem-nemo', 'Enim repudiandae laborum aut suscipit a. Sed sit veniam nobis et ut. Ullam aut corrupti voluptatem pariatur excepturi. Ad aut nesciunt amet corrupti quibusdam fuga sint.', 1, 1, NULL, '2021-04-18 07:04:54', NULL, NULL),
(40, 'Accusamus molestias placeat.', 'accusamus-molestias-placeat', 'Sit ullam et voluptatem aperiam commodi. Enim error pariatur nulla animi sapiente. Vitae vel facere fugit.', 0, 2, NULL, '2021-04-17 14:13:38', NULL, NULL),
(41, 'Totam commodi distinctio incidunt voluptatem.', 'totam-commodi-distinctio-incidunt-voluptatem', 'Quas nobis animi rerum quas maxime. Quo accusantium commodi enim ut necessitatibus qui qui. Modi porro molestiae aperiam vel.', 0, 2, NULL, '2021-04-18 22:16:06', NULL, NULL),
(42, 'Ad rerum quaerat nostrum.', 'ad-rerum-quaerat-nostrum', 'Dolorem qui aliquam ad excepturi. Voluptatem quia perspiciatis quos. Vitae omnis rem at facilis omnis ut.', 0, 1, NULL, '2021-04-15 19:24:10', NULL, NULL),
(43, 'Deserunt non hic.', 'deserunt-non-hic', 'Nisi officiis quia nostrum ex tempore. Pariatur consequatur repellendus est nisi. Autem deserunt minus rerum ad. Odio vel cum est vel libero. Amet doloremque sed excepturi ut.', 1, 2, NULL, '2021-04-17 02:00:01', NULL, NULL),
(44, 'Sit pariatur odit voluptatibus tempora aut.', 'sit-pariatur-odit-voluptatibus-tempora-aut', 'Facilis quia iste nihil assumenda nesciunt qui. Vitae est mollitia quasi praesentium.', 0, 1, NULL, '2021-04-17 12:17:05', NULL, NULL),
(45, 'Voluptatem aperiam a qui aut in.', 'voluptatem-aperiam-a-qui-aut-in', 'Dolorum nostrum ut impedit praesentium aliquid dolor. Incidunt a sed nesciunt ex. Ullam quisquam dolor ducimus dolores natus velit labore. Tenetur quos odit repudiandae enim et. Ratione voluptas est dolore exercitationem.', 1, 1, NULL, '2021-04-14 04:31:47', NULL, NULL),
(46, 'Earum architecto vel.', 'earum-architecto-vel', 'Expedita temporibus perspiciatis commodi qui ut in. Consequuntur eos minus doloribus autem. Quisquam atque id sequi.', 0, 1, NULL, '2021-04-20 09:20:55', NULL, NULL),
(47, 'Itaque atque est iusto vero.', 'itaque-atque-est-iusto-vero', 'Eaque eum ut commodi aspernatur. Cupiditate non sit suscipit doloremque autem. Adipisci voluptatem minus aspernatur. Optio dolorem soluta excepturi dolorum mollitia ducimus nisi magni. Minima magni ducimus earum sit sint et.', 1, 2, NULL, '2021-04-20 13:35:07', NULL, NULL),
(48, 'Occaecati voluptatibus maiores ipsum tenetur.', 'occaecati-voluptatibus-maiores-ipsum-tenetur', 'Non est sed accusamus. Dolor possimus sunt ea earum sunt. Magnam deleniti commodi libero et ut est et. Facilis molestiae non doloribus molestias consequatur dolore.', 1, 2, NULL, '2021-04-16 17:31:02', NULL, NULL),
(49, 'Facilis fuga saepe.', 'facilis-fuga-saepe', 'Et eveniet eveniet temporibus voluptatem et est vero. Et vitae dignissimos quia. Eos voluptatibus non a veniam amet.', 0, 2, NULL, '2021-04-12 21:54:29', NULL, NULL),
(50, 'Harum similique illum veniam qui.', 'harum-similique-illum-veniam-qui', 'Fugit et vero quisquam magni eos amet repellat. Et tenetur est ipsa.', 0, 2, NULL, '2021-04-19 21:18:45', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `faqs`
--

DROP TABLE IF EXISTS `faqs`;
CREATE TABLE IF NOT EXISTS `faqs` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `question` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `faqs`
--

INSERT INTO `faqs` (`id`, `question`, `answer`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Officia odit rerum dolorem quia nostrum.', 'Eos magnam ipsam dolore velit consectetur omnis dolores consectetur. Eos eaque ut perspiciatis ad. Voluptatem rerum ut nihil nisi.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(2, 'Magnam non est facilis.', 'Accusamus adipisci porro et quisquam consequatur quidem dolore. Commodi magnam minus reiciendis esse. Maiores amet rerum nam modi voluptatem similique. Quaerat illo nesciunt magni at.', 0, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(3, 'Sunt illum explicabo nihil eum totam non fuga.', 'Molestias velit cum at assumenda aliquid. Accusamus et sunt blanditiis dolor quos ab quis. Non deleniti delectus voluptas non ad mollitia. Magni cum itaque atque iusto quia et.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'Quia aut accusantium consequuntur quisquam nemo.', 'Excepturi voluptatem tenetur quisquam quisquam vero nihil. Explicabo tempore aut repudiandae accusantium. Et quas earum numquam molestiae porro molestiae tenetur. Maxime eum laboriosam veritatis odio magnam voluptatem.', 0, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(5, 'Impedit sint esse sapiente et.', 'Ut odio voluptas quaerat officia. Laudantium odit nihil autem. Iste incidunt placeat libero aut voluptas earum.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(6, 'Eos expedita voluptates molestias quo necessitatibus enim.', 'Aliquid veniam omnis et reprehenderit. Debitis est quo porro temporibus harum sapiente. Ullam minima quasi quidem repellendus ut deserunt quis.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(7, 'Rerum laborum nam laborum et aliquid voluptatum impedit et.', 'Odit cum debitis adipisci consequatur labore. Non ea ullam debitis sint. Earum quasi voluptatem error aspernatur eos quia.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(8, 'Quia ab rerum molestias voluptatem eos.', 'Numquam cum illo velit qui suscipit. Voluptatum voluptates omnis cumque esse nulla et sed. Placeat quae eaque tenetur fugiat.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(9, 'Ex quas quia voluptatem et cupiditate temporibus.', 'Consequatur fugiat nostrum aliquam vero incidunt eligendi qui. Voluptas autem minima ipsam accusantium est. Aut ut incidunt voluptatem qui at sequi.', 1, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(10, 'Quod incidunt possimus atque optio vel.', 'Tempore minima aliquam hic. Enim quidem asperiores rem id. Quasi cumque modi optio quos incidunt. Maxime alias labore aliquid rem architecto voluptatem est. Eos veniam nihil a similique.', 0, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

DROP TABLE IF EXISTS `favorites`;
CREATE TABLE IF NOT EXISTS `favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `seller_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 8, 9, '2022-05-06 09:27:12', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `gift_cards`
--

DROP TABLE IF EXISTS `gift_cards`;
CREATE TABLE IF NOT EXISTS `gift_cards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `code` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `guest_user`
--

DROP TABLE IF EXISTS `guest_user`;
CREATE TABLE IF NOT EXISTS `guest_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guest_user`
--

INSERT INTO `guest_user` (`id`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '253258', '2022-05-16 04:29:54', NULL, NULL),
(2, '999783', '2022-05-17 07:02:23', NULL, NULL),
(3, '333252', '2022-05-17 08:40:06', NULL, NULL),
(4, '755218', '2022-05-19 04:53:10', NULL, NULL),
(5, '668476', '2022-05-24 09:51:48', NULL, NULL),
(6, '633773', '2022-05-26 11:09:10', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `help_supports`
--

DROP TABLE IF EXISTS `help_supports`;
CREATE TABLE IF NOT EXISTS `help_supports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ledgers`
--

DROP TABLE IF EXISTS `ledgers`;
CREATE TABLE IF NOT EXISTS `ledgers` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `recordable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recordable_id` bigint(20) UNSIGNED NOT NULL,
  `context` tinyint(3) UNSIGNED NOT NULL,
  `event` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `modified` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pivot` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `extra` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` text COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ledgers_recordable_type_recordable_id_index` (`recordable_type`,`recordable_id`),
  KEY `ledgers_user_id_user_type_index` (`user_id`,`user_type`)
) ENGINE=MyISAM AUTO_INCREMENT=108 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ledgers`
--

INSERT INTO `ledgers` (`id`, `user_type`, `user_id`, `recordable_type`, `recordable_id`, `context`, `event`, `properties`, `modified`, `pivot`, `extra`, `url`, `ip_address`, `user_agent`, `signature`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-03-15 13:02:36\",\"last_login_ip\":\"110.235.219.137\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"jbdAvxDf1u8yCftERRuHtOrn91QvdfzuoWAjSqnXb7E4vwqMSt5XeSbIcGmT\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-03-15 13:02:36\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/logout', '110.235.219.137', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0/9uiP7EnX-09', 'babf84d329742df56af03ebdf1f95a70f551c5f99bf8263b9d2099e89b96132ceb7e5dffaa13ef8e84d690e8f1244a43e5a0480166b0107d2c8d3f22b33e0909', '2022-03-15 13:26:52', '2022-03-15 13:26:52'),
(2, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-03-15 13:27:02\",\"last_login_ip\":\"110.235.219.137\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"jbdAvxDf1u8yCftERRuHtOrn91QvdfzuoWAjSqnXb7E4vwqMSt5XeSbIcGmT\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-03-15 13:27:02\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.137', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0/9uiP7EnX-09', '009d18d6ab85a39cd1cd76b5b55afc993fc14c5560477ef3f0e786740db39b161421940412db73a44d74d7e081c65f1db9559026e92f3b30f33168901e0c2f57', '2022-03-15 13:27:02', '2022-03-15 13:27:02'),
(3, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-03-15 13:27:02\",\"last_login_ip\":\"110.235.219.137\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"PidRxf7GY24mr8UTbti5NyaOstgUQJkYao1jKInf0Q8hz2kEwrMVLGH6MXgH\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-03-15 13:27:02\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/logout', '110.235.219.137', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:98.0) Gecko/20100101 Firefox/98.0/9uiP7EnX-09', '3299c25374742f71501decb4bab8ef35af507f86d927e5c3edc10368d3c0941f5d280e57200077b9272b1af8a24aeb6bb63dd3f05dd8be20eca5e632e116efc9', '2022-03-15 13:27:49', '2022-03-15 13:27:49'),
(4, NULL, NULL, 'App\\Models\\Auth\\User', 2, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Narendra\",\"last_name\":\"Singh\",\"username\":\"narendra\",\"email\":\"\",\"mobile_no\":\"9928394640\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$lol0XginMJpUbQm7SwCmy.CoiIHT8Gq20jXgxtTxRpL1C9oXU0H1K\",\"confirmation_code\":\"484424c0441533ef3dbfc9fa7c1893c0\",\"uuid\":\"533da588-3465-46eb-884e-143dab05d87b\",\"updated_at\":\"2022-03-16 13:53:09\",\"created_at\":\"2022-03-16 13:53:09\",\"id\":2}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.137', 'okhttp/4.9.1', '52fadae193ed7c312458dd75d8408d9139c63f33deff964f38f5e4571ca6f132f9c73629482fb9cc7581dc93f41cdc877207a3c003f286131937dbf04415cfca', '2022-03-16 13:53:09', '2022-03-16 13:53:09'),
(5, NULL, NULL, 'App\\Models\\Auth\\User', 2, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Narendra\",\"last_name\":\"Singh\",\"username\":\"narendra\",\"email\":\"\",\"mobile_no\":\"9928394640\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$lol0XginMJpUbQm7SwCmy.CoiIHT8Gq20jXgxtTxRpL1C9oXU0H1K\",\"confirmation_code\":\"484424c0441533ef3dbfc9fa7c1893c0\",\"uuid\":\"533da588-3465-46eb-884e-143dab05d87b\",\"updated_at\":\"2022-03-16 13:53:09\",\"created_at\":\"2022-03-16 13:53:09\",\"id\":2}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":2,\"role_id\":3}]}', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.137', 'okhttp/4.9.1', '44a9f0c89997abcb09bc1ab9a8428873ab0c782fde4f236ae5fb724f9a181345c8e07fa65c35cff5c52447cb53c5cc70b1cb7339a4040a9c3c9cab34d54081cc', '2022-03-16 13:53:09', '2022-03-16 13:53:09'),
(6, NULL, NULL, 'App\\Models\\Auth\\User', 3, 4, 'created', '{\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":false,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"updated_at\":\"2022-04-20 17:24:31\",\"created_at\":\"2022-04-20 17:24:31\",\"id\":3}', '[\"first_name\",\"last_name\",\"email\",\"password\",\"confirmation_code\",\"confirmed\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/register', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '1066ed4859827732ddf7be8aab9ebaad9d10f5d27f937f5aee33e7e6fb71ce63d87594b198f79b9c7a497a20776d7ecf93968badb9b60e3af4578df0a907753c', '2022-04-20 17:24:31', '2022-04-20 17:24:31'),
(7, NULL, NULL, 'App\\Models\\Auth\\User', 3, 4, 'attached', '{\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":false,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"updated_at\":\"2022-04-20 17:24:31\",\"created_at\":\"2022-04-20 17:24:31\",\"id\":3}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":3,\"role_id\":3}]}', '[]', 'http://design.smartitway.com/ohcut/public/register', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', 'f61924d8388ad84b8ba7fcbe92720393ed019568116a09636bcb25fa7e8073c323685ea511185d9b1d7df318e40cbbe1e87819eb8a01549b925a7b5c9e804761', '2022-04-20 17:24:31', '2022-04-20 17:24:31'),
(8, 'App\\Models\\Auth\\User', 3, 'App\\Models\\Auth\\User', 3, 4, 'updated', '{\"id\":3,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"user_group_id\":0,\"username\":null,\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":0,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"kMbLp1gCVS9SIPJGRgiXcTA0ZWOKQEUD5vIc55rWk5fK9ZSbQ3tymqnJnGX0\",\"created_at\":\"2022-04-20 17:24:31\",\"updated_at\":\"2022-04-20 17:24:31\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '018a6717a7e2f54a4649af64c786cafa155500e494a3585f8d26b751bbd0611e693149d5f42790d17dcc8e4b2581c54135ef1f22f1b05199eb46a0432e4a7bd8', '2022-04-20 17:24:44', '2022-04-20 17:24:44'),
(9, 'App\\Models\\Auth\\User', 3, 'App\\Models\\Auth\\User', 3, 4, 'updated', '{\"id\":3,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"user_group_id\":0,\"username\":null,\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":0,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"rWDXgF0pkwM2aRHdsLQ4OPSLJV2oUY9g5JrgC7BkQzQOICY1kYZ4ZfM5Er5M\",\"created_at\":\"2022-04-20 17:24:31\",\"updated_at\":\"2022-04-20 17:24:31\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '374b927a22a238d669c306c2a756ee3fe83b08a793f97e2787eb08ac07ef35dbb56cad8aa3573a6ee72b91ee93ccf096ddae1243f5f172f1efcaecbf3fab109a', '2022-04-20 17:24:44', '2022-04-20 17:24:44'),
(10, NULL, NULL, 'App\\Models\\Auth\\User', 3, 4, 'updated', '{\"id\":3,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"user_group_id\":0,\"username\":null,\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":true,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"rWDXgF0pkwM2aRHdsLQ4OPSLJV2oUY9g5JrgC7BkQzQOICY1kYZ4ZfM5Er5M\",\"created_at\":\"2022-04-20 17:24:31\",\"updated_at\":\"2022-04-20 18:41:32\",\"deleted_at\":null}', '[\"confirmed\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/account/confirm/f6f08a2dc652cce284fce32bf5e7bff4', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', 'dd01c7bf6d7f68fb6db0510cb60654a607c69e6a52c8125521e57fcdfa9705e770c3158d2a6934ce9bbe455799f0681c5f36bb9ac1e720ab290c24d5f3aec73a', '2022-04-20 18:41:32', '2022-04-20 18:41:32'),
(11, 'App\\Models\\Auth\\User', 3, 'App\\Models\\Auth\\User', 3, 4, 'updated', '{\"id\":3,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"user_group_id\":0,\"username\":null,\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/Los_Angeles\",\"last_login_at\":\"2022-04-20 18:59:15\",\"last_login_ip\":\"172.118.155.20\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"rWDXgF0pkwM2aRHdsLQ4OPSLJV2oUY9g5JrgC7BkQzQOICY1kYZ4ZfM5Er5M\",\"created_at\":\"2022-04-20 17:24:31\",\"updated_at\":\"2022-04-20 18:59:15\",\"deleted_at\":null}', '[\"timezone\",\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', 'a2ac1dfbd82a9c3fe8cd63fc7f9b73886346ed610511aa502c85a0f049fdf4d3f4207677f6ec90312e000f0746ed11fbc8f6942b9ac7e22c6df1f153fb2e1e8b', '2022-04-20 18:59:15', '2022-04-20 18:59:15'),
(12, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-04-21 05:28:42\",\"last_login_ip\":\"110.235.219.77\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"PidRxf7GY24mr8UTbti5NyaOstgUQJkYao1jKInf0Q8hz2kEwrMVLGH6MXgH\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-04-21 05:28:42\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '5d9eaf669ad2c83943c5174263fd4b5c455b1fbea88802f7eb3cf50f2304336679cb8544d85337c4410282c5729f119eacf3af39d22571cb2735fda47282d799', '2022-04-21 05:28:42', '2022-04-21 05:28:42'),
(13, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 4, 4, 'created', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteam@mailinator.com\",\"password\":\"$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C\",\"status\":1,\"confirmation_code\":\"0f43b8c8cd5c731379e42bb452adee09\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"4\",\"uuid\":\"56999975-6541-4053-bd96-8d2c19fb526d\",\"updated_at\":\"2022-04-21 05:38:13\",\"created_at\":\"2022-04-21 05:38:13\",\"id\":4}', '[\"first_name\",\"last_name\",\"email\",\"password\",\"status\",\"confirmation_code\",\"confirmed\",\"created_by\",\"user_group_id\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '16aa441b07029e6aaf7e035ce691e0e0d78c18ee954a400630acc63d2df9d2eb6a75fcab1ff48cb12e2a0791c61ffd1a317a700f687c2ea0dd8b8169eb6ff173', '2022-04-21 05:38:13', '2022-04-21 05:38:13'),
(14, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 4, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteam@mailinator.com\",\"password\":\"$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C\",\"status\":1,\"confirmation_code\":\"0f43b8c8cd5c731379e42bb452adee09\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"4\",\"uuid\":\"56999975-6541-4053-bd96-8d2c19fb526d\",\"updated_at\":\"2022-04-21 05:38:13\",\"created_at\":\"2022-04-21 05:38:13\",\"id\":4}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":4,\"role_id\":\"4\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '0fb1710b69a85f1d20a00003b0c61fe4beb790762a2e93831217bf98a6fab3b4edcab88b38ea4275793208abce6c0e017af8466076da124e575559b7c27e22c1', '2022-04-21 05:38:13', '2022-04-21 05:38:13'),
(15, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 4, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteam@mailinator.com\",\"password\":\"$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C\",\"status\":1,\"confirmation_code\":\"0f43b8c8cd5c731379e42bb452adee09\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"4\",\"uuid\":\"56999975-6541-4053-bd96-8d2c19fb526d\",\"updated_at\":\"2022-04-21 05:38:13\",\"created_at\":\"2022-04-21 05:38:13\",\"id\":4}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":4,\"permission_id\":\"2\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'e67dc9076c1d3b42f2e22b350134bf5b48ce813c09e7d3cfb2ff2fab9968f05f4e7f690651ebb74b7eb4462f60169905c2696a0760658a17008e14bd0ee90aff', '2022-04-21 05:38:13', '2022-04-21 05:38:13'),
(16, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'created', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[\"first_name\",\"last_name\",\"email\",\"password\",\"status\",\"confirmation_code\",\"confirmed\",\"created_by\",\"user_group_id\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '97196f5ece63bb192c58d46407a7ed2d0e4b62c17f757bbb7c9f74ecb37b97714eb2b5aa01d88bb653bd98090ed8cae91aadb8592f5ddef5d5b55e517bd9e1e6', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(17, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":5,\"role_id\":\"2\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '1ffa31ee20b8ae0da2d5a2c62025ec104bcfd9d7a310f1f7c42dff1a1a11f954963bda196a43a1998bb134f1704caa47e9bcd30d2cc5bd08981809547d5e38f6', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(18, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"1\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'c8267dec15bc3e6ce991c42a5398c81d83875d20351c4f55a6897840d7766ebeae28ca62a7a5690fa09bd3a5e8e95985ca1a3cbd39bd0aa8794e7cfa25019987', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(19, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"3\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '25e2d12ba9c4bdac12c4f868ef67f39ba5968a8da5a7ef36fd4128f349e74b79593547909577e3c21cd084cbb8c3f92402ef0966ad9fa9a751176830d965be5b', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(20, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"4\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'd28fab2e3c843bb7fdbb3627a9630724def822fa44a39bac66b8dddccdb0b9cf1821bff239c69507a394e0913e9f76a4951a1ea66acb9a9fd857ff0503375b3a', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(21, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"5\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'a5cedcd7731ec84f589776a560d3288c6e26f3f5941557fe63353732ec752c1bbb39a2cdb97133118c7257d645154a018c58a46a641b2d6a2729d7912d82bc7b', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(22, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"6\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'f44ed2949c47f4fc9b6068c81ea2caa193d739c6bd1ed8d1211e9c5801623be5a1706b93ecaacd881fd56987d568da6c6f5d32e024a49f7aa960203da5c424c0', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(23, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"7\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'e350dc001a710b831d454404f46af4abe4e1121a586499a9206d0bf44450618cbfc4380e1128b239b318219472b105aa60573782ce1fc58ce4a96c5b4e55408e', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(24, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"8\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '715a8973d1206d82d47508cba93d302081db4833d3e52524e3fa461798f919a374688ce63e2d8e3b01985f649c1eb20d1f16121ef7d7150a131b3470be427ce2', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(25, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"16\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'f726aa63460160a145f3abe72379a3b41b9cf6d8c97e49457da144c46674e14255bba445a96c3d14dc0c7e074273c65d9f7e9bdf95d9835926104c31e26b89ee', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(26, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"20\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '387a6031bd2231ac65ceae58bf0ba7cf70c59f105d75e14ffb9893ed2b9383d882462a444d50319d532c4b4c67e4d5f788788103bacb016283741f4385d71fd2', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(27, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"24\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '1df0ccbbed6e5440eb04a925367492ba9c189a65849f80b46ad446f8e8657a33cde54b90d4f348168abc7ae13e3b4fc2d7534b168c69f4cc23664ec012a336f4', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(28, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"25\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '7bb85901a6b34f480af0bd8d737c0135b4f0ff674c5601d0750784347d837254c1977f10bcf97a13a0a1c702aeb1f52b8a9d0adc5712a6e3bd6217fc4d29d093', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(29, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"26\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'df7298a1b04809d93282ec2d4a4a40a94b1425e5c49cab85505d7c502d2e5d6a5aeed50d583d79b96f0cba84f6a185293e66ce18827301967f928b84abd5c861', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(30, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"27\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '01042a162eef03a6f133e08c73c10d6630917a1dc99dcc59bfdd28367dd359f8bc2e05120bcc2af08ddd84c985d5a09d2af20ed6277abb6528a3ea9b5df5cf86', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(31, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"28\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'f5a5d14de7097fe96c1773182bec041514e70fc27e292fca7a7b3a6cddff905d819ff5cad4b2a193da3d3867efd1a74a6c096ab5862f1c4a023615edb58dbb6f', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(32, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"29\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '20a272e9db3e9dd4ff4ef00cc9567ae85103c7a5b81258f64070bfc99208bfb476e004cdca8ed998b3fec4022b1c680ef97ae3a9fc297fb6e27bf09f7653d344', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(33, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"30\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'cdefe8b97f748029f78c1c0aeb2620f012ad191c82a57cfc56d0c2b089bdcc58c4dcbc425b16a0bea2b53e87569735d7c5fdb0e2dba6589c2c8871e161f8c59f', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(34, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"31\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '84edc33dafca5684a0eb8763282b60a4fb6d60b96387816c0e3674f4c5c75681c7489200277eb6b92aab07deac1eade3000733d020530722a02e1fa008e1c72b', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(35, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"33\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '087f46ff584c234cac20943a2e6996b5901b886c355e82235b7c7241fd94c88fb9253b295982109ad091deaa577a11dfd915d656f02ef413a766a4b0753f8676', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(36, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"34\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'fc4ca58cf8d94b7b02c4d245983d7ad156521efd0436cc17a2ae0121390c2994bc3af9d67de3fbce2f746b756214367fe6613f990bbe500f1081ef16f06e6224', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(37, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"35\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'fe8a622ae4ac523325a2d9688ee02481684e283fe429cbc9e2f9ae426d9902615e60eef336547349582912a5d7ea6327bc598e1668ca9a3180d43e3ef1365dee', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(38, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"36\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '6cca8d900bb2a4c0dd722e5992a2f550a0b4d2b072ffb64c88e393428cc0634e3e045e82d6b467f8d2aeee1a225bc7156ac7c565d649cdae4f89ee7e3ec7df6b', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(39, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"37\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '8d253e1d680e5b5e58e05f8825fc24cf3f5fddbc7f1df3e0a7762b6cbd4d5d9f72f952db15b41f36ab69083bf27457e74fb1bf2cf4510e2cf5add3ec1070114a', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(40, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"38\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '9b9230e2b260c7ba3f36b2a6d1e987536e95bd706936fae232bd8d82653d713c5eca227d7e22526021e4c19559ba43141ba046cbdc9d1deb6bc901dfddc66ffb', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(41, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"39\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '39e2ff617eb3ad4a8321b801fa9bdb9123022b59af69dbed9867b4f239c66c1c1ee97fd86d1ac58800d27bc4f0188a46b4f78213e3d5af309dcc6f28440cfe6a', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(42, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"40\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '8ae0f29e9d924b9bf449fac0c3f58545e31fbbcdec6b2330f51ae0616a319f8ddddcfa1cdefca074edea9ac6ab8b797c9899023a4b29097aa8b8b3f5e35ae7a4', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(43, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"41\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '5c4e46ebeed8a8efa013517e3f8b9f2f4e9a830e7c96af7e21a117b6d4d7ddfce085333835760b8e37b8f4f3bcb83f574756195ee05ff8da5c91213599fa2132', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(44, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"42\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'd4571edce27abc68ac23bb8959ba7cf9e64256aed70272c91b687b308a32df0c65081e96292ae7cafacab50a7cc16b02dc3bb53c75b577b3865bd11e07327de7', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(45, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"43\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'd4c11a80ca2e969bb4a3fc315c57e99bb836c452eca1560712bc1f895224e5f28c2f66d3e3c305154b4a8aec05ef31f3ef59569a505676def19a2d19f76bc19b', '2022-04-21 07:11:54', '2022-04-21 07:11:54');
INSERT INTO `ledgers` (`id`, `user_type`, `user_id`, `recordable_type`, `recordable_id`, `context`, `event`, `properties`, `modified`, `pivot`, `extra`, `url`, `ip_address`, `user_agent`, `signature`, `created_at`, `updated_at`) VALUES
(46, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"44\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '67a18fa4343231270d4f60bf764b3f05ad14e566350b860277f088d89d3287c3070c780c5d057d0e670d732d8b5274eed5dc146a603e33350e57fad40491db37', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(47, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"45\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'cd397b793cbc6a6c265c30cd06f096440c09d8d36a2ad6f0c45dae7fdf7e635f838721d7950c4cf528cdb1d698d2d43239a37c31a143c7e03fb860aa8ccd703a', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(48, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"46\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'f3eb5d7eeab5c23ee39cd439e222d3e64e34d233f4eb46c752087c69b715482f3473110f292b5e061b1357c24a72f6d981a00269b29d582e81d25976ab73bb25', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(49, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"47\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '15dbd07703b726e6e131c5e7306692b8c916ce31f6e951b2caf9b8d12dd9055247dd8a7596310030443262a70dea30703e188b1a40763a45308b595b423f9ef9', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(50, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 5, 4, 'attached', '{\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteamwdp@mailinator.com\",\"password\":\"$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN\\/G0\\/.C0bAA3kN3eZsHzH60coKYxy\",\"status\":1,\"confirmation_code\":\"cb8af30966627159f86755ed071a7a12\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"2\",\"uuid\":\"822a7a07-721b-4fcf-b9dc-6d0ded7a2420\",\"updated_at\":\"2022-04-21 07:11:54\",\"created_at\":\"2022-04-21 07:11:54\",\"id\":5}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":5,\"permission_id\":\"48\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '453b8ac2eb1d4e2053c4ee4d5bc8e7f5646d5d7444a0d6958da459f427f25b9586fe5a6e485cae5cd6cfc8c4cdc85d9b7f435f394e7fe2d9947b3f118dbdf7e2', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(51, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\Saloon', 4, 4, 'updated', '{\"id\":4,\"uuid\":\"56999975-6541-4053-bd96-8d2c19fb526d\",\"user_group_id\":\"2\",\"username\":null,\"first_name\":\"Android\",\"last_name\":\"Team\",\"email\":\"androidteam@mailinator.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0f43b8c8cd5c731379e42bb452adee09\",\"confirmed\":\"1\",\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":\"1\",\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":null,\"created_at\":\"2022-04-21 05:38:13\",\"updated_at\":\"2022-04-21 07:13:09\",\"deleted_at\":null}', '[\"user_group_id\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon/4', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '09df36c8b74d7e498f52b248bc4657569b31489081098bd4a973744218cf89c7dd167ea865b11e8059991703aa1469e309b715ecfb5a2441ec82dbdcefb28ad5', '2022-04-21 07:13:09', '2022-04-21 07:13:09'),
(52, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\Saloon', 4, 4, 'updated', '{\"id\":4,\"uuid\":\"56999975-6541-4053-bd96-8d2c19fb526d\",\"user_group_id\":\"2\",\"username\":null,\"first_name\":\"Wdp\",\"last_name\":\"Technology\",\"email\":\"androidteam@mailinator.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0f43b8c8cd5c731379e42bb452adee09\",\"confirmed\":\"1\",\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":\"1\",\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":null,\"created_at\":\"2022-04-21 05:38:13\",\"updated_at\":\"2022-04-21 07:14:19\",\"deleted_at\":null}', '[\"first_name\",\"last_name\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/saloon/4', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '44288f4e5b30272c9000dd5a8ed0fed1ff309eaa4b57797b0dca5fb260033f91bda151dec94f65091d80b99b801485cd552acb8a9078d9fcc2f0580d1d1efca6', '2022-04-21 07:14:19', '2022-04-21 07:14:19'),
(53, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-04-21 05:28:42\",\"last_login_ip\":\"110.235.219.77\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-04-21 05:28:42\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/logout', '110.235.219.77', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '8320ea3eb055706be0b8bb2c70ba50cba5c4c69700e5faedae0ea1c595ce7e42a25d0bbf39fd060ea7bb0177ace4cfff9c97c24062d8f1bf07a9c3db04526c4f', '2022-04-21 11:35:37', '2022-04-21 11:35:37'),
(54, 'App\\Models\\Auth\\User', 3, 'App\\Models\\Auth\\User', 3, 4, 'updated', '{\"id\":3,\"uuid\":\"874dfe27-fecc-46d2-a8cb-9a01960ae4e6\",\"user_group_id\":0,\"username\":null,\"first_name\":\"Grace\",\"last_name\":\"Jang\",\"email\":\"grace@svgo.ai\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$lJxXuOrFe\\/pg6y0tEqTj6eIyQ6\\/7WBdqW7Es\\/ECEzpiJJgdWVjrqC\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"f6f08a2dc652cce284fce32bf5e7bff4\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/Los_Angeles\",\"last_login_at\":\"2022-04-20 18:59:15\",\"last_login_ip\":\"172.118.155.20\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"u5yBVMmLWonPvOfWx7ubLzw0t3glgJy9uCdiiZz0I6i4v6fp1WQ0s1ytybvq\",\"created_at\":\"2022-04-20 17:24:31\",\"updated_at\":\"2022-04-20 18:59:15\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/logout', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '7d48c62bf89cf393345c6a415d0fda75f0eb2ce324a0802379ea2697b295a7e98ad7d14766f4b25e6f64612e0c2d37cfbd13d7aa49c36c829124a0b28a337604', '2022-04-21 11:38:43', '2022-04-21 11:38:43'),
(55, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/Los_Angeles\",\"last_login_at\":\"2022-04-21 11:39:03\",\"last_login_ip\":\"172.118.155.20\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-04-21 11:39:03\",\"deleted_at\":null}', '[\"timezone\",\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '7b41fac0406750ee1c4d5f767404ab7e7a98f4d3a523327313c084631a7dbed56c499df30e6a40082f442a27bc10c901e36c85c31c410fd5adf450731e62658a', '2022-04-21 11:39:03', '2022-04-21 11:39:03'),
(56, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 6, 4, 'created', '{\"first_name\":\"test\",\"last_name\":\"test\",\"email\":\"test@gmail.com\",\"password\":\"$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe\",\"status\":1,\"confirmation_code\":\"9636693a8824eeaf0ff027f78be55854\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"3\",\"uuid\":\"41ca8a88-b490-4553-ba71-e70e4afd5574\",\"updated_at\":\"2022-04-21 11:54:47\",\"created_at\":\"2022-04-21 11:54:47\",\"id\":6}', '[\"first_name\",\"last_name\",\"email\",\"password\",\"status\",\"confirmation_code\",\"confirmed\",\"created_by\",\"user_group_id\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/user', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', '1f4c7a8a7b32a17b40075b95e72e2c7968388bd9223aa07bdf5e4c343c6a9aeab2b8e2f536f642bac117db8e8d5882cec30a415c9d6eb900a3698e9b45f347c2', '2022-04-21 11:54:47', '2022-04-21 11:54:47'),
(57, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 6, 4, 'attached', '{\"first_name\":\"test\",\"last_name\":\"test\",\"email\":\"test@gmail.com\",\"password\":\"$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe\",\"status\":1,\"confirmation_code\":\"9636693a8824eeaf0ff027f78be55854\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"3\",\"uuid\":\"41ca8a88-b490-4553-ba71-e70e4afd5574\",\"updated_at\":\"2022-04-21 11:54:47\",\"created_at\":\"2022-04-21 11:54:47\",\"id\":6}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":6,\"role_id\":\"3\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/user', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', 'eddab994fa172bae92d63d04178948ee215bb288064bdaa22cbbfc7d43601ee98034657fa07477ee98a420f7ed9a50b2f1e05e0d419f3595f80ea8085caf32ea', '2022-04-21 11:54:47', '2022-04-21 11:54:47'),
(58, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 6, 4, 'attached', '{\"first_name\":\"test\",\"last_name\":\"test\",\"email\":\"test@gmail.com\",\"password\":\"$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe\",\"status\":1,\"confirmation_code\":\"9636693a8824eeaf0ff027f78be55854\",\"confirmed\":1,\"created_by\":1,\"user_group_id\":\"3\",\"uuid\":\"41ca8a88-b490-4553-ba71-e70e4afd5574\",\"updated_at\":\"2022-04-21 11:54:47\",\"created_at\":\"2022-04-21 11:54:47\",\"id\":6}', '[]', '{\"relation\":\"permissions\",\"properties\":[{\"user_id\":6,\"permission_id\":\"2\"}]}', '[]', 'http://design.smartitway.com/ohcut/public/admin/auth/user', '172.118.155.20', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.3 Safari/605.1.15', 'c0f0545a652887c63e11204312bdd44347d9198c7a9b6e67ae308b4256d2e944c9721c5509e83fb95910351f2d4fa5dcd8f85e1baeed5e4e513b861c20db0c54', '2022-04-21 11:54:47', '2022-04-21 11:54:47'),
(59, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-04-22 10:23:47\",\"last_login_ip\":\"110.235.219.27\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-04-22 10:23:47\",\"deleted_at\":null}', '[\"timezone\",\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.27', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '84eb5fcc1388f14359f88a5945a9231bd0b54c8e74dd8c5b3b8cdb429f5b302826aeb2044d7e5a7f59df1dfb3e7d6163c51dd6eff35bf3ee889c2063170b67b3', '2022-04-22 10:23:47', '2022-04-22 10:23:47'),
(60, NULL, NULL, 'App\\Models\\Auth\\User', 7, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Abhishek\",\"last_name\":\"Tripathi\",\"username\":\"Abhishek Tripathi\",\"email\":\"abhi@mailinator.com\",\"mobile_no\":\"8602624288\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$ao6g1wsJg5xKobRdZylmTOclkqsoWz3nOLQcAfu4bb4Db6.6rRNV6\",\"confirmation_code\":\"cbbffcdbbacc26092141639885fa680f\",\"uuid\":\"89684ccc-a82b-42b1-83f5-6a9b40e033ea\",\"updated_at\":\"2022-04-22 16:19:00\",\"created_at\":\"2022-04-22 16:19:00\",\"id\":7}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.27', 'okhttp/5.0.0-alpha.3', 'b7b7da031acacbff9e33fe93557a8928b79ed3b377b9a3e819bbaff060c8f4477c36fd456f54a6f2f8bb4948097d890e104527c1ea89274e6a46a911561340cb', '2022-04-22 16:19:00', '2022-04-22 16:19:00'),
(61, NULL, NULL, 'App\\Models\\Auth\\User', 7, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Abhishek\",\"last_name\":\"Tripathi\",\"username\":\"Abhishek Tripathi\",\"email\":\"abhi@mailinator.com\",\"mobile_no\":\"8602624288\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$ao6g1wsJg5xKobRdZylmTOclkqsoWz3nOLQcAfu4bb4Db6.6rRNV6\",\"confirmation_code\":\"cbbffcdbbacc26092141639885fa680f\",\"uuid\":\"89684ccc-a82b-42b1-83f5-6a9b40e033ea\",\"updated_at\":\"2022-04-22 16:19:00\",\"created_at\":\"2022-04-22 16:19:00\",\"id\":7}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":7,\"role_id\":3}]}', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.27', 'okhttp/5.0.0-alpha.3', '16196cf34ae07955457f1a78d9ead14efc2ddd0a5df907ea4913b305fb68675fb8e2d20662a421934077ebb8e8fbe3571f26df4bee3778bf6c1431ab860b70cc', '2022-04-22 16:19:00', '2022-04-22 16:19:00'),
(62, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 05:37:54\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 05:37:54\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '04801a7915da05694e70eec619c2e35cc6ac75555e1e170a552647311ab747ee1472b8e84b2d3a7fa719bfab3189a9d78051b9e0066db38aa44288c5a31d150d', '2022-05-02 05:37:54', '2022-05-02 05:37:54'),
(63, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 05:55:44\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 05:55:44\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'c6ec704cdbe8c2932edcb18c4fcbb912ce8ebb7477f117d952417ae343dc77d587a42fe203a5e2655924f50376bfccae9204236cf25f8eabbdf0bec3d83fabf2', '2022-05-02 05:55:44', '2022-05-02 05:55:44'),
(64, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 07:04:29\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 07:04:29\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'ace46bb4fa789c8bc77debdb1fdd4fb4e5e930e82ac9a82b3cf777aa721a6d241c5f28ea5c68cd49b6b21dca3d4083f7f977e992f3bbdde848f681c794825917', '2022-05-02 07:04:29', '2022-05-02 07:04:29'),
(65, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 10:57:17\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 10:57:17\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'dab23466da9c26b2f4e59ae52ceab3c8dd0bbd34ae3f59133051828db71dbf0229edc3587d620feb34af45a93bff6965fe080b9bf9bb84cff42b3c5691957b51', '2022-05-02 10:57:17', '2022-05-02 10:57:17'),
(66, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 11:25:21\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 11:25:21\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'f5048241be71fc57311cc94ce32bbce92bf2fd3c427c1d575233e040c8366c524af42d90ab08aeee03faaff4c6b0ae8245ab5dfd84214d74b0eab471d61e254e', '2022-05-02 11:25:21', '2022-05-02 11:25:21'),
(67, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-02 13:19:17\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-02 13:19:17\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', 'd84fffd9fdbc7b570e3ee7655eaede0a6c0a02e9faeaa8fb9f86c59902455eb2cb73ee32c9f830de5abb3275683ad0a598b79a2eba3e1125ba35143fa29f542b', '2022-05-02 13:19:17', '2022-05-02 13:19:17'),
(68, NULL, NULL, 'App\\Models\\Auth\\User', 8, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"Gujar\",\"username\":\"Rohit Gujar\",\"email\":\"rohit@mailinator.com\",\"mobile_no\":\"6666666666\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$IAJXukkSFRN7ghtloJzYheZusUoaX1Jra.t.5\\/116WVOu\\/vKkBXY2\",\"confirmation_code\":\"d7e5a9db050469f190fbc359ac5e47d2\",\"uuid\":\"ea28d774-25dc-47fd-9c5b-1a6e7bd2c5a5\",\"updated_at\":\"2022-05-04 10:48:21\",\"created_at\":\"2022-05-04 10:48:21\",\"id\":8}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.126', 'okhttp/5.0.0-alpha.3', 'f468b3b08a415b6c810430547869fe00e379def33b6c6a1604e2ff9ddf692f9212e7f5e98b2a8e0dcd1e205620e831e3d508687d94958ca42be3e82b3d08ab84', '2022-05-04 10:48:21', '2022-05-04 10:48:21'),
(69, NULL, NULL, 'App\\Models\\Auth\\User', 8, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"Gujar\",\"username\":\"Rohit Gujar\",\"email\":\"rohit@mailinator.com\",\"mobile_no\":\"6666666666\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$IAJXukkSFRN7ghtloJzYheZusUoaX1Jra.t.5\\/116WVOu\\/vKkBXY2\",\"confirmation_code\":\"d7e5a9db050469f190fbc359ac5e47d2\",\"uuid\":\"ea28d774-25dc-47fd-9c5b-1a6e7bd2c5a5\",\"updated_at\":\"2022-05-04 10:48:21\",\"created_at\":\"2022-05-04 10:48:21\",\"id\":8}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":8,\"role_id\":3}]}', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.126', 'okhttp/5.0.0-alpha.3', '0a830e4f79460bd477e6d9342882abd2136bea57ba8a0b56039695a37271c52d0de07eb21cc159ebe4a005e3a20b9da0239afc8bdb90e070643748a93ebd6511', '2022-05-04 10:48:21', '2022-05-04 10:48:21'),
(70, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-05 05:16:58\",\"last_login_ip\":\"110.235.219.159\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-05 05:16:58\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.159', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.127 Safari/537.36', '2199e9e80b27a41b2f9a6db5aa32f6e438990f42967d6f4a373263dd861d019689fb6ce40beed9a6928ae1608070b35c2dd1dff98280af1ca0bc1e3f16b1ca4e', '2022-05-05 05:16:58', '2022-05-05 05:16:58'),
(71, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-05 09:24:19\",\"last_login_ip\":\"110.235.219.159\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-05 09:24:19\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.159', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', 'f0edbb6028d6b601b61fe4a7baecd4430af3e92a9450f223ea157d2d6e2607561cf2d4db1296bc584a65e1d179cfca8437688cb1873957bcae53b014c270ed2e', '2022-05-05 09:24:19', '2022-05-05 09:24:19'),
(72, NULL, NULL, 'App\\Models\\Auth\\User', 9, 4, 'created', '{\"user_group_id\":\"2\",\"first_name\":\"Jaipur\",\"last_name\":\"salon\",\"username\":\"jaipur salon\",\"email\":\"\",\"mobile_no\":\"1231231233\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$MGVmXPe3A9Ldp1sy3Hzg4ONt7umOja2i8cvSXbtqBXMMwjgx73Syi\",\"confirmation_code\":\"dee60f78a040199fb813d4b6ab5250ed\",\"uuid\":\"9d34729d-b2a3-42d8-a263-e84c19c70fae\",\"updated_at\":\"2022-05-06 11:36:05\",\"created_at\":\"2022-05-06 11:36:05\",\"id\":9}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.159', 'okhttp/5.0.0-alpha.3', '2694ecf54c49fd9e78a1ca8d04c29dfd3f47d34da91f9e6d55f0e3a8a3174ebf0cc2f1499103463da14d43fb4cca5df92c979993b8088e31dfeec9662ec6afb7', '2022-05-06 11:36:05', '2022-05-06 11:36:05'),
(73, NULL, NULL, 'App\\Models\\Auth\\User', 9, 4, 'attached', '{\"user_group_id\":\"2\",\"first_name\":\"Jaipur\",\"last_name\":\"salon\",\"username\":\"jaipur salon\",\"email\":\"\",\"mobile_no\":\"1231231233\",\"active\":1,\"confirmed\":1,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$MGVmXPe3A9Ldp1sy3Hzg4ONt7umOja2i8cvSXbtqBXMMwjgx73Syi\",\"confirmation_code\":\"dee60f78a040199fb813d4b6ab5250ed\",\"uuid\":\"9d34729d-b2a3-42d8-a263-e84c19c70fae\",\"updated_at\":\"2022-05-06 11:36:05\",\"created_at\":\"2022-05-06 11:36:05\",\"id\":9}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":9,\"role_id\":2}]}', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.159', 'okhttp/5.0.0-alpha.3', '56bed4dddf826250c99b0f500cd15d2d482b8952c6f29d6ab1bae13a309453974c76393c2712abc4a745d22ac60dbbb4d3dbd43eb2439da59f94f79c32843dfe', '2022-05-06 11:36:05', '2022-05-06 11:36:05'),
(74, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-09 13:09:51\",\"last_login_ip\":\"110.235.219.160\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-09 13:09:51\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.160', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', '80d7d2ace9859a0b152f128a3b788cfe137a2fe79870863c0da4185ff035e77f1676e47c99c2301763db844dcd49a98f004d90c5fdf900a506879ad0323a49f1', '2022-05-09 13:09:51', '2022-05-09 13:09:51'),
(75, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-10 13:05:29\",\"last_login_ip\":\"110.235.219.160\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-10 13:05:29\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', 'cdb4d4f89f8d666c5baed7e7e83f88d305c0e5d460b2e7e0b471f692622a64501814a935fa73387ea02cb343271639e2a39e390e01766f86f3e20a064af645f3', '2022-05-10 13:05:29', '2022-05-10 13:05:29'),
(76, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-10 13:32:20\",\"last_login_ip\":\"110.235.219.160\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-10 13:32:20\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', '048b1692ad0550a4b947a3b3071eed82de148558ce8ca3cf19b29fd0f2faec1ed34aa98dcd4ca7b383c6c2130a66011632fe99c62a3f3849efdb07f44cd09cc1', '2022-05-10 13:32:20', '2022-05-10 13:32:20'),
(77, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-12 05:11:20\",\"last_login_ip\":\"110.235.219.160\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-12 05:11:20\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', '7932236d099b9207298b184a4081496b052d9d7f7841d9ffcd3c3a6b7aa732ea774ded05ec0995f85450beeacf2043c433f2addb377ab6b5ac73e1c6dfdf7c67', '2022-05-12 05:11:20', '2022-05-12 05:11:20'),
(78, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-12 11:15:39\",\"last_login_ip\":\"110.235.219.160\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-12 11:15:39\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.160', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', 'e807f762dae48408b03630163a68303eeb893e6b6fa7e880e8b8bb6523efdf48aeeaf080f8cbc0ceabae358f45843757a0f8c08f944a56a5f60ed6d12c30959b', '2022-05-12 11:15:39', '2022-05-12 11:15:39'),
(79, NULL, NULL, 'App\\Models\\Auth\\User', 10, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Oh\",\"last_name\":\"Cut\",\"username\":\"Oh-Cut\",\"email\":\"ohcut@mailinator.com\",\"mobile_no\":\"9876543210\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$Kf7OLfUKfXpXhasCTlmro.cVUHEkvinBZaiASfbuMGKhWoLdA7i9e\",\"confirmation_code\":\"771054e9a1d09db1285e8da9c643ad13\",\"uuid\":\"b3e424f0-243e-41e4-8053-5bb54b1db7ac\",\"updated_at\":\"2022-05-16 10:01:12\",\"created_at\":\"2022-05-16 10:01:12\",\"id\":10}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"to_be_logged_out\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.160', 'Oh-Cut/1.0 (com.WDP.SalonUser; build:1; iOS 15.2.0) Alamofire/4.9.1', 'e2d5ed1852cc37c20135e3ad68e168be07e9522a62b365e1ee12dedfcf8fb8288935219e66a59b3dfc750211efdf3240ee482d61aecfa9d72ce6bf3c77e35fbb', '2022-05-16 10:01:12', '2022-05-16 10:01:12'),
(80, NULL, NULL, 'App\\Models\\Auth\\User', 10, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Oh\",\"last_name\":\"Cut\",\"username\":\"Oh-Cut\",\"email\":\"ohcut@mailinator.com\",\"mobile_no\":\"9876543210\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$Kf7OLfUKfXpXhasCTlmro.cVUHEkvinBZaiASfbuMGKhWoLdA7i9e\",\"confirmation_code\":\"771054e9a1d09db1285e8da9c643ad13\",\"uuid\":\"b3e424f0-243e-41e4-8053-5bb54b1db7ac\",\"updated_at\":\"2022-05-16 10:01:12\",\"created_at\":\"2022-05-16 10:01:12\",\"id\":10}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":10,\"role_id\":3}]}', '[]', 'http://design.smartitway.com/ohcut/public/api/register', '110.235.219.160', 'Oh-Cut/1.0 (com.WDP.SalonUser; build:1; iOS 15.2.0) Alamofire/4.9.1', '3b43f1b87ccabf3adc0191426b5c819aec6cb3ee8f576066406e476bd1f78ef453f99bd3584cc49f7a14cbed00fbd45c431e988c53f149028801d911eb890e14', '2022-05-16 10:01:12', '2022-05-16 10:01:12'),
(81, NULL, NULL, 'App\\Models\\Auth\\User', 10, 4, 'updated', '{\"id\":10,\"uuid\":\"b3e424f0-243e-41e4-8053-5bb54b1db7ac\",\"user_group_id\":3,\"username\":\"Oh-Cut\",\"first_name\":\"Oh\",\"last_name\":\"Cut\",\"email\":\"ohcut@mailinator.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$Kf7OLfUKfXpXhasCTlmro.cVUHEkvinBZaiASfbuMGKhWoLdA7i9e\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"771054e9a1d09db1285e8da9c643ad13\",\"confirmed\":true,\"mobile_no\":\"9876543210\",\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":null,\"updated_by\":null,\"is_term_accept\":1,\"discount_message\":0,\"remember_token\":null,\"created_at\":\"2022-05-16 10:01:12\",\"updated_at\":\"2022-05-16 04:32:34\",\"deleted_at\":null}', '[\"confirmed\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/account/confirm/771054e9a1d09db1285e8da9c643ad13', '110.235.219.160', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', '7c2db02489722abdaa14ec13b5fec46c05d219ca5f17d2357e16e80d91520204914a156f564610f1c940820e87ee89adc27aab494790a2519af8e83bb9be6ee6', '2022-05-16 04:32:34', '2022-05-16 04:32:34'),
(82, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-16 06:47:18\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-16 06:47:18\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36', 'd78b34393b2a3b69c2d35a508817fb17437c98d5f12afd7f0b493a71dd704ed1e4c13f604ad42d62c7f4ba542fc9cd4e5747434b67e9448d82369233dd006e23', '2022-05-16 06:47:18', '2022-05-16 06:47:18'),
(83, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-17 08:54:12\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-17 08:54:12\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', 'a2058589019648c07714816b0ad50c3d91039546cb46b535f5aea289ad66f871ff9e5407083d822239f3976776e887cdbf92e0a0a6414d2e9f3422de8d7cdfb5', '2022-05-17 08:54:12', '2022-05-17 08:54:12');
INSERT INTO `ledgers` (`id`, `user_type`, `user_id`, `recordable_type`, `recordable_id`, `context`, `event`, `properties`, `modified`, `pivot`, `extra`, `url`, `ip_address`, `user_agent`, `signature`, `created_at`, `updated_at`) VALUES
(84, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-17 10:10:24\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-17 10:10:24\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', 'f82c7fcd9c4cab352ab6003247a8a5588a785a320a2ce500a5d5b6bc843b67af3beb2030589dd4da00926f791a7cef2f1fc42849e9e54e4527edab6d460defd6', '2022-05-17 10:10:24', '2022-05-17 10:10:24'),
(85, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-17 13:13:58\",\"last_login_ip\":\"110.235.219.126\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-17 13:13:58\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.126', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', '228a4c0c11b4827d15dfed2b8db6353a532a62c5fd103fcc62770b302667ddea3ae118d1ef7da1c364e78e40b519199bff5dcd53685e7e375a7b7c335ab37693', '2022-05-17 13:13:58', '2022-05-17 13:13:58'),
(86, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-18 08:47:00\",\"last_login_ip\":\"110.235.219.128\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-18 08:47:00\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.128', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '07b6006627dc8d4f387c924ed0a308b1585b032cee3778a07c740ac3e05283bff939e44bd7555c270a955166866de19b0df3e41f18a91004759cad988fbdd654', '2022-05-18 08:47:00', '2022-05-18 08:47:00'),
(87, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-20 11:05:29\",\"last_login_ip\":\"110.235.219.240\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-20 11:05:29\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.240', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36', '4ba07eb0724a780c6f3198bbc5e5000dd1a89b0189b5d9ca57441462859ff8330ef248cdf896375ae7eaab3f09ec410ad561ccc7c492c8840bed630f996b0941', '2022-05-20 11:05:29', '2022-05-20 11:05:29'),
(88, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-20 11:15:16\",\"last_login_ip\":\"110.235.219.240\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-20 11:15:16\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.240', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', 'b5369be3fb39aa774959b57b8988fa8f3a3e6af11aa846a0296bfab0a85ce2abe6e3cca5ef744fc5132c592cdd0f0510d323a18908b084f6bab2beaca3d783c1', '2022-05-20 11:15:16', '2022-05-20 11:15:16'),
(89, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-24 09:47:17\",\"last_login_ip\":\"110.235.219.59\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-24 09:47:17\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.59', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '965b3639c4a08b96b64ce3485e1192695c6c07a6e620118152445f1fb9835577300c13277f993b9afd99ca8e9f47f915e0930f03b14c2a84655f060e241e7c34', '2022-05-24 09:47:17', '2022-05-24 09:47:17'),
(90, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-24 12:36:25\",\"last_login_ip\":\"110.235.219.59\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"A6hTIPOTWejwxJnGyLimmH3qucmoB7icwRoh0ktlcVCLmPqKKX9xfTI927wS\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-24 12:36:25\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.59', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '5b2c8e0f4d8dc61f73f9defa47afbd11a51ee5c0cef2bc30142e98211746973951c54ee60e269f9a43ea1856a35448d0b42f68a1085f8e717ba4dbf092d1acfd', '2022-05-24 12:36:25', '2022-05-24 12:36:25'),
(91, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-24 12:36:25\",\"last_login_ip\":\"110.235.219.59\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-24 12:36:25\",\"deleted_at\":null}', '[\"remember_token\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/logout', '110.235.219.59', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '3351bdedb8f59d1f87666a08b15aa38a6da562313baf358b68b86602f1f6da2764ec5e4569bdd5cb3ea2555a188cce9bdc019f680f9b78609dcfa28441c6d489', '2022-05-25 11:46:28', '2022-05-25 11:46:28'),
(92, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-05-26 06:00:50\",\"last_login_ip\":\"110.235.219.59\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-05-26 06:00:50\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.59', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '4c775dbc2474b9a2e0ccfb81e2288d6b8dad9a75c0725dd73794c7a86987b283dde0438e5298af108d617364d0b189a64fc3cdd11529a45fc0ab8607d67dfe6c', '2022-05-26 06:00:50', '2022-05-26 06:00:50'),
(93, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-06-01 12:20:46\",\"last_login_ip\":\"110.235.219.244\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-06-01 12:20:46\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.244', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', 'fa3d04779008e000b67b6513e4f3611419ad2dad35cd53b3f646963a57cf35818cbc2cbb793cc2cd28f43de9f4e5749658ffddc684a82e257f65102366b287fb', '2022-06-01 12:20:46', '2022-06-01 12:20:46'),
(94, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"Asia\\/Kolkata\",\"last_login_at\":\"2022-06-02 05:32:08\",\"last_login_ip\":\"110.235.219.244\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 06:32:18\",\"updated_at\":\"2022-06-02 05:32:08\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://design.smartitway.com/ohcut/public/login', '110.235.219.244', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36', '57f71f41c2bd3b9221c17e6e0a5182359b495c66f8937231aadeb28513b1db041963ae3ad7fcade84fcfe58d41e60f616070aabf695eed7957970ae04bdef592', '2022-06-02 05:32:08', '2022-06-02 05:32:08'),
(95, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2022-07-01 08:23:01\",\"last_login_ip\":\"::1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2022-07-01 08:23:02\",\"deleted_at\":null}', '[\"timezone\",\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://localhost/ohcut/public/login', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'e2986a1cf512b99e7fba1d601d20e092ea0108a0289d52a2610704a1b410bdabe48dcbd7f56e3a47d9d089d24c476f397c1129a4983eb5154cabe38f7a7fe32c', '2022-07-01 02:53:02', '2022-07-01 02:53:02'),
(96, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2022-07-11 12:52:06\",\"last_login_ip\":\"::1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2022-07-11 12:52:10\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://localhost/ohcut/public/login', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '7e0d2aacbd965f43f9897267f34d97e8abf8ce9b13bfb58524a40110a9ef8ae6c301289b173c6f9ba2a193346ec99576287383811e2081435c53e8820f0c2280', '2022-07-11 07:22:10', '2022-07-11 07:22:10'),
(97, NULL, NULL, 'App\\Models\\Auth\\User', 11, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"parmar\",\"username\":\"rohit\",\"email\":\"rohit@gmail.com\",\"mobile_no\":\"5555566666\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$gr4tKhbiLlMNT2syaURYVe.oP4ZZ\\/YLQUZt7\\/bjjAdeElC7\\/LNn2K\",\"confirmation_code\":\"a5a70881441e1dcea3d0d9a02ca25c80\",\"uuid\":\"1d5a82e7-c8d1-41dc-b89a-cd3fda1b3d0c\",\"updated_at\":\"2022-07-21 10:35:23\",\"created_at\":\"2022-07-21 10:35:23\",\"id\":11}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"to_be_logged_out\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '95564602b9b23d4f0fbced14d62a022140f6d1d6fdf0974d549778eeb8b009d71c9a1e1cecc27af1984bf6257a8b0db04f88a3e5cc929764453bb5cc66b691ed', '2022-07-21 05:05:23', '2022-07-21 05:05:23'),
(98, NULL, NULL, 'App\\Models\\Auth\\User', 11, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"parmar\",\"username\":\"rohit\",\"email\":\"rohit@gmail.com\",\"mobile_no\":\"5555566666\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$gr4tKhbiLlMNT2syaURYVe.oP4ZZ\\/YLQUZt7\\/bjjAdeElC7\\/LNn2K\",\"confirmation_code\":\"a5a70881441e1dcea3d0d9a02ca25c80\",\"uuid\":\"1d5a82e7-c8d1-41dc-b89a-cd3fda1b3d0c\",\"updated_at\":\"2022-07-21 10:35:23\",\"created_at\":\"2022-07-21 10:35:23\",\"id\":11}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":11,\"role_id\":3}]}', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'a1be036ec9f2d4dfba56b90a02dacee296239a2d1bb8c50a17ea7b5009762e3a77b55e914da9c66a3df5ce8ec6e3c2234673c6af140686c58c6b05c1ec34bfc8', '2022-07-21 05:05:23', '2022-07-21 05:05:23'),
(99, NULL, NULL, 'App\\Models\\Auth\\User', 12, 4, 'created', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"parmar\",\"username\":\"rohit\",\"email\":\"rohit@gmail.com\",\"mobile_no\":\"5555566666\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$53Eite7CfalkzuQGSFMG\\/ecoTg2VowJ48omBYYdVlgwSWGl3nFuWa\",\"confirmation_code\":\"edf80ae0224b867eb56f6d7a5d3f9aeb\",\"uuid\":\"960f42fa-d22b-468a-ab27-7fabba104075\",\"updated_at\":\"2022-07-21 10:38:29\",\"created_at\":\"2022-07-21 10:38:29\",\"id\":12}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"to_be_logged_out\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'ba083a2c7bf96353c517421687f8a7ab2f9208d0fba264561399cc54216d5868ed18db2faa44e3d38472b1e42410ad7b857d39ca90e6dcd069996f3cb1ac0fcb', '2022-07-21 05:08:29', '2022-07-21 05:08:29'),
(100, NULL, NULL, 'App\\Models\\Auth\\User', 12, 4, 'attached', '{\"user_group_id\":\"3\",\"first_name\":\"Rohit\",\"last_name\":\"parmar\",\"username\":\"rohit\",\"email\":\"rohit@gmail.com\",\"mobile_no\":\"5555566666\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$53Eite7CfalkzuQGSFMG\\/ecoTg2VowJ48omBYYdVlgwSWGl3nFuWa\",\"confirmation_code\":\"edf80ae0224b867eb56f6d7a5d3f9aeb\",\"uuid\":\"960f42fa-d22b-468a-ab27-7fabba104075\",\"updated_at\":\"2022-07-21 10:38:29\",\"created_at\":\"2022-07-21 10:38:29\",\"id\":12}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":12,\"role_id\":3}]}', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'daf4de9b0f1f8475a534f14d8af8789a845f8b446771f3cc0bd877aaf622077683cf092f9cdb0cc6a52b5d2d73a4be2b251c14ddc5ed81b762d2ed13aa40c0d8', '2022-07-21 05:08:29', '2022-07-21 05:08:29'),
(101, NULL, NULL, 'App\\Models\\Auth\\User', 13, 4, 'created', '{\"user_group_id\":\"2\",\"first_name\":\"Garima\",\"last_name\":\"Singh\",\"username\":\"garima\",\"email\":\"garima@gmail.com\",\"mobile_no\":\"5555566677\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$PHJtb0.C8oz2TATNAjA\\/NOfdRm4DNwCwp3bBIjaarHC0ROPD3Q1s6\",\"confirmation_code\":\"37acf6de5105e2223e9db5827102387b\",\"uuid\":\"66e9b06c-d9e3-4fdb-9782-2b49a09e2492\",\"updated_at\":\"2022-07-27 14:53:06\",\"created_at\":\"2022-07-27 14:53:06\",\"id\":13}', '[\"user_group_id\",\"first_name\",\"last_name\",\"username\",\"email\",\"mobile_no\",\"to_be_logged_out\",\"active\",\"confirmed\",\"is_term_accept\",\"discount_message\",\"password\",\"confirmation_code\",\"uuid\",\"updated_at\",\"created_at\",\"id\"]', '[]', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '52b85879f316b0616b96a3081eda0e4d562464b91a1f17251ed0ccac5eeb8fe8d9cbec30a2d07deae96dc0097162a92ebbe9c1af7f8e44a5593bc9a2315f984e', '2022-07-27 09:23:06', '2022-07-27 09:23:06'),
(102, NULL, NULL, 'App\\Models\\Auth\\User', 13, 4, 'attached', '{\"user_group_id\":\"2\",\"first_name\":\"Garima\",\"last_name\":\"Singh\",\"username\":\"garima\",\"email\":\"garima@gmail.com\",\"mobile_no\":\"5555566677\",\"to_be_logged_out\":\"\",\"active\":1,\"confirmed\":0,\"is_term_accept\":1,\"discount_message\":0,\"password\":\"$2y$10$PHJtb0.C8oz2TATNAjA\\/NOfdRm4DNwCwp3bBIjaarHC0ROPD3Q1s6\",\"confirmation_code\":\"37acf6de5105e2223e9db5827102387b\",\"uuid\":\"66e9b06c-d9e3-4fdb-9782-2b49a09e2492\",\"updated_at\":\"2022-07-27 14:53:06\",\"created_at\":\"2022-07-27 14:53:06\",\"id\":13}', '[]', '{\"relation\":\"roles\",\"properties\":[{\"user_id\":13,\"role_id\":2}]}', '[]', 'http://localhost/ohcut/public/api/register', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'c2e4a156ca163ff6ebebb1d099d4cacda58c8e2846f76f6f1a98291837139c9d455120485fc9e08368f21b5c8c4c84081842b6096d59dc7d0a1fa07657b301bf', '2022-07-27 09:23:07', '2022-07-27 09:23:07'),
(103, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2022-07-28 09:14:05\",\"last_login_ip\":\"::1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2022-07-28 09:14:06\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://localhost/ohcut/public/login', '::1', 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', '9e6f3d0d68eba62d484c4158c99d1339814d6186121eba18550b5a151d9c48f19a825459d1ca3c25d0abf56cc5a1ab9dc8c86c6ede492f620c8f1fb59e806a80', '2022-07-28 03:44:06', '2022-07-28 03:44:06'),
(104, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2022-08-14 06:57:51\",\"last_login_ip\":\"::1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2022-08-14 06:57:51\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://localhost/ohcut/public/login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', '7eabbdd1461651fa25ec923d7f7b23c45ec3d15cb3db84f52b1a0b3fadb1adb9765d326a93ab85fd2866e159d21509add1609cc814f0fcaf23a6ef0e3c54f159', '2022-08-14 01:27:52', '2022-08-14 01:27:52'),
(105, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 6, 4, 'deleted', '{\"id\":6,\"uuid\":\"41ca8a88-b490-4553-ba71-e70e4afd5574\",\"user_group_id\":3,\"username\":null,\"first_name\":\"test\",\"last_name\":\"test\",\"email\":\"test@gmail.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":null,\"password\":\"$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"9636693a8824eeaf0ff027f78be55854\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":null,\"last_login_at\":null,\"last_login_ip\":null,\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":null,\"created_at\":\"2022-04-21 17:24:47\",\"updated_at\":\"2022-08-15 02:13:25\",\"deleted_at\":\"2022-08-15 02:13:25\"}', '[]', '[]', '[]', 'http://localhost/ohcut/public/admin/auth/user/6', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36', 'f5ff078c61d6e1816686c1a8d188ae59cae9e75dfa28c68f0bc1cfbadf4a86ae21f3cc13c32b15a5fe6a8ec3a2b923ff076c2615ec19b3d59b8250ceccac2d89', '2022-08-14 20:43:25', '2022-08-14 20:43:25'),
(106, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"info@webdevelopmentpark.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2022-10-11 15:48:33\",\"last_login_ip\":\"::1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2022-10-11 15:48:34\",\"deleted_at\":null}', '[\"last_login_at\",\"updated_at\"]', '[]', '[]', 'http://localhost/ohcut/public/login', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36', '2217c8f1b885d9dabf0a8cf4134ad0e8ed4b19ffeeb20f204df1255a81029df535a9e6d5ea8b73aab8ee8dcbb6a122c016a417463f7b01db7dd0a68af5a803a9', '2022-10-11 10:18:35', '2022-10-11 10:18:35'),
(107, 'App\\Models\\Auth\\User', 1, 'App\\Models\\Auth\\User', 1, 4, 'updated', '{\"id\":1,\"uuid\":\"04daa696-a06f-4367-93f1-1ebf7516b89f\",\"user_group_id\":3,\"username\":\"super admin\",\"first_name\":\"super\",\"last_name\":\"admin\",\"email\":\"vksinghjaipur@gmail.com\",\"avatar_type\":\"gravatar\",\"avatar_location\":\"70132.jpg\",\"password\":\"$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O\",\"password_changed_at\":null,\"active\":1,\"otp\":null,\"confirmation_code\":\"0e31364ae38ff072b14aafc3e01244a0\",\"confirmed\":1,\"mobile_no\":null,\"address\":null,\"zip_code\":null,\"profile_image\":null,\"date_of_birth\":null,\"timezone\":\"America\\/New_York\",\"last_login_at\":\"2023-04-14 06:08:34\",\"last_login_ip\":\"127.0.0.1\",\"to_be_logged_out\":0,\"status\":1,\"notification\":1,\"created_by\":1,\"updated_by\":null,\"is_term_accept\":0,\"discount_message\":0,\"remember_token\":\"S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0\",\"created_at\":\"2022-02-22 12:02:18\",\"updated_at\":\"2023-04-14 06:08:34\",\"deleted_at\":null}', '[\"last_login_at\",\"last_login_ip\",\"updated_at\"]', '[]', '[]', 'http://127.0.0.1:8000/login', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36', '029855721b97975e4b42c6edbdbe0b6d62e60f6dd354e4bc3218139bf238ea57999a2a77544b8dcbc36cff8a7a0adc834d256abad6f9be627bbd612a501756b0', '2023-04-14 00:38:34', '2023-04-14 00:38:34');

-- --------------------------------------------------------

--
-- Table structure for table `look_books`
--

DROP TABLE IF EXISTS `look_books`;
CREATE TABLE IF NOT EXISTS `look_books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `sub_cat_id` int(11) DEFAULT NULL,
  `look_book_image` varchar(191) DEFAULT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `service_length` varchar(255) DEFAULT NULL,
  `description` text,
  `tag` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `look_books`
--

INSERT INTO `look_books` (`id`, `seller_id`, `staff_id`, `category_id`, `sub_cat_id`, `look_book_image`, `service_type`, `service_length`, `description`, `tag`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 0, 0, NULL, '1651670152images2.jpg', NULL, NULL, NULL, NULL, 1, '2022-05-04 18:45:52', '2022-05-13 10:10:19', NULL),
(2, 2, 0, 1, NULL, '7362.jpg', NULL, NULL, NULL, NULL, 1, '2022-05-16 18:16:59', NULL, NULL),
(3, 2, 1, 1, 1, '2527.jpg', 'Male', 'small', 'no descroption', '#ganesh #madan', 1, '2022-05-16 18:16:59', '2022-06-08 18:41:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `look_book_favorites`
--

DROP TABLE IF EXISTS `look_book_favorites`;
CREATE TABLE IF NOT EXISTS `look_book_favorites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `look_book_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `look_book_favorites`
--

INSERT INTO `look_book_favorites` (`id`, `user_id`, `look_book_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 9, 1, '2022-06-23 12:00:40', NULL, NULL),
(7, 10, 2, '2022-06-23 12:25:27', '2022-06-23 13:35:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` longtext NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `message`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'New Message Test', '2022-05-13 11:31:40', '2022-05-13 12:55:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2017_09_03_144628_create_permission_tables', 1),
(9, '2017_09_11_174816_create_social_accounts_table', 1),
(10, '2017_09_26_140332_create_cache_table', 1),
(11, '2017_09_26_140528_create_sessions_table', 1),
(12, '2017_09_26_140609_create_jobs_table', 1),
(13, '2017_11_02_060149_create_blog_categories_table', 1),
(14, '2017_11_02_060149_create_blog_map_categories_table', 1),
(15, '2017_11_02_060149_create_blog_map_tags_table', 1),
(16, '2017_11_02_060149_create_blog_tags_table', 1),
(17, '2017_11_02_060149_create_blogs_table', 1),
(18, '2017_11_02_060149_create_faqs_table', 1),
(19, '2017_11_02_060149_create_pages_table', 1),
(20, '2018_04_08_033256_create_password_histories_table', 1),
(21, '2018_11_21_000001_create_ledgers_table', 1),
(22, '2019_08_19_000000_create_failed_jobs_table', 1),
(23, '2020_06_11_080530_create_email_templates_table', 1),
(24, '2020_06_18_060624_add_foreign_key_constraints_to_acl_tables', 1);

-- --------------------------------------------------------

--
-- Table structure for table `mobile_session`
--

DROP TABLE IF EXISTS `mobile_session`;
CREATE TABLE IF NOT EXISTS `mobile_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `session_key` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile_session`
--

INSERT INTO `mobile_session` (`id`, `user_id`, `session_key`, `created_at`, `modified`) VALUES
(1, 2, 'j7BIJbWR', '2022-03-16 08:23:09', NULL),
(2, 7, 'vK6plqgJ', '2022-04-22 10:49:00', NULL),
(3, 8, 'moTR0Bxc', '2022-05-04 05:18:21', '2022-06-02 05:52:27'),
(4, 9, 'M3ZNmRc0', '2022-05-06 06:06:05', NULL),
(5, 10, '', '2022-05-16 04:31:12', '2022-05-21 11:05:52'),
(6, 4, 't5aFsKlI', '2022-05-20 11:25:07', '2022-05-26 12:37:12'),
(7, 11, '5XfapuOM', '2022-07-21 10:35:23', NULL),
(8, 12, 'fJCW4Tra', '2022-07-21 10:38:29', '2022-07-22 13:36:07'),
(9, 13, 'sA62qJhW', '2022-07-27 14:53:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
CREATE TABLE IF NOT EXISTS `newsletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `user_id`, `title`, `message`, `type`, `is_read`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 9, 'New order', 'New order recieved successfully', 'order', 0, '2022-05-13 09:14:59', NULL, NULL),
(2, 9, 'New order', 'New order recieved successfully', 'order', 0, '2022-05-18 13:12:17', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `seller_id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `start_time` varchar(255) DEFAULT NULL,
  `end_time` varchar(255) DEFAULT NULL,
  `order_id` varchar(100) DEFAULT NULL,
  `trans_id` varchar(100) DEFAULT NULL,
  `service_date` date DEFAULT NULL,
  `order_date` date DEFAULT NULL,
  `total_amount` varchar(11) DEFAULT NULL,
  `coupon_code` varchar(11) DEFAULT NULL,
  `discount_amount` varchar(11) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `payment_type` varchar(255) DEFAULT NULL,
  `order_status` enum('Pending','Accept','Reject','Complete','Cancel') NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `seller_id`, `staff_id`, `amount`, `start_time`, `end_time`, `order_id`, `trans_id`, `service_date`, `order_date`, `total_amount`, `coupon_code`, `discount_amount`, `payment_status`, `payment_type`, `order_status`, `created_at`, `updated_at`) VALUES
(1, 8, 9, 1, '131', '08:41', '09:40', 'US1892257684', '123456', '2022-05-13', '2022-05-13', '131.0', '', '15.90000000', 'Complete', 'cash', 'Pending', '2022-05-13 09:14:54', NULL),
(2, 10, 9, 1, '86', '11:38', '12:37', 'US4288989945', '1234', '2022-05-20', '2022-05-18', '86', '', '11.4', 'Complete', 'cash', 'Pending', '2022-05-18 13:12:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
CREATE TABLE IF NOT EXISTS `packages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scooter_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `cannonical_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_keyword` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_page_slug_unique` (`page_slug`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `page_slug`, `description`, `cannonical_link`, `seo_title`, `seo_keyword`, `seo_description`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(11, 'Privacy Policy', 'privacy-policy', '<p>Hello</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, '2021-06-21 06:29:21', '2021-06-21 06:29:21', NULL),
(12, 'Terms and conditions', 'terms-and-conditions', '<p>term and condition</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, '2021-06-21 06:36:58', '2021-06-21 06:36:58', NULL),
(13, 'Travel fee and policy', 'travel-fee-and-policy', '<p>no description</p>', NULL, NULL, NULL, NULL, 1, 1, NULL, '2021-06-21 06:37:43', '2021-06-21 06:37:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_histories`
--

DROP TABLE IF EXISTS `password_histories`;
CREATE TABLE IF NOT EXISTS `password_histories` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_histories_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_histories`
--

INSERT INTO `password_histories` (`id`, `user_id`, `password`, `created_at`, `updated_at`) VALUES
(1, 4, '$2y$10$pM.qsmGF.GLy4PrWcHeV8.yoTwcUGMunOaxZJ21pCfHOhyXZtK2hm', '2021-04-22 06:32:18', '2021-04-22 06:32:18'),
(2, 5, '$2y$10$A5fHIb69E5FR3e7nxPWrceOBiF35B1hNxLNj7Nn.ayCtRsfSy7IwS', '2021-04-22 06:32:18', '2021-04-22 06:32:18'),
(3, 6, '$2y$10$.175YbXM1OBz0uvKtKxiousSWoyI5BQKU.FsIha3FGcWakRgzxftm', '2021-04-26 06:18:59', '2021-04-26 06:18:59'),
(4, 7, '$2y$10$edJR4H0db8yTS.e8yNTraeokYeiMtcJy8wuhiYj9WeUP4yezpg2S6', '2021-04-26 06:48:28', '2021-04-26 06:48:28'),
(5, 8, '$2y$10$oA6VeCiSGYvzreMKJ8.xAuJ5nvzJg4/ynCZNlXLg8YDiQLFOwgYFq', '2021-04-26 06:48:54', '2021-04-26 06:48:54'),
(6, 9, '$2y$10$FMGTCSgSeJVgkdqyKizO8OswOVtJ94femiwI.S/gHaPMND5F606Ky', '2021-04-26 06:51:01', '2021-04-26 06:51:01'),
(7, 10, '$2y$10$7lCifkJ.NHpTY1Aj8zVeu./tB9DcyVZJCGmzYO6zu819tOMkcdz6S', '2021-04-26 06:53:14', '2021-04-26 06:53:14'),
(8, 11, '$2y$10$3JuHQXzDN1nLaZXUAKAniepxjakNzYMUvWPIiMP7mgSQU4/xqpPE.', '2021-04-26 07:35:40', '2021-04-26 07:35:40'),
(9, 12, '$2y$10$D7pfsLLNa1PsmtiVHj4.3uNHTFm9F/Qky44qCCByk0M3sVFcwKwQy', '2021-04-26 09:46:06', '2021-04-26 09:46:06'),
(10, 13, '$2y$10$E6s100/sY9dB0YpJfaHy8Oglx72m7ckA1tu60dqxovfFI/FnsFVfi', '2021-04-28 07:47:36', '2021-04-28 07:47:36'),
(11, 13, '$2y$10$XR2sxWBhbQnMUyiyBXTL7ODBwDrz87WTiP/Jf0HnRzpla00O7v5dW', '2021-04-28 07:53:22', '2021-04-28 07:53:22'),
(12, 14, '$2y$10$ghCy.Y1lVaVSAcQwSznhV.q5IuxANe9PREcu9L5FzFhDHSDtcCnCm', '2021-05-10 09:12:42', '2021-05-10 09:12:42'),
(14, 16, '$2y$10$SWSfpzULJcUWA9g5XBdSe.6asw65rU6b/DacY7PTgtrgcY0EAOf8W', '2021-05-28 05:29:07', '2021-05-28 05:29:07'),
(15, 17, '$2y$10$xbUDekIFW2QVxT4YGvkCo.iVMQJZ2HPI9jqw34AbpWXgjoEMxO2D2', '2021-05-28 05:31:36', '2021-05-28 05:31:36'),
(18, 20, '$2y$10$Ix/ELegNNDNnXyLBSnLo5OGgZCZSqt0oX/7NX8f20WNuJE14mW3tq', '2021-06-16 00:16:42', '2021-06-16 00:16:42'),
(19, 21, '$2y$10$4hC3H8l.R7kvT2wDSCPhyuwtVtVokHbQ7.62w1cM7Ertdy65/gsYi', '2021-06-16 00:39:59', '2021-06-16 00:39:59'),
(21, 23, '$2y$10$FpWq9C5DMDWkuHwlEa8xguj0435/EblCaz8lFuXTbpTwh7v1Z0ALK', '2021-06-16 00:59:09', '2021-06-16 00:59:09'),
(22, 24, '$2y$10$djGYJhNfN6FMKcF.Omu7ReTRbgsF5vQ/WN1Z49cs.o5beNGIRkRgi', '2021-06-16 01:09:33', '2021-06-16 01:09:33'),
(23, 25, '$2y$10$UUrpTOgxVEi81qPiKPoq2OdkEYiJd30nIhyuPkMIRdOlmUKxHfT6S', '2021-06-16 01:21:32', '2021-06-16 01:21:32'),
(24, 26, '$2y$10$uwkc3DdeKqdyJNVe2H0fHO0kPEweRTC0jOFaN9DeemIVm5HL8ZTOe', '2021-06-16 01:31:11', '2021-06-16 01:31:11'),
(25, 27, '$2y$10$nt.Mk.0s3MHITSDY0OYfHeJlTOBHu.mWi7hQH3vWl0XyPSiy87pvC', '2021-06-16 01:37:37', '2021-06-16 01:37:37'),
(26, 28, '$2y$10$i2Ar/KQXpC/IDD0g8T4A5OPhD6ehcgCPsPzOktQX5hhRYsdXfnkTG', '2021-06-16 01:39:09', '2021-06-16 01:39:09'),
(27, 29, '$2y$10$Lr7HLkdmnckmVHOJXFAQy.i0rznXe/B58nWV0QHlffztuMjP8YLHe', '2021-06-16 01:45:39', '2021-06-16 01:45:39'),
(28, 30, '$2y$10$HX4KKxcxAidf95S8YkQq/.8w.Yt32WQy2GJoSePRL99kRRHC8fG/S', '2021-06-16 01:49:34', '2021-06-16 01:49:34'),
(29, 31, '$2y$10$3eB1n1Z4NIrVhbCO1Ot0/.2QEwS4aEqsuer0VWxdkfCYb..Iu3AHa', '2021-06-16 01:54:53', '2021-06-16 01:54:53'),
(30, 32, '$2y$10$lIZR5UNCoHCl5qMohsZ69eMkEQBHocgcxVNvJwi5p2Ir5LKfAGbQW', '2021-06-16 03:08:01', '2021-06-16 03:08:01'),
(31, 33, '$2y$10$sip90uyl7jWEpAgsKRVnEu/OZyliYtc8eW4NImeeU7VNcXNn9HPTC', '2021-06-16 03:29:39', '2021-06-16 03:29:39'),
(32, 34, '$2y$10$M9dW33dmFedCfpI7EZnSWOaUwI6aJzNmqhcp015CHmDImrorCeQGS', '2021-06-16 04:44:33', '2021-06-16 04:44:33'),
(33, 35, '$2y$10$EHfkFi6IEZqymGzoDvKpI.nrLHrDJY8a9hF4C9Ijw3kXdLej/DCkq', '2021-06-16 04:59:37', '2021-06-16 04:59:37'),
(34, 36, '$2y$10$VBWcn9RYxnM8strsS8G7vODPRMmU63nrWYENLdgu4neDCyPWOmtWy', '2021-06-16 05:00:22', '2021-06-16 05:00:22'),
(35, 37, '$2y$10$Cpq5yT2LsjVqjNX4HBn6GuIY8rY6So9HX86Mm.R.iVlC/CPd0rVsy', '2021-07-08 01:46:25', '2021-07-08 01:46:25'),
(36, 38, '$2y$10$c/xxJ26NabA5eBR7ghSc.e686hia5AmUqJIWyt5vhrDPT3wTrWstq', '2021-07-08 01:49:15', '2021-07-08 01:49:15'),
(37, 39, '$2y$10$j93sFTCL9t.BCfAaJdfibehbVcL.2lEwB1LHCU.AyAOFuImN22DQa', '2021-07-11 23:15:34', '2021-07-11 23:15:34'),
(38, 40, '$2y$10$p0CzyBNCvviyvDJJIXzyIOlfzRw5pzfdIhBFCXGnT3keMqmyrPbsq', '2021-07-13 07:22:29', '2021-07-13 07:22:29'),
(39, 41, '$2y$10$ieVT2rqhuGUtbNCzFv8JFeiv11grFIxU/mPNtFBY98GmUmwx6cboy', '2021-07-16 02:48:45', '2021-07-16 02:48:45'),
(40, 42, '$2y$10$YlNJh98Ox2pJzys8aTsRfeEKgkZ4zGhDnyMbnas4cQN/K.5B.834S', '2021-07-17 00:02:46', '2021-07-17 00:02:46'),
(41, 43, '$2y$10$osZU7qXaWW7DPzrfH1rX9egRw4Rck3vLf7ZJFj8yKOuAKnr3889iO', '2021-07-17 00:46:53', '2021-07-17 00:46:53'),
(42, 44, '$2y$10$0J.0oBwgu6eIljx.V6lUW.G5r.6dmzAYf70Su1WskNUMgcED.0FMe', '2021-07-19 02:50:21', '2021-07-19 02:50:21'),
(43, 45, '$2y$10$54HEFDcAnPmQUYjhEZ0KF.KelNTazlYEYrYlim24MyOTwWSXR9ome', '2021-07-23 01:23:01', '2021-07-23 01:23:01'),
(44, 46, '$2y$10$fFJ51Q6TbvMKYmfwr6Gt6O93LXJEqP9nkgX3IfU8Dnhz2pEMuM0ee', '2021-07-23 01:36:06', '2021-07-23 01:36:06'),
(45, 47, '$2y$10$i9v3/asMM/Px3vulE2yPiOqfFhDqtQqWkbZ.A3i39hqaCo9JIHufS', '2021-08-03 04:36:49', '2021-08-03 04:36:49'),
(46, 48, '$2y$10$pSv1uTE6N3xJP9AtIls9iec27g03mzUgg.V4MNe9wnk1pPODNHcO6', '2021-08-03 06:10:59', '2021-08-03 06:10:59'),
(47, 49, '$2y$10$SSHStXx7.EhlRgjOfUgTlOCKvKaZ2CjwxMkWU2/hH.olc13TFnDtK', '2021-08-03 08:46:33', '2021-08-03 08:46:33'),
(48, 50, '$2y$10$Ato7Nwh3/4hgwTVTeVzYtuhVJxsZO8/d/F.H9y46dqfBylNsWy7uW', '2021-08-04 12:51:28', '2021-08-04 12:51:28'),
(49, 51, '$2y$10$qA6EdLs2Zb0Pnc5qwQM.e.E6AptbLdiLgZlyYVHI1PhZ8l9dORjIC', '2021-08-06 10:45:05', '2021-08-06 10:45:05'),
(50, 52, '$2y$10$E9DbzRiO3zdHCSk8ogBLfu1EP.zSPFv2FuhY9JuJYzDgNeiJIpxIG', '2021-08-06 11:46:18', '2021-08-06 11:46:18'),
(51, 53, '$2y$10$MwFyPy0r9jFyvbtl1YmR/O.rLjXvoDECT.nlB.VPra4Ph0pzobsOa', '2021-08-06 11:50:12', '2021-08-06 11:50:12'),
(52, 54, '$2y$10$ySeWJ0.DxQEuM1fk3eAvXOZWjykGz.xlq.IHxiwq9ADorKURqYlBe', '2021-08-06 11:53:56', '2021-08-06 11:53:56'),
(53, 55, '$2y$10$TczxkSfNSynobWNWeJFM6O2U0n2wSOWwc7ievP6tNTZfgEiuWLLXa', '2021-08-06 11:57:47', '2021-08-06 11:57:47'),
(54, 56, '$2y$10$VHE9p6xE/dv0KqBRc2NYzeDI6SOVs0xTZXMpIvaJEnWH8tNiuyXVi', '2021-08-07 05:38:04', '2021-08-07 05:38:04'),
(55, 57, '$2y$10$R/wqsu6QhHr84peCx7wv.OHsO9aRBYh4ohYx29zxvn/66pL.MBGPy', '2021-08-07 08:17:57', '2021-08-07 08:17:57'),
(116, 119, '$2y$10$ABa2C9bQ8vQSBX/IoE/jl.3WDicYqH2Ip.TEIQPnFa2PfJzKXTPE.', '2021-12-01 18:14:03', '2021-12-01 18:14:03'),
(57, 59, '$2y$10$0SYKDZXDECcc28u4geq0X.flk/qHVabAqPlLbSqrDzr0SGEHTDPAq', '2021-08-12 09:35:41', '2021-08-12 09:35:41'),
(58, 60, '$2y$10$rzYuOBvKIQfzvn.uUcVqj.93aHyqnagykttzJM.E57th5zweJrLPe', '2021-08-17 04:34:35', '2021-08-17 04:34:35'),
(59, 61, '$2y$10$0uKiENB/cEkeNfiULNAL2e7we4n3kiha6Rpv0qoAc.qFQZ0UKqECq', '2021-08-17 05:15:55', '2021-08-17 05:15:55'),
(60, 62, '$2y$10$T.FkeZIQXpwVpymghGZLSusFm.3Cwe1lG9Fsv7OSg2VQUtRBtKgyG', '2021-08-17 06:51:01', '2021-08-17 06:51:01'),
(61, 63, '$2y$10$8UxKCTjB3ETCsyaCEfsUoOr/DIiPaphxLTU1Of.Rvu6oiRqTRut.C', '2021-08-18 06:33:54', '2021-08-18 06:33:54'),
(62, 64, '$2y$10$MNyg5m1jwXHn9H/9dkrngu5EjLf0KN20Cm8crcNx4poa1b9TnqIQq', '2021-08-18 07:02:40', '2021-08-18 07:02:40'),
(63, 65, '$2y$10$6j90Sxw34FH/BzOqJJhYquKdvcl9nnlfcoHyazgsDYn0QyhgrPsr.', '2021-08-18 09:30:18', '2021-08-18 09:30:18'),
(64, 66, '$2y$10$FE0RLxLEbQWg8LFjDw7gu.CLloxY2R/AolWRk5GrHHb7b5CEQUmLO', '2021-08-20 08:30:26', '2021-08-20 08:30:26'),
(65, 67, '$2y$10$cRW9dVsE1ZPDl0f65B/iFeCfAu.BbTSfLdEdqdKGVTPpE3rtQghBy', '2021-08-26 14:29:07', '2021-08-26 14:29:07'),
(66, 68, '$2y$10$L3asFo9YC2L1fQB6UoP1KurH4n33iFHXwVm4.l.GIdiaUPCFkFbRC', '2021-08-26 16:27:38', '2021-08-26 16:27:38'),
(67, 69, '$2y$10$HgmUKuXi.EC7vq6myW9Mn.yoSx36w95T0M9Gu1CkCVAUP3s7TvVES', '2021-08-26 16:28:41', '2021-08-26 16:28:41'),
(68, 70, '$2y$10$liLr9dAHHDXUUD1MKBVLvuLPr51OTdaHWFx749rp0afCl5WbGFTo2', '2021-08-28 00:28:52', '2021-08-28 00:28:52'),
(69, 71, '$2y$10$9xRsX9LWSs.UpOk5kVOReuS9RzzBGcz2OjRAzRKudO5XepwRF9zU6', '2021-09-02 14:17:06', '2021-09-02 14:17:06'),
(70, 72, '$2y$10$5s.7VQT5PuvhvTi4tNeTK.tgFPkQLHLRyVTcmcfIl8wSnHtfiH.Ni', '2021-09-04 16:15:05', '2021-09-04 16:15:05'),
(71, 73, '$2y$10$/nRTp2gAg/okiCpxr5pCJuW7cetLyR2.k4NOObjQRsZSF6Ci2qyeS', '2021-09-06 17:52:46', '2021-09-06 17:52:46'),
(72, 74, '$2y$10$bjIO5I7EmhYsrFTglTNkAOGLA/bKgiQ30YR8VAOEEAxZuz2njd922', '2021-09-07 13:41:41', '2021-09-07 13:41:41'),
(73, 75, '$2y$10$23xQgFmCFnaaXHiG1M7VG.YPohSswc1i17wHs1GROLwUFsHFFVhfO', '2021-09-09 12:18:38', '2021-09-09 12:18:38'),
(74, 76, '$2y$10$XeRIvQCcb95eWNbf3nU2AuZZwc2oEgRT8He8GwJ6sN/OXJzEHvb3K', '2021-09-09 12:39:10', '2021-09-09 12:39:10'),
(75, 77, '$2y$10$0.VCzHr88P4SmoNj01yhL.UC1D3CAl/v.QuqFPfRRhifUmtNuy9qG', '2021-09-09 12:46:09', '2021-09-09 12:46:09'),
(76, 78, '$2y$10$/qvV0TjsTuZ7/0oCFlSKb.iD1okdWLcX1ikwBQYymcSvE5NKUEj.S', '2021-09-09 12:58:55', '2021-09-09 12:58:55'),
(77, 79, '$2y$10$WGM2J5ww3QkewwH5zt22q.5./UlE0NBneGGOUws2SXEoS484a9x6C', '2021-09-10 13:42:00', '2021-09-10 13:42:00'),
(78, 80, '$2y$10$ZDrP4s43zHc6KX5VghszSOmrJKnDS3kZ9sk3P/t7gvxW2LWiCyPKa', '2021-09-11 14:08:00', '2021-09-11 14:08:00'),
(79, 81, '$2y$10$ORuW0PUOQpq56r9Evd/OAOIzdufhrJDU133WLD1JRmHp.fKeP6xQ.', '2021-09-11 14:11:01', '2021-09-11 14:11:01'),
(80, 82, '$2y$10$QRN8jEKT9igSuG6yF5jgEuTgylbjCO4wZWe613fvGTNINfGHVTQl2', '2021-09-13 11:24:59', '2021-09-13 11:24:59'),
(81, 83, '$2y$10$gJTSWTo.gdWbpsYf2EfhsOG1vVgEh5pSfsfj.6Po5.jdzPGmh7ZWq', '2021-09-13 11:32:28', '2021-09-13 11:32:28'),
(82, 84, '$2y$10$Xr2tkzl2hqwqVPv6Ftg4K.P48HwsWFkvYpDA1RogRA7Nnghu6o/9q', '2021-09-13 11:33:59', '2021-09-13 11:33:59'),
(83, 85, '$2y$10$SdgO8415uCm26fVwrr0Fg.kPzV2wV.3.so.UR6rL8O8uZd3UpxsC.', '2021-09-13 12:00:43', '2021-09-13 12:00:43'),
(84, 86, '$2y$10$HGFthBm9tsFSMvrkP5LhduMoqj6QhhL7KgnrwS.DiRv8QpPUyswFS', '2021-09-13 12:27:39', '2021-09-13 12:27:39'),
(85, 87, '$2y$10$gveEZR2ok5piutgJqM/Jle5T6v5ChBetxZMB4msX6QDixF9XiahUK', '2021-09-15 13:53:22', '2021-09-15 13:53:22'),
(131, 134, '$2y$10$c79USh142UmRlsVS3FhZ1OK3YJlfSd7g66OpabnGf6FtbWrdNbfXC', '2022-01-17 19:00:44', '2022-01-17 19:00:44'),
(87, 89, '$2y$10$nNk8Q0pkzDo2gomxbIUHz..ufKAMEgKjo19reTl1cyJtMUHeBbzxe', '2021-09-22 19:50:51', '2021-09-22 19:50:51'),
(88, 90, '$2y$10$QbThKF8TzEQdZiHbhAfha.Vy4JohLN7jNcohEmurZsa5BF2/pqKhC', '2021-09-23 18:38:10', '2021-09-23 18:38:10'),
(89, 91, '$2y$10$Ben0BgzqirHTFr4EBfJmtONUzCDUO4KtYLt1FQ2RbXFyk2hW2UqLO', '2021-09-23 18:44:46', '2021-09-23 18:44:46'),
(90, 92, '$2y$10$jbpt2D/EcmeIna25LFvEUevj1OoaPHJDK7xO45V5eZeg7Q82.V1Se', '2021-09-24 15:05:21', '2021-09-24 15:05:21'),
(91, 93, '$2y$10$9qE.D.7Wjah4HMg2CDmqVu8Od4s2ct0VL6ODimeCebmNP1F0/Gj3m', '2021-09-24 15:22:26', '2021-09-24 15:22:26'),
(92, 94, '$2y$10$rqVr9tJenQXeu2WA9ScWLuEoe6dm.Jryd.lRFkRFRluNIfiPv7LaC', '2021-09-24 16:03:39', '2021-09-24 16:03:39'),
(93, 95, '$2y$10$dpDpivXnbdDqo.W0h4FacuD3BEwdJ6rkbqTZ.1QHwxx/hRZO.TdEe', '2021-10-02 15:48:10', '2021-10-02 15:48:10'),
(94, 96, '$2y$10$iB6PI5HdafMjSixY5dw/UeATARi1oqaGVofraNdnnOkBMxD6hR8vC', '2021-10-04 14:16:58', '2021-10-04 14:16:58'),
(95, 97, '$2y$10$t2c9GBHjI9ftY01x7KDRIeE3NIjRrm2wIuICKGAIhYANp4dQn8Ovi', '2021-10-04 15:43:43', '2021-10-04 15:43:43'),
(96, 98, '$2y$10$78mAXLEdqF1ROTajtkb28edrZs70sQIZ7putupw2IWy2omUa90d7S', '2021-10-05 16:55:24', '2021-10-05 16:55:24'),
(97, 100, '$2y$10$n8riT7SRloCHO6lhbks9uey0V.395pQ.YFf.ugn8KnTu6QAbbTF0W', '2021-10-05 17:14:25', '2021-10-05 17:14:25'),
(98, 101, '$2y$10$34.7EtrgOkfVmMihQkjbxe7ROke6tdIkAZqbg3TcmLarQyN9Ziqru', '2021-10-05 17:18:36', '2021-10-05 17:18:36'),
(99, 102, '$2y$10$ycK5sXcxWCcz0wejZOCGK.xfDdmTDLQSfnKU2D89rgTEN7YK7dDbS', '2021-10-05 17:21:31', '2021-10-05 17:21:31'),
(100, 103, '$2y$10$vQpUJZvsYUWZVyINFDEm6elegT8rwwobrSiZ4B930TwCpvqQAOaP2', '2021-10-05 18:23:27', '2021-10-05 18:23:27'),
(101, 104, '$2y$10$EAz/qa/RZt4QZVqyvwbZtOQ9hrUBQxfkoIOBFoLTLVPk96i3WarMW', '2021-10-11 12:49:14', '2021-10-11 12:49:14'),
(102, 105, '$2y$10$7XVPZJNtnkMSa/7eZZ3/zeJjdbCfbm9pduUZJiNAqkq33LHWDPRHW', '2021-10-21 13:55:16', '2021-10-21 13:55:16'),
(103, 106, '$2y$10$8G5zfrRdfJ3V1RhDcTfb6u6/T4Nae9hdiDROQmidGni3LhuSQOBEW', '2021-10-21 15:03:51', '2021-10-21 15:03:51'),
(104, 107, '$2y$10$TfHn1YoqKSUw7IZeYREo4OrBEgHar8bmsCy.8GCLABmz6zOzQfccG', '2021-10-21 16:04:07', '2021-10-21 16:04:07'),
(105, 108, '$2y$10$e9yXeI0Ohd9SUGImqk/lcerNOCJSZGlDUBDye0k2X8CLwU.oV6fvm', '2021-10-21 16:26:33', '2021-10-21 16:26:33'),
(106, 109, '$2y$10$4KFeu9duUuKQYhjKmRCD4.DtudEmKZrv9pfKRGd489qRtvdB0w/Me', '2021-10-21 19:32:53', '2021-10-21 19:32:53'),
(107, 110, '$2y$10$oqwqG/E3oJ2BXKsYRxlaeerVCthk9qvdi0nW3JtQt2efZnL44yGjG', '2021-10-22 18:23:43', '2021-10-22 18:23:43'),
(108, 111, '$2y$10$TBXqbS59go1FSRM27m.bh.ge1hU/sMj6L9TRNcthWNfqmvNc7rBIG', '2021-11-06 13:50:05', '2021-11-06 13:50:05'),
(109, 112, '$2y$10$gExfDJcM13OkX7NScJnXJOttdHJzsKhoJIBojoS3QIO.51zraaSvq', '2021-11-08 19:01:19', '2021-11-08 19:01:19'),
(110, 113, '$2y$10$.bVfsHOw7Fj1LAdbPwugHOacYss8F5GRvmLbqtmHINL.EktojFI/2', '2021-11-11 18:15:18', '2021-11-11 18:15:18'),
(111, 114, '$2y$10$DhZ9HA4X7OzfjcTnQLC7rOLtUlMdEKadVEt65BHI3U1KwGjk9.Ynm', '2021-11-12 18:39:29', '2021-11-12 18:39:29'),
(112, 115, '$2y$10$u544Jut9mgg7rnoA602b/uh8Zbfx92sRVMoMAhdANxgg7F7orVNVS', '2021-11-12 18:50:33', '2021-11-12 18:50:33'),
(113, 116, '$2y$10$IilHC7LPAq/YaDvDvV4ZLeeWbGyb1JzLIx2TFBDYQbgHYDXzSKmCC', '2021-11-12 19:04:21', '2021-11-12 19:04:21'),
(114, 117, '$2y$10$hY78aA4fY1uB4.df7kNHQ.NXMjyQdcnpj5S06V5xEf.V9piOHBNyu', '2021-12-01 13:39:15', '2021-12-01 13:39:15'),
(115, 118, '$2y$10$8U.uSPhcdep86B2QIrMQB.oRMjKeKQ/K9V2dMpGP/D2AfITeCdhrK', '2021-12-01 15:39:01', '2021-12-01 15:39:01'),
(117, 120, '$2y$10$rkgh.IxB5YyuVDaQOyCa4u7uA0tvodU.JaeBD8NlCfSPYT3OGAvLi', '2021-12-01 18:21:43', '2021-12-01 18:21:43'),
(118, 121, '$2y$10$MILUmC2jJeRkvMQcG679LeCEgd/j6KVGbfX0LJBieRA37oH1UtmNi', '2021-12-02 12:01:58', '2021-12-02 12:01:58'),
(119, 122, '$2y$10$Ks8iSOqwZu4TurJIxptjbO6dEPWjwFaN.vBTgIkKsWNAHmDyeBWGC', '2021-12-02 13:44:56', '2021-12-02 13:44:56'),
(120, 123, '$2y$10$ja7VAOtcE4dg4M/o/4GEE.3gNVBSmH20aC17U8va./089gr2PZU4O', '2021-12-02 14:15:11', '2021-12-02 14:15:11'),
(121, 124, '$2y$10$ZAuTLlC2AcxDZis/d1qNJefK4EQmrz57WnRy/.NxzPj7kzkiN7rLW', '2021-12-14 09:00:53', '2021-12-14 09:00:53'),
(122, 125, '$2y$10$y9MjntQhOWyMr9z0aeV3sO3yuFsU50G1KiuLK/b2eNTGaL4bPS3zW', '2021-12-14 09:19:49', '2021-12-14 09:19:49'),
(123, 126, '$2y$10$xVV/C.g4.rR41CylSHROcOetnQC2/0V2reSVUd8RQhiW03I9idE5u', '2021-12-21 12:31:46', '2021-12-21 12:31:46'),
(124, 127, '$2y$10$cJ2xqwj4xwecl8Wwk.S9L.zu3bgGKvZ85KWXrilWP4iUUAxm.fcPa', '2021-12-21 14:28:19', '2021-12-21 14:28:19'),
(125, 128, '$2y$10$fXwdhVuEtG8hAjywoPPAKeCJ2HuwG00R7QP09HT//sh1/UjIzN3Um', '2021-12-21 14:40:50', '2021-12-21 14:40:50'),
(126, 129, '$2y$10$UU4F2bJNXVsO5O7Fy5oo1uVBspzBJm3fzFYiaifA0SmZ6uqyEjSY2', '2021-12-21 15:04:39', '2021-12-21 15:04:39'),
(127, 130, '$2y$10$Zm6MbrTq2XRsdXKzxzBOweedELWf28zH0MRa/jbTvz/8uLWtsTxUy', '2021-12-23 19:04:23', '2021-12-23 19:04:23'),
(128, 131, '$2y$10$seh4KzBLWaYk3twsc37NR.hH9rrA9y3QznW90LnNHUBKkRXfkOjcW', '2021-12-24 13:38:23', '2021-12-24 13:38:23'),
(129, 132, '$2y$10$Ite9qKqpPi.O1az59rko6O5nfmcZS4tcSyyHvWQpFacaVRCRaiSvq', '2021-12-24 13:40:42', '2021-12-24 13:40:42'),
(130, 133, '$2y$10$0GXIreX7D4oOImnI/SCmlOR4u0VigNF1wcgXOkr/rOSZr6bn3cUKK', '2022-01-12 12:27:29', '2022-01-12 12:27:29'),
(132, 135, '$2y$10$zP.Q21lty.Hc0hH/0fcO/urgutEpTy3VhDwIb.2xKudekiAzjFxn.', '2022-03-15 11:40:00', '2022-03-15 11:40:00'),
(133, 2, '$2y$10$lol0XginMJpUbQm7SwCmy.CoiIHT8Gq20jXgxtTxRpL1C9oXU0H1K', '2022-03-16 13:53:09', '2022-03-16 13:53:09'),
(134, 3, '$2y$10$lJxXuOrFe/pg6y0tEqTj6eIyQ6/7WBdqW7Es/ECEzpiJJgdWVjrqC', '2022-04-20 17:24:31', '2022-04-20 17:24:31'),
(135, 4, '$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C', '2022-04-21 05:38:13', '2022-04-21 05:38:13'),
(136, 5, '$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN/G0/.C0bAA3kN3eZsHzH60coKYxy', '2022-04-21 07:11:54', '2022-04-21 07:11:54'),
(137, 6, '$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe', '2022-04-21 11:54:47', '2022-04-21 11:54:47'),
(138, 7, '$2y$10$ao6g1wsJg5xKobRdZylmTOclkqsoWz3nOLQcAfu4bb4Db6.6rRNV6', '2022-04-22 16:19:00', '2022-04-22 16:19:00'),
(139, 8, '$2y$10$IAJXukkSFRN7ghtloJzYheZusUoaX1Jra.t.5/116WVOu/vKkBXY2', '2022-05-04 10:48:21', '2022-05-04 10:48:21'),
(140, 9, '$2y$10$MGVmXPe3A9Ldp1sy3Hzg4ONt7umOja2i8cvSXbtqBXMMwjgx73Syi', '2022-05-06 11:36:05', '2022-05-06 11:36:05'),
(141, 10, '$2y$10$Kf7OLfUKfXpXhasCTlmro.cVUHEkvinBZaiASfbuMGKhWoLdA7i9e', '2022-05-16 10:01:12', '2022-05-16 10:01:12'),
(142, 11, '$2y$10$gr4tKhbiLlMNT2syaURYVe.oP4ZZ/YLQUZt7/bjjAdeElC7/LNn2K', '2022-07-21 05:05:23', '2022-07-21 05:05:23'),
(143, 12, '$2y$10$53Eite7CfalkzuQGSFMG/ecoTg2VowJ48omBYYdVlgwSWGl3nFuWa', '2022-07-21 05:08:29', '2022-07-21 05:08:29'),
(144, 13, '$2y$10$PHJtb0.C8oz2TATNAjA/NOfdRm4DNwCwp3bBIjaarHC0ROPD3Q1s6', '2022-07-27 09:23:06', '2022-07-27 09:23:06');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`email`, `token`, `created_at`) VALUES
('test@gmail.com', '$2y$10$x5ESyy0DWb7V7/usWUc90..aHW5BrgRsNuKeT0hg5/aUE4QP7uT7e', '2021-04-28 06:05:37'),
('ganesh@mailinator.com', '$2y$10$ZqoDgLHFaOaiGKyzna63Ge7hnjq7E75KY8SPEmMZIkEH.E8grn0Mm', '2021-04-28 06:06:25'),
('Test13@gmail.com', '$2y$10$Q4A.MV8oHQwAIQDrNIYN6.F6OBALy2oWgo7q38y1/b7ZPjPJLd1E.', '2021-04-30 04:03:25');

-- --------------------------------------------------------

--
-- Table structure for table `payment_history`
--

DROP TABLE IF EXISTS `payment_history`;
CREATE TABLE IF NOT EXISTS `payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `ride_booking_id` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  `paid_amount` varchar(55) DEFAULT NULL,
  `total_amount` varchar(55) DEFAULT NULL,
  `gateway` varchar(55) DEFAULT NULL,
  `token_id` varchar(255) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `payment_transactions`
--

DROP TABLE IF EXISTS `payment_transactions`;
CREATE TABLE IF NOT EXISTS `payment_transactions` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner_id` bigint(20) UNSIGNED NOT NULL,
  `invoice_id` int(10) UNSIGNED DEFAULT NULL,
  `sourcable_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sourcable_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` double(8,2) NOT NULL DEFAULT '0.00',
  `paid_currency` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_amount` double(8,2) DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` timestamp NULL DEFAULT NULL,
  `status` enum('completed','pending','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'completed',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `extra` text COLLATE utf8mb4_unicode_ci,
  `reference` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_transactions_owner_type_owner_id_index` (`owner_type`,`owner_id`),
  KEY `payment_transactions_sourcable_type_sourcable_id_index` (`sourcable_type`,`sourcable_id`),
  KEY `payment_transactions_invoice_id_foreign` (`invoice_id`),
  KEY `payment_transactions_created_by_index` (`created_by`),
  KEY `payment_transactions_updated_by_index` (`updated_by`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `sort`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'view-backend', 'View Backend', 1, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(2, 'view-frontend', 'View Frontend', 2, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(3, 'view-access-management', 'View Access Management', 3, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'view-user-management', 'View User Management', 4, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(5, 'view-active-user', 'View Active User', 5, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(6, 'view-deactive-user', 'View Deactive User', 6, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(7, 'view-deleted-user', 'View Deleted User', 7, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(8, 'show-user', 'Show User Details', 8, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(9, 'create-user', 'Create User', 9, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(10, 'edit-user', 'Edit User', 9, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(11, 'delete-user', 'Delete User', 10, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(12, 'activate-user', 'Activate User', 11, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(13, 'deactivate-user', 'Deactivate User', 12, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(14, 'login-as-user', 'Login As User', 13, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(15, 'clear-user-session', 'Clear User Session', 14, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(16, 'view-role-management', 'View Role Management', 15, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(17, 'create-role', 'Create Role', 16, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(18, 'edit-role', 'Edit Role', 17, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(19, 'delete-role', 'Delete Role', 18, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(20, 'view-permission-management', 'View Permission Management', 19, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(21, 'create-permission', 'Create Permission', 20, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(22, 'edit-permission', 'Edit Permission', 21, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(23, 'delete-permission', 'Delete Permission', 22, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(24, 'view-page', 'View Page', 23, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(25, 'create-page', 'Create Page', 24, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(26, 'edit-page', 'Edit Page', 25, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(27, 'delete-page', 'Delete Page', 26, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(28, 'view-email-template', 'View Email Templates', 27, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(29, 'create-email-template', 'Create Email Templates', 28, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(30, 'edit-email-template', 'Edit Email Templates', 29, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(31, 'delete-email-template', 'Delete Email Templates', 30, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(32, 'edit-settings', 'Edit Settings', 31, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(33, 'view-blog-category', 'View Blog Categories Management', 32, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(34, 'create-blog-category', 'Create Blog Category', 33, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(35, 'edit-blog-category', 'Edit Blog Category', 34, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(36, 'delete-blog-category', 'Delete Blog Category', 35, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(37, 'view-blog-tag', 'View Blog Tags Management', 36, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(38, 'create-blog-tag', 'Create Blog Tag', 37, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(39, 'edit-blog-tag', 'Edit Blog Tag', 38, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(40, 'delete-blog-tag', 'Delete Blog Tag', 39, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(41, 'view-blog', 'View Blogs Management', 40, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(42, 'create-blog', 'Create Blog', 41, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(43, 'edit-blog', 'Edit Blog', 42, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(44, 'delete-blog', 'Delete Blog', 43, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(45, 'view-faq', 'View FAQ Management', 44, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(46, 'create-faq', 'Create FAQ', 45, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(47, 'edit-faq', 'Edit FAQ', 46, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(48, 'delete-faq', 'Delete FAQ', 47, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

DROP TABLE IF EXISTS `permission_role`;
CREATE TABLE IF NOT EXISTS `permission_role` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_role_permission_id_foreign` (`permission_id`),
  KEY `permission_role_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`) VALUES
(71, 48, 2),
(70, 47, 2),
(69, 46, 2),
(68, 45, 2),
(67, 44, 2),
(66, 43, 2),
(65, 42, 2),
(64, 41, 2),
(63, 40, 2),
(62, 39, 2),
(61, 38, 2),
(60, 37, 2),
(59, 36, 2),
(58, 35, 2),
(57, 34, 2),
(56, 33, 2),
(55, 31, 2),
(54, 30, 2),
(53, 29, 2),
(52, 28, 2),
(51, 27, 2),
(50, 26, 2),
(49, 25, 2),
(48, 24, 2),
(47, 20, 2),
(46, 16, 2),
(45, 8, 2),
(44, 7, 2),
(43, 6, 2),
(42, 5, 2),
(41, 4, 2),
(40, 3, 2),
(39, 1, 2),
(34, 2, 3);

-- --------------------------------------------------------

--
-- Table structure for table `permission_user`
--

DROP TABLE IF EXISTS `permission_user`;
CREATE TABLE IF NOT EXISTS `permission_user` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_user_permission_id_foreign` (`permission_id`),
  KEY `permission_user_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=143 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_user`
--

INSERT INTO `permission_user` (`id`, `permission_id`, `user_id`) VALUES
(1, 42, 2),
(2, 34, 2),
(3, 38, 2),
(4, 29, 2),
(5, 46, 2),
(6, 25, 2),
(7, 44, 2),
(8, 36, 2),
(9, 40, 2),
(10, 31, 2),
(11, 48, 2),
(12, 27, 2),
(13, 43, 2),
(14, 35, 2),
(15, 39, 2),
(16, 30, 2),
(17, 47, 2),
(18, 26, 2),
(19, 8, 2),
(20, 3, 2),
(21, 5, 2),
(22, 1, 2),
(23, 33, 2),
(24, 37, 2),
(25, 41, 2),
(26, 6, 2),
(27, 7, 2),
(28, 28, 2),
(29, 45, 2),
(30, 24, 2),
(31, 20, 2),
(32, 16, 2),
(33, 4, 2),
(34, 2, 3),
(35, 1, 15),
(36, 2, 15),
(37, 1, 21),
(38, 2, 21),
(39, 1, 22),
(40, 2, 22),
(41, 2, 55),
(141, 48, 4),
(43, 1, 5),
(44, 3, 5),
(45, 4, 5),
(46, 5, 5),
(47, 6, 5),
(48, 7, 5),
(49, 8, 5),
(50, 16, 5),
(51, 20, 5),
(52, 24, 5),
(53, 25, 5),
(54, 26, 5),
(55, 27, 5),
(56, 28, 5),
(57, 29, 5),
(58, 30, 5),
(59, 31, 5),
(60, 33, 5),
(61, 34, 5),
(62, 35, 5),
(63, 36, 5),
(64, 37, 5),
(65, 38, 5),
(66, 39, 5),
(67, 40, 5),
(68, 41, 5),
(69, 42, 5),
(70, 43, 5),
(71, 44, 5),
(72, 45, 5),
(73, 46, 5),
(74, 47, 5),
(75, 48, 5),
(140, 47, 4),
(139, 46, 4),
(138, 45, 4),
(137, 44, 4),
(136, 43, 4),
(135, 42, 4),
(134, 41, 4),
(133, 40, 4),
(132, 39, 4),
(131, 38, 4),
(130, 37, 4),
(129, 36, 4),
(128, 35, 4),
(127, 34, 4),
(126, 33, 4),
(125, 31, 4),
(124, 30, 4),
(123, 29, 4),
(122, 28, 4),
(121, 27, 4),
(120, 26, 4),
(119, 25, 4),
(118, 24, 4),
(117, 20, 4),
(116, 16, 4),
(115, 8, 4),
(114, 7, 4),
(113, 6, 4),
(112, 5, 4),
(111, 4, 4),
(110, 3, 4),
(109, 1, 4),
(142, 2, 6);

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

DROP TABLE IF EXISTS `plans`;
CREATE TABLE IF NOT EXISTS `plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `price` varchar(20) DEFAULT NULL,
  `number_of_staff` int(11) DEFAULT NULL,
  `no_off_staff` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `name`, `price`, `number_of_staff`, `no_off_staff`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Unlimited', '9', NULL, 0, 1, '2021-04-30 08:45:24', '2021-06-03 08:57:15', NULL),
(2, 'Professional', '10', NULL, 0, 1, '2021-04-30 08:45:24', '2021-05-28 17:28:19', NULL),
(3, 'Standard', '15', NULL, 0, 1, '2021-04-30 08:45:48', '2021-05-28 17:28:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `price_types`
--

DROP TABLE IF EXISTS `price_types`;
CREATE TABLE IF NOT EXISTS `price_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `price_types`
--

INSERT INTO `price_types` (`id`, `type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Fixed', '2021-08-19 17:10:20', NULL, NULL),
(2, 'Various', '2021-08-19 17:10:30', NULL, NULL),
(3, 'starts at', '2021-08-19 17:10:50', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `category_id` int(11) NOT NULL DEFAULT '0',
  `sub_cat_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `user_id`, `name`, `description`, `price`, `category_id`, `sub_cat_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Test 1', 'My Description', 500.00, 1, 1, 1, '2022-05-17 08:54:38', '2022-05-18 09:00:45', NULL),
(2, 1, 'Facial Cream', 'Facial Cream', 200.00, 2, 14, 1, '2022-05-17 08:55:38', '2022-05-18 09:00:58', NULL),
(3, 1, 'Beauty Saloon', 'no description', 362.00, 1, 1, 1, '2022-05-19 08:32:10', NULL, NULL),
(4, 1, 'Baby Hair cut', 'no description', 150.00, 1, 2, 1, '2022-05-19 08:33:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_banners`
--

DROP TABLE IF EXISTS `product_banners`;
CREATE TABLE IF NOT EXISTS `product_banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_banner` varchar(191) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product_banners`
--

INSERT INTO `product_banners` (`id`, `product_banner`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '1652793253hair-salon.jpg', 1, '2022-05-17 18:32:06', '2022-05-17 13:14:13', NULL),
(2, '1652793270Hair-salon_leaf_Getty-Images.png', 1, '2022-05-17 13:14:30', NULL, NULL),
(3, '1652793281homepage.jpg', 1, '2022-05-17 13:14:41', NULL, NULL),
(4, '1652793288Slider1.jpg', 1, '2022-05-17 13:14:48', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_cart`
--

DROP TABLE IF EXISTS `product_cart`;
CREATE TABLE IF NOT EXISTS `product_cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `price` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `status` enum('pending','complete') NOT NULL DEFAULT 'pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_cart`
--

INSERT INTO `product_cart` (`id`, `user_id`, `p_id`, `quantity`, `price`, `order_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(13, 633773, 1, 1, '500', 'US3019848268', 'complete', '2022-05-30 13:56:01', '2022-05-31 14:25:49', NULL),
(12, 4, 3, 1, '724', NULL, 'pending', '2022-05-27 13:46:53', '2022-05-27 16:34:25', NULL),
(11, 4, 2, 1, '400', NULL, 'pending', '2022-05-27 13:46:50', '2022-05-27 16:34:55', NULL),
(10, 4, 1, 1, '500', NULL, 'pending', '2022-05-27 13:46:47', '2022-05-27 17:56:59', NULL),
(14, 633773, 1, 1, '500', 'US6926834560', 'complete', '2022-05-31 14:26:43', '2022-05-31 14:58:34', NULL),
(15, 633773, 1, 1, '500', 'US2231094010', 'complete', '2022-05-31 15:09:29', '2022-05-31 15:09:50', NULL),
(16, 633773, 1, 1, '500', 'US4278701368', 'complete', '2022-05-31 15:12:11', '2022-05-31 15:12:30', NULL),
(17, 8, 1, 1, '500', 'US7061922129', 'complete', '2022-06-02 11:21:25', '2022-06-02 11:27:28', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_image`
--

DROP TABLE IF EXISTS `product_image`;
CREATE TABLE IF NOT EXISTS `product_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_image`
--

INSERT INTO `product_image` (`id`, `p_id`, `image`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, '119.jpeg', 1, '2022-05-17 08:54:38', NULL, NULL),
(2, 1, '388.jpeg', 1, '2022-05-17 08:54:38', NULL, NULL),
(3, 1, '747.jpeg', 1, '2022-05-17 08:54:38', NULL, NULL),
(4, 2, '565.jpeg', 1, '2022-05-17 08:55:38', NULL, NULL),
(5, 2, '460.jpeg', 1, '2022-05-17 08:55:38', NULL, NULL),
(6, 3, '662.jpeg', 1, '2022-05-19 08:32:10', NULL, NULL),
(7, 3, '379.jpeg', 1, '2022-05-19 08:32:10', NULL, NULL),
(8, 4, '281.jpeg', 1, '2022-05-19 08:33:26', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_items`
--

DROP TABLE IF EXISTS `product_items`;
CREATE TABLE IF NOT EXISTS `product_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_items`
--

INSERT INTO `product_items` (`id`, `user_id`, `item_id`, `p_id`, `price`, `quantity`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 633773, 1, 1, '500', 1, '2022-05-31 14:25:49', '2022-05-31 14:25:49', NULL),
(2, 633773, 2, 1, '500', 1, '2022-05-31 14:58:34', '2022-05-31 14:58:34', NULL),
(3, 633773, 3, 1, '500', 1, '2022-05-31 15:09:50', '2022-05-31 15:09:50', NULL),
(4, 633773, 4, 1, '500', 1, '2022-05-31 15:12:30', '2022-05-31 15:12:30', NULL),
(5, 8, 5, 3, '500', 1, '2022-06-02 11:27:28', '2022-06-02 16:55:36', NULL),
(7, 8, 5, 2, '500', 1, '2022-06-02 11:27:28', '2022-06-02 16:37:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_orders`
--

DROP TABLE IF EXISTS `product_orders`;
CREATE TABLE IF NOT EXISTS `product_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_amount` varchar(55) DEFAULT NULL,
  `discount` varchar(255) DEFAULT NULL,
  `shipping_address` varchar(255) DEFAULT NULL,
  `shipping_charge` varchar(11) NOT NULL DEFAULT '0',
  `payment_method` varchar(255) DEFAULT NULL,
  `trans_id` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `payment_status` enum('Success','Fail') NOT NULL DEFAULT 'Success',
  `order_status` enum('pending','cancel','complete','dispatch') NOT NULL DEFAULT 'pending',
  `payment_date` date DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_orders`
--

INSERT INTO `product_orders` (`id`, `user_id`, `total_amount`, `discount`, `shipping_address`, `shipping_charge`, `payment_method`, `trans_id`, `order_id`, `payment_status`, `order_status`, `payment_date`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 633773, '$500', NULL, '1', '0', 'strip', '3352483', 'US3019848268', 'Success', 'pending', '2022-05-31', '2022-05-31 14:25:49', '2022-05-31 14:25:49', NULL),
(2, 633773, '$500', NULL, '1', '0', 'paypal', '707712', 'US6926834560', 'Success', 'pending', '2022-05-31', '2022-05-31 14:58:34', '2022-05-31 14:58:34', NULL),
(3, 633773, '$500', NULL, '1', '0', 'strip', '4881028', 'US2231094010', 'Success', 'pending', '2022-05-31', '2022-05-31 15:09:50', '2022-05-31 15:09:50', NULL),
(4, 633773, '$500', NULL, '1', '0', 'strip', '2992837', 'US4278701368', 'Success', 'pending', '2022-05-31', '2022-05-31 15:12:30', '2022-05-31 15:12:30', NULL),
(5, 8, '$500', NULL, '2', '0', 'strip', '6730299', 'US7061922129', 'Success', 'dispatch', '2022-06-02', '2022-06-02 11:27:28', '2022-10-16 14:45:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_return`
--

DROP TABLE IF EXISTS `product_return`;
CREATE TABLE IF NOT EXISTS `product_return` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `return_item_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `price` varchar(255) DEFAULT NULL,
  `quantity` varchar(255) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `resion` text,
  `status` enum('pending','complete','collect') NOT NULL DEFAULT 'pending',
  `payment_status` enum('Pending','Refund') NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

DROP TABLE IF EXISTS `product_reviews`;
CREATE TABLE IF NOT EXISTS `product_reviews` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `p_id` int(11) NOT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `rating` varchar(20) DEFAULT NULL,
  `description` text,
  `image` text,
  `image2` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product_reviews`
--

INSERT INTO `product_reviews` (`id`, `user_id`, `p_id`, `order_id`, `rating`, `description`, `image`, `image2`, `created_at`, `updated_at`, `deleted_at`) VALUES
(3, 8, 3, 'US7061922129', '2', 'Good product', '8072.jpg', '78433.jpg', '2022-06-02 15:46:00', '2022-06-02 16:55:07', NULL),
(2, 8, 2, 'US7061922129', '5', 'Good product', '8072.jpg', '78433.jpg', '2022-06-02 15:46:00', '2022-06-02 16:37:43', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

DROP TABLE IF EXISTS `ratings`;
CREATE TABLE IF NOT EXISTS `ratings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `staff_id` int(11) DEFAULT NULL,
  `order_id` varchar(255) DEFAULT NULL,
  `rating` varchar(55) DEFAULT NULL,
  `comment` text,
  `status` tinyint(1) DEFAULT '1',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `refrences`
--

DROP TABLE IF EXISTS `refrences`;
CREATE TABLE IF NOT EXISTS `refrences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(200) DEFAULT NULL,
  `refren_style` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position_title` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `organization_name` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `all` tinyint(1) NOT NULL DEFAULT '0',
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_unique` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `all`, `sort`, `status`, `created_by`, `updated_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Administrator', 1, 1, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(2, 'Saloon', 0, 2, 0, 1, 1, '2021-04-22 06:32:18', '2022-04-21 07:13:35', NULL),
(3, 'User', 0, 3, 1, 1, NULL, '2021-04-22 06:32:18', '2021-04-22 06:32:18', NULL),
(4, 'Seller', 0, 4, 0, 1, 1, '2022-04-21 05:37:29', '2022-04-21 07:13:26', '2022-04-21 07:13:26');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
CREATE TABLE IF NOT EXISTS `role_user` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  KEY `role_user_role_id_foreign` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1),
(2, 2, 3),
(3, 3, 3),
(4, 4, 2),
(5, 5, 2),
(6, 6, 3),
(7, 7, 3),
(8, 8, 3),
(9, 9, 2),
(10, 10, 3),
(11, 11, 3),
(12, 12, 3),
(13, 13, 2);

-- --------------------------------------------------------

--
-- Table structure for table `saller_business_types`
--

DROP TABLE IF EXISTS `saller_business_types`;
CREATE TABLE IF NOT EXISTS `saller_business_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_type_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `seller_business_services`
--

DROP TABLE IF EXISTS `seller_business_services`;
CREATE TABLE IF NOT EXISTS `seller_business_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_type_id` int(11) DEFAULT NULL,
  `service_type_id` varchar(255) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `price` int(11) DEFAULT NULL,
  `price_type` varchar(255) NOT NULL,
  `special_offer` varchar(255) DEFAULT NULL,
  `person` int(11) DEFAULT NULL,
  `home` int(11) DEFAULT NULL,
  `virtual` int(11) DEFAULT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `service_image` varchar(255) NOT NULL,
  `time_type` tinyint(1) NOT NULL DEFAULT '0',
  `in_time` varchar(255) DEFAULT NULL,
  `in_week` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_business_services`
--

INSERT INTO `seller_business_services` (`id`, `user_id`, `business_type_id`, `service_type_id`, `type`, `price`, `price_type`, `special_offer`, `person`, `home`, `virtual`, `duration`, `service_image`, `time_type`, `in_time`, `in_week`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 9, 1, '2', '', 56, 'Fixed', '15', 1, 1, NULL, '45', '62227.jpg', 0, 'NULL', 'NULL', '2022-05-06 09:14:11', NULL, NULL),
(2, 9, 1, '3', '', 30, 'Fixed', '10', 1, 1, NULL, '30', '68614.jpg', 0, 'NULL', 'NULL', '2022-05-06 09:14:11', NULL, NULL),
(7, 9, 1, '1', '', 45, 'varies', '10', 1, 1, NULL, '60', '42061.jpg', 0, 'NULL', 'NULL', '2022-05-06 09:17:23', NULL, NULL),
(8, 4, 1, '1', '', 50, 'start at', '10', 1, 1, NULL, '30', '97139.jpeg', 0, 'NULL', 'NULL', '2022-05-20 12:20:41', NULL, NULL),
(9, 4, 1, '2', '', 50, 'start at', '5', 1, 1, NULL, '30', '41412.jpeg', 0, 'NULL', 'NULL', '2022-05-20 12:20:41', NULL, NULL),
(10, 4, 1, '3', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(11, 4, 1, '4', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(12, 4, 1, '5', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(13, 4, 1, '6', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(14, 4, 1, '7', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(15, 4, 1, '8', '', NULL, '', NULL, 1, 0, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(16, 4, 1, '9', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(17, 4, 1, '10', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(18, 4, 1, '11', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL),
(19, 4, 1, '12', '', NULL, '', NULL, 1, 1, NULL, NULL, '', 0, NULL, NULL, '2022-05-20 12:20:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `logo` varchar(255) DEFAULT NULL,
  `favicon` varchar(255) DEFAULT NULL,
  `contact_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `logo`, `favicon`, `contact_no`, `address`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, '99999999', NULL, '2021-04-28 16:49:17', '2022-03-15 13:07:16');

-- --------------------------------------------------------

--
-- Table structure for table `social_accounts`
--

DROP TABLE IF EXISTS `social_accounts`;
CREATE TABLE IF NOT EXISTS `social_accounts` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook_provider_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` text COLLATE utf8mb4_unicode_ci,
  `avatar` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `social_accounts_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `special_offers`
--

DROP TABLE IF EXISTS `special_offers`;
CREATE TABLE IF NOT EXISTS `special_offers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `special_offers`
--

INSERT INTO `special_offers` (`id`, `name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '10%off', '2021-08-20 10:47:11', NULL, NULL),
(2, '20%off', '2021-08-20 10:47:32', NULL, NULL),
(3, '30%off', '2021-08-20 10:47:45', NULL, NULL),
(4, '40%off', '2021-08-20 10:47:58', NULL, NULL),
(5, '50%off', '2021-08-20 10:48:16', NULL, NULL),
(6, '60%off', '2021-08-20 10:48:28', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `staff_members`
--

DROP TABLE IF EXISTS `staff_members`;
CREATE TABLE IF NOT EXISTS `staff_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `seller_id` int(11) DEFAULT NULL,
  `staff_id` int(11) NOT NULL,
  `staff_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_card_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `about` text COLLATE utf8mb4_unicode_ci,
  `experience` int(11) NOT NULL DEFAULT '1',
  `request_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_status` enum('Pending','Accepted') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Pending',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `staff_members`
--

INSERT INTO `staff_members` (`id`, `seller_id`, `staff_id`, `staff_image`, `name`, `position`, `staff_card_id`, `phone`, `bio`, `about`, `experience`, `request_code`, `request_status`, `created_at`, `update_at`, `deleted_at`) VALUES
(1, 1, 1, '123566.png', 'Vilsan', 'senior', 'sadfsdfsdfs', '3695644678', NULL, NULL, 1, NULL, 'Pending', '2022-06-08 18:44:35', NULL, NULL),
(2, 1, 0, '36338.png', 'Ganesh', 'Senior', '548645', '9929516019', 'vsdfdsf', NULL, 0, '2113276', 'Pending', '2022-06-10 14:04:08', NULL, NULL),
(3, 1, 0, '32881.png', 'Ganesh', 'Senior', '548645', '99295160199', 'vsdfdsf', NULL, 0, '1306419', 'Pending', '2022-06-10 14:04:41', NULL, NULL),
(4, 1, 0, '24253.png', 'Ganesh', 'Senior', '548645', '99295160199', 'vsdfdsf', NULL, 0, '7432238', 'Pending', '2022-06-10 14:05:14', NULL, NULL),
(5, 1, 0, '17831.png', 'Ganesh', 'Senior', '548645', '99295516019', 'vsdfdsf', NULL, 2, '1413212', 'Pending', '2022-06-10 14:05:44', NULL, NULL),
(6, 1, 0, '56111.png', 'syam kumawat', 'Senior', 'SL2677', '9929580199', 'vsdfdsf', NULL, 2, '7476312', 'Pending', '2022-06-10 14:40:28', NULL, NULL),
(7, 1, 0, '59416.png', 'syam kumawat', 'Senior', 'SL7468', '9929780199', 'vsdfdsf', NULL, 2, '5174765', 'Pending', '2022-06-10 14:41:30', NULL, NULL),
(8, 1, 0, '99456.png', 'syam kumawat', 'Senior', 'SL3269', '99297250199', 'vsdfdsf', NULL, 2, '4472426', 'Pending', '2022-06-10 14:41:59', NULL, NULL),
(9, 1, 0, '55024.png', 'syam kumawat', 'Senior', 'SL5770', '99297250199', 'vsdfdsf', NULL, 2, '5266505', 'Pending', '2022-06-10 14:42:52', NULL, NULL),
(10, 1, 0, '70959.png', 'syam kumawat', 'Senior', 'SL7673', '99297202199', 'vsdfdsf', NULL, 2, '9488640', 'Pending', '2022-06-10 14:43:06', NULL, NULL),
(11, 1, 0, '48376.png', 'syam kumawat', 'Senior', 'SL5574', '99563698754', 'vsdfdsf', NULL, 2, '424758', 'Pending', '2022-06-10 14:44:35', NULL, NULL),
(12, 1, 0, '40811.png', 'syam kumawat', 'Senior', 'SL7418', '99563698702', 'vsdfdsf', NULL, 2, '2625865', 'Pending', '2022-06-10 14:48:36', NULL, NULL),
(13, 1, 0, '79148.png', 'syam kumawat', 'Senior', 'SL3540', '99563698707', 'vsdfdsf', NULL, 2, '2904098', 'Pending', '2022-06-10 14:49:26', NULL, NULL),
(14, 1, 12, '14674.jpg', 'syam kumawat', 'Senior', 'SL5939', '3695214785', 'vsdfdsf', NULL, 2, '7771649', 'Pending', '2022-06-10 16:14:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_group_id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'gravatar',
  `avatar_location` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_changed_at` timestamp NULL DEFAULT NULL,
  `active` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `otp` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `mobile_no` varchar(55) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip_code` int(10) DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_login_ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_be_logged_out` tinyint(1) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `notification` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) UNSIGNED DEFAULT NULL,
  `updated_by` int(10) UNSIGNED DEFAULT NULL,
  `is_term_accept` tinyint(1) NOT NULL DEFAULT '0' COMMENT ' 0 = not accepted,1 = accepted',
  `discount_message` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mobile_no` (`mobile_no`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `uuid`, `user_group_id`, `username`, `first_name`, `last_name`, `email`, `avatar_type`, `avatar_location`, `password`, `password_changed_at`, `active`, `otp`, `confirmation_code`, `confirmed`, `mobile_no`, `address`, `zip_code`, `profile_image`, `date_of_birth`, `timezone`, `last_login_at`, `last_login_ip`, `to_be_logged_out`, `status`, `notification`, `created_by`, `updated_by`, `is_term_accept`, `discount_message`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, '04daa696-a06f-4367-93f1-1ebf7516b89f', 3, 'super admin', 'super', 'admin', 'vksinghjaipur@gmail.com', 'gravatar', '70132.jpg', '$2y$10$vvtL7GDmsmzTp8Ml..TtV.oF64BlxPbkXgCOYEJPfu6hPOSfBNG7O', NULL, 1, NULL, '0e31364ae38ff072b14aafc3e01244a0', 1, NULL, NULL, NULL, NULL, NULL, 'America/New_York', '2023-04-14 00:38:34', '127.0.0.1', 0, 1, 1, 1, NULL, 0, 0, 'S4EHwmYY7VV4MrijUNX7HcqCjaRm4XV4GcgL1voj8VOIMJUiSsc8OCocJyj0', '2022-02-22 06:32:18', '2023-04-14 00:38:34', NULL),
(2, '533da588-3465-46eb-884e-143dab05d87b', 3, 'narendra', 'Narendra', 'Singh', '', 'gravatar', NULL, '$2y$10$lol0XginMJpUbQm7SwCmy.CoiIHT8Gq20jXgxtTxRpL1C9oXU0H1K', NULL, 1, NULL, '484424c0441533ef3dbfc9fa7c1893c0', 1, '9928394640', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-03-16 13:53:09', '2022-03-16 13:53:09', NULL),
(3, '874dfe27-fecc-46d2-a8cb-9a01960ae4e6', 0, NULL, 'Grace', 'Jang', 'grace@svgo.ai', 'gravatar', NULL, '$2y$10$lJxXuOrFe/pg6y0tEqTj6eIyQ6/7WBdqW7Es/ECEzpiJJgdWVjrqC', NULL, 1, NULL, 'f6f08a2dc652cce284fce32bf5e7bff4', 1, NULL, NULL, NULL, NULL, NULL, 'America/Los_Angeles', '2022-04-20 18:59:15', '172.118.155.20', 0, 1, 1, NULL, NULL, 0, 0, 'u5yBVMmLWonPvOfWx7ubLzw0t3glgJy9uCdiiZz0I6i4v6fp1WQ0s1ytybvq', '2022-04-20 17:24:31', '2022-04-20 18:59:15', NULL),
(4, '56999975-6541-4053-bd96-8d2c19fb526d', 2, 'Oh CUT Business', 'Wdp', 'Technology', 'androidteam@mailinator.com', 'gravatar', '65272.jpeg', '$2y$10$tSWIXHZiBGfPRUcd98pft.zVlweqM1ibt0F0wkwNdnD7nrxMhrb1C', NULL, 1, NULL, '0f43b8c8cd5c731379e42bb452adee09', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, NULL, 0, 0, NULL, '2022-04-21 05:38:13', '2022-04-21 07:14:19', NULL),
(5, '822a7a07-721b-4fcf-b9dc-6d0ded7a2420', 2, NULL, 'Android', 'Team', 'androidteamwdp@mailinator.com', 'gravatar', NULL, '$2y$10$Le3PnL2uwR2oerMtIuMQBOyjN/G0/.C0bAA3kN3eZsHzH60coKYxy', NULL, 1, NULL, 'cb8af30966627159f86755ed071a7a12', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, NULL, 0, 0, NULL, '2022-04-21 07:11:54', '2022-04-21 07:11:54', NULL),
(7, '89684ccc-a82b-42b1-83f5-6a9b40e033ea', 3, 'Abhishek Tripathi', 'Abhishek', 'Tripathi', 'abhi@mailinator.com', 'gravatar', NULL, '$2y$10$ao6g1wsJg5xKobRdZylmTOclkqsoWz3nOLQcAfu4bb4Db6.6rRNV6', NULL, 1, NULL, 'cbbffcdbbacc26092141639885fa680f', 1, '8602624288', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-04-22 16:19:00', '2022-04-22 16:19:00', NULL),
(6, '41ca8a88-b490-4553-ba71-e70e4afd5574', 3, NULL, 'test', 'test', 'test@gmail.com', 'gravatar', NULL, '$2y$10$VrOKRIEY4dgfHjvsiYdDyeV34lapI37wsDJ64IPgtIh6KXvigIwoe', NULL, 1, NULL, '9636693a8824eeaf0ff027f78be55854', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, 1, NULL, 0, 0, NULL, '2022-04-21 11:54:47', '2022-08-14 20:43:25', '2022-08-14 20:43:25'),
(8, 'ea28d774-25dc-47fd-9c5b-1a6e7bd2c5a5', 3, 'Rohit Gujar', 'Rohit', 'Gujar', 'rohit@mailinator.com', 'gravatar', NULL, '$2y$10$IAJXukkSFRN7ghtloJzYheZusUoaX1Jra.t.5/116WVOu/vKkBXY2', NULL, 1, NULL, 'd7e5a9db050469f190fbc359ac5e47d2', 1, '6666666666', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-05-04 10:48:21', '2022-05-04 10:48:21', NULL),
(9, '9d34729d-b2a3-42d8-a263-e84c19c70fae', 2, 'jaipur salon', 'Jaipur', 'salon', '', 'gravatar', NULL, '$2y$10$MGVmXPe3A9Ldp1sy3Hzg4ONt7umOja2i8cvSXbtqBXMMwjgx73Syi', NULL, 1, NULL, 'dee60f78a040199fb813d4b6ab5250ed', 1, '1231231233', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-05-06 11:36:05', '2022-05-06 11:36:05', NULL),
(10, 'b3e424f0-243e-41e4-8053-5bb54b1db7ac', 3, 'Oh-Cut', 'Oh', 'Cut', 'ohcut@mailinator.com', 'gravatar', NULL, '$2y$10$Kf7OLfUKfXpXhasCTlmro.cVUHEkvinBZaiASfbuMGKhWoLdA7i9e', NULL, 1, NULL, '771054e9a1d09db1285e8da9c643ad13', 1, '9876543210', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-05-16 10:01:12', '2022-05-16 04:32:34', NULL),
(12, '960f42fa-d22b-468a-ab27-7fabba104075', 3, 'rohit', 'Rohit', 'parmar', 'rohit@gmail.com', 'gravatar', NULL, '$2y$10$53Eite7CfalkzuQGSFMG/ecoTg2VowJ48omBYYdVlgwSWGl3nFuWa', NULL, 1, NULL, 'edf80ae0224b867eb56f6d7a5d3f9aeb', 0, '5555566666', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-07-21 05:08:29', '2022-07-21 05:08:29', NULL),
(13, '66e9b06c-d9e3-4fdb-9782-2b49a09e2492', 2, 'garima', 'Garima', 'Singh', 'garima@gmail.com', 'gravatar', NULL, '$2y$10$PHJtb0.C8oz2TATNAjA/NOfdRm4DNwCwp3bBIjaarHC0ROPD3Q1s6', NULL, 1, NULL, '37acf6de5105e2223e9db5827102387b', 0, '5555566677', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 1, 1, NULL, NULL, 1, 0, NULL, '2022-07-27 09:23:06', '2022-07-27 09:23:06', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_billing_address`
--

DROP TABLE IF EXISTS `user_billing_address`;
CREATE TABLE IF NOT EXISTS `user_billing_address` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_title` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_billing_address`
--

INSERT INTO `user_billing_address` (`id`, `user_id`, `address_title`, `first_name`, `last_name`, `email`, `phone_no`, `address`, `country`, `state`, `city`, `zip_code`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 633773, 'Software company', 'Wdp', 'Technology', 'wdp@mailinator.com', '9635658696', 'Jaipur', 'India', 'Rajasthan', 'Jaipur', '302020', '2022-05-30 14:56:32', '2022-05-30 14:56:32', NULL),
(2, 8, 'Jaipur', 'Rohit', 'Gujar', 'test', '1234567890', 'Jaipur', 'India', 'Rajasthan', 'Jaipur', '302020', '2022-06-02 11:24:33', '2022-06-02 11:24:33', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_devices`
--

DROP TABLE IF EXISTS `user_devices`;
CREATE TABLE IF NOT EXISTS `user_devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `device_type` varchar(255) DEFAULT NULL,
  `device_id` text,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_devices`
--

INSERT INTO `user_devices` (`id`, `user_id`, `device_type`, `device_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 'android', 'c_s5AyN7TsaFBwHzZf26Mg:APA91bF_leeMUfzlTuf0QiWTdO_-54xo28VAmIQliv5L4gzik7H-w_fVD5NdvX0ekpJ4lxzNNmVhdN4hQY7YXH7i_DPAWOPWXrpfJqRPmqk7_SbEtOFV_i9QHWqPludWGqRqSXSvpcH9', '2022-03-16 08:23:09', NULL, NULL),
(2, 7, 'android', 'eCNfZOALQO6yzfkR5hkf0u:APA91bGvBXbgquLriOLI1hOC2zZnBr3pwEENipbz9WXJoIjgBRlirbLd2EpdDhBpfj2JWz-oPGIxsDvh9NjVlB6NFstJ2yccFWCWjm_KqhyFkoAHzgUAq6IMW3LIHotqFrFuFDpusWBy', '2022-04-22 10:49:00', NULL, NULL),
(3, 8, 'android', 'cQHQbUp7QBCTe0u4F6Zhvw:APA91bGk6Neq4tB4tUZgFBMKGDOqigOLCCqkdLDjeEJHG-9O8ToEfvjbKvWJ0Th3z3cX-0zwVXoavRVo6F1ilZDjf7diOx2Y6-poTx_PcngZHH7YF4GGixuWJ_HI-4lvktrM5X-XggFL', '2022-05-04 05:18:21', '2022-05-26 08:16:21', NULL),
(4, 9, 'Android', 'dErczwyzR4SSag_ApJ5R5Y:APA91bEZzV5MWHIRdrPkFXTVYsST2vY_bWLLnS3_JBWc8I9kuviJbMqBcTjwuN218kVWWlO03NdbGU9sJMHRmyI-669Ph05DRruzlkx9bW9PQFuqxI0TUXRDtDsboaKCjSv1QUNHoYK7', '2022-05-06 06:06:05', NULL, NULL),
(5, 10, 'ios', 'dtIr8EAhDkkeqASihKFqF8:APA91bHb72BXZg5VW-dHgrCa2ch0JbZZPiJUo0hLOGp1TBnVi9ARTc4o47kW6mMvqdQQ2KMHDyi6tcsQQiIhExd__2LlYBgTvyaGJHAo6IH69KrW7OT6aBO5I837olpAymZ8tnMzLR_R', '2022-05-16 04:31:12', '2022-05-16 04:33:21', NULL),
(6, 4, 'ios', 'f5Wxl1ygsEPmrVnhZC-9US:APA91bEkCo1gGa_awV9pT7b5CNzjlxWg3e8yQ-qx1-7eMR-pccxBDaUDQkLd8BMmFKzguATYoxhk0J6HG0WevZlvI-KE-3Vole2HP9e6nfvCeCYNganNxhcbJ79VTbWhWsx6WHGqx9Sb', '2022-05-20 11:25:07', '2022-05-26 12:37:12', NULL),
(7, 11, '', '', '2022-07-21 10:35:23', NULL, NULL),
(8, 12, 'android', '1', '2022-07-21 10:38:29', '2022-07-22 13:36:07', NULL),
(9, 13, '', '', '2022-07-27 14:53:07', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_settings`
--

DROP TABLE IF EXISTS `user_settings`;
CREATE TABLE IF NOT EXISTS `user_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `notification` enum('1','0') NOT NULL DEFAULT '1',
  `message` enum('1','0') NOT NULL DEFAULT '0',
  `language` enum('en','ar') DEFAULT 'en',
  `currency` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
