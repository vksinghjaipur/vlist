<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application by vikash singh. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });


Route::group(['namespace' => 'Api'], function () {
        /*Account Controller Start*/
        
        Route::post('logout', 'AccountController@logout');
        Route::post('guestUser', 'AccountController@guestUser');
        Route::post('register', 'AccountController@register');
        Route::post('login', 'AccountController@login');
        Route::post('updatePhoneNumber', 'AccountController@updatePhoneNumber');
        Route::post('updatePassword', 'AccountController@updatePassword');
        Route::post('userSetting', 'AccountController@userSetting');
        Route::post('userSettingList', 'AccountController@userSettingList');
        Route::post('updateProfileImage', 'AccountController@updateProfileImage');
        Route::post('updateProfile', 'AccountController@updateProfile');
        Route::post('getProfile', 'AccountController@getProfile');
        
        Route::post('deleteAccount', 'AccountController@deleteAccount');

        //Route::post('forgetPassword','AccountController@forgetPassword');
        Route::post('forgetPasswordUpdate','AccountController@forgetPasswordUpdate');
        Route::post('resendOtp','AccountController@resendOtp');
        Route::post('verifyOtp','AccountController@verifyOtp');

        Route::post('requestVerifyCode', 'AccountController@requestVerifyCode');
       

        //get services
        Route::get('getServices','AccountController@getServices');

        //get Nursing Professionals
        Route::post('getNursingList','AccountController@getNursingList');

        //get Nursing Details
        Route::post('getNursingDetails', 'AccountController@getNursingDetails');
        
        //Get All Nursing Booking Slots        
        Route::post('getAllBookingSlots', 'AccountController@getAllBookingSlots');
        Route::post('getAllNursingSlots', 'AccountController@getAllNursingSlots');
        Route::post('updateNursingSlot', 'AccountController@updateNursingSlot');
        Route::post('fullDaySlotsBlock', 'AccountController@fullDaySlotsBlock');
       

        //Notification
        Route::post('notificationList','UserController@notificationList');
        Route::post('notificationDelete','UserController@notificationDelete');
        Route::post('notificationRead','UserController@notificationRead');
        Route::post('notificationSetting','AppController@notificationSetting');

        //Favorite
        Route::post('favorite','UserController@favorite');
        Route::post('favoriteList','UserController@favoriteList');

        //All Pages
        Route::post('pages', 'AppController@pages');

        
        //V Social Login
        Route::post('emailUpdate', 'AccountController@emailUpdate');
        Route::post('socialLogin', 'AccountController@socialLogin');
        Route::post('isCheckedSocial', 'AccountController@isCheckedSocial');

        //home search
        Route::post('nusingList', 'AppController@nursingList');
        Route::post('home', 'UserController@home');
        //Route::post('searchCities', 'AppController@searchCities');
        //get Plan
        //Route::get('getPlans','AppController@getPlans');

        //Appointment Booking 
        Route::post('appointmentBooking', 'UserController@appointmentBooking');
        Route::post('careSeekerBookings', 'UserController@careSeekerBookings');
        Route::post('careSeekerBookingCancel', 'UserController@careSeekerBookingCancel');

        //Nursing Staff Appointment
        Route::post('nursingStaffBookings', 'UserController@nursingStaffBookings');
        //Route::post('nursingBookingCancel', 'UserController@nursingBookingCancel');
        Route::post('nursingBookingAction', 'UserController@nursingBookingAction');
        /* Showing feedback count, average, total income, total bookings, today bookings */
        Route::post('feedbackAvg', 'UserController@feedbackAvg');
        /* give feedback to nursing by careseeker */
        Route::post('giveFeedback', 'UserController@giveFeedback');

        /* Showing transaction history */
        Route::post('showTransaction', 'UserController@showTransaction');

        //remove  description
        Route::get('updatesql','UserController@updatesql');
        Route::group(['middleware' => ['auth:api']], function () {
        Route::group(['prefix' => 'auth'], function () {
        Route::post('logout', 'AuthController@logout');
        Route::get('me', 'AuthController@me');

     });
   });
});
