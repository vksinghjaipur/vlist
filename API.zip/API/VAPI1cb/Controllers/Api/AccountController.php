<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Role;
use App\Models\City;
use App\Models\User;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Models\Service;
use App\Models\Userprofile;
use App\Models\AvailabilitySlot;
use App\Models\AvailabilityTimes;
use App\Models\WeekData;
use App\Models\DayData;
use App\Models\Auth\SocialAccount;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsResendOtp;
use App\Notifications\Auth\UserNeedsConfirmation;
use App\Events\Frontend\UserConfirmed;

date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');

class AccountController extends APIController
{
       
    /* User Login */
    public function login(Request $request)
    {
    //$access_token=123456;
    $validation = Validator::make($request->all(), [
        'email' =>'required',
        'password' => 'required|min:6',
        'device_id'=>'required',
        'device_type'=>'required',
         //'user_group_id'=>'required',
    ]);

    if ($validation->fails()) {
        $resultArray['status']=0;
        $resultArray['message']=trans('api.Invalid parameters.');
        return response()->json($resultArray); exit;
    }

               
    $email= $request->email;
    if (filter_var($email, FILTER_VALIDATE_EMAIL))
    {
        $credentials = ['email'=>$request->get('email'),'password'=>$request->get('password'),'password'=>$request->get('password')];
    }
    else
    {   
        $credentials = ['mobile'=>$request->get('email'),'password'=>$request->get('password')];
    }

        if (! Auth::attempt($credentials)) {
            $resultArray['status']=0;
            $resultArray['message']=trans('api.messages.login.failed');
            return response()->json($resultArray); exit;
        }
        

        $user = $request->user();

        $lat=isset($request->lat)?$request->lat:'';
        $lng=isset($request->lng)?$request->lng:'';
        $deviceType=isset($request->device_type)?$request->device_type:'';
        $deviceId=isset($request->device_id)?$request->device_id:'';

        // DB::table('users')->where('id',$user->id)->first();
        DB::table('users')->where('id',$user->id)->update(['device_type'=>$deviceType,'device_id'=>$deviceId,'lat'=>$lat,'lng'=>$lng]); 
       

        if(!$user->confirmed==1){
            $resultArray['status']=0;
            $resultArray['message']=trans('api.messages.not_confirmed');
            return response()->json($resultArray); exit;
        }
        
        $result['id']=!empty($user->id) ? $user->id:'';
        $result['name']=!empty($user->name) ? $user->name:'';
        $result['user_type']=!empty($user->user_type) ? $user->user_type:'';
        $result['first_name']=!empty($user->first_name) ? $user->first_name:'';
        $result['last_name']=!empty($user->last_name) ? $user->last_name:'';
        $result['username']=!empty($user->username)? $user->username:'';
        $result['email']=!empty($user->email)? $user->email:'';
        $result['mobile']=!empty($user->mobile)? $user->mobile:'';
        $result['date_of_birth']=!empty($user->date_of_birth)? $user->date_of_birth:'';
        $result['service_id']=!empty($user->service_id)? $user->service_id:'';
        $result['device_id']=!empty($request->device_id)? $request->device_id:'';
        $result['device_type']=!empty($request->device_type)? $request->device_type:'';
        $result['lat']=!empty($request->lat)? $request->lat:'';
        $result['lng']=!empty($request->lng)? $request->lng:'';

        
        if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
        {
            $result['avatar']=url('img/avatars/'.$user->avatar);
        }
        else
        {
            $result['avatar']=url('img/avatars/default-user-profile.png');
        }
       
        $getprofile=Userprofile::where('user_id',$user->id)->first();
        $result['practicing']=!empty($getprofile->practicing)? $getprofile->practicing:'';
        $result['experience']=!empty($getprofile->experience)? $getprofile->experience:'';
        $result['license_number']=!empty($getprofile->license_number)? $getprofile->license_number:'';
        $result['bank_details']=!empty($getprofile->bank_details)? $getprofile->bank_details:'';
        $result['ifsc_code']=!empty($getprofile->ifsc_code)? $getprofile->ifsc_code:'';
        $result['country']=!empty($getprofile->country)? $getprofile->country:'';
        $result['state']=!empty($getprofile->state)? $getprofile->state:'';
        $result['city']=!empty($getprofile->city)? $getprofile->city:'';
        $result['pin_code']=!empty($getprofile->pin_code)? $getprofile->pin_code:'';
        
        $resultArray['status']=1;
        $resultArray['message']=trans('api.messages.login.success');
        $resultArray['data']=$result;
        return response()->json($resultArray); exit;
    } 

    /* User Register */
    public function register(Request $request)
    {
    $validation = Validator::make($request->all(), [
        'user_type'=>'required',
        'name'=>'required',
        //'mobile'=>'required|numeric',
        'email' => 'required',
        'password' => 'required|min:6',
        'confirm_password'=>'required_with:password|same:password|min:6',
       //'term_condition'=>'required|numeric',
    ]);

    if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=trans('Invalid parameters.');
             return response()->json($resultArray); exit;
    }

    if(filter_var($request->email, FILTER_VALIDATE_EMAIL))
    {
        $email = $request->email;
    }
    else
    {
        $phone = $request->email;
    }

    //$user_type = isset($request->user_type) && !empty($request->user_type) ? $request->user_type: '3';
    $user_type = isset($request->user_type) && !empty($request->user_type) ? $request->user_type: '';
    $name = isset($request->name) && !empty($request->name) ? $request->name: '';
    $first_name = isset($request->first_name) && !empty($request->first_name) ? $request->first_name: '';
    $last_name = isset($request->last_name) && !empty($request->last_name) ? $request->last_name: '';

    $email = isset($email) && !empty($email) ? $email: '';
    $device_type = isset($request->device_type) && !empty($request->device_type) ? $request->device_type: '';
    $device_id = isset($request->device_id) && !empty($request->device_id) ? $request->device_id: '';
    $password = isset($request->password) && !empty($request->password) ? $request->password: '';
    $myname = isset($request->myname) && !empty($request->myname) ? $request->myname: '';
    //$service_id = isset($request->service_id) && !empty($request->service_id) ? $request->service_id: '';
        
    $lat = isset($request->lat) && !empty($request->lat) ? $request->lat: '';
    $lng = isset($request->lng) && !empty($request->lng) ? $request->lng: '';

    $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
    App::setLocale($lang);

    if(!empty($email))
    { 
        $emailexist = DB::table('users')->whereRaw("(email = '".$email."' AND deleted_at IS null )")->first();

        if(!empty($emailexist))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.messages.email_taken');
            return response()->json($resultArray); exit;
        }
    }

    if(isset($phone) && !empty($phone))
    {
        $mobilecheck = DB::table('users')->whereRaw("(mobile = '".$phone."' AND deleted_at IS null )")->first();
        if(!empty($mobilecheck))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.messages.phone_taken');
            return response()->json($resultArray); exit;
        }
    }

        if ($request->hasFile('avatar'))
        {
        $image = $request->file('avatar');
        $myname = rand(11111,99999).'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/img/avatars/');
        $image->move($destinationPath, $myname);
        }

        
        $registerArr['uuid'] = Uuid::uuid4()->toString();
        $registerArr['user_type']=$user_type;
        $registerArr['name']=$name;
        $registerArr['first_name']=$first_name;
        $registerArr['last_name']=$last_name;
        $registerArr['mobile'] = isset($phone)?$phone:'';
        $registerArr['email'] = $email;
        $registerArr['device_type'] = $device_type;
        $registerArr['device_id'] = $device_id;
        $registerArr['avatar']= $myname;
        //$registerArr['to_be_logged_out'] = $location;
        //$registerArr['active'] = 1;
        $registerArr['verify_otp'] = rand(1111,9999);
        $registerArr['confirmed'] = 0;

        $registerArr['password'] =bcrypt($password);
        $registerArr['confirmation_code'] = md5(uniqid(mt_rand(), true));
        $registerArr['created_at'] = Carbon::now()->toDateTimeString();
        $registerArr['remember_token'] = Hash::make('secret');

        $registerArr['lat'] = $lat;
        $registerArr['lng'] = $lng;
        
        if($user = User::create($registerArr)) 
        {
            $roles=$request->user_type;
            $user->syncRoles($roles);

            $name=isset($request->name)?$request->name:'';
            $first_name=isset($request->first_name)?$request->first_name:'';
            $last_name=isset($request->last_name)?$request->last_name:'';
            $username=isset($request->username)?$request->username:'';
            $practiceType=isset($request->practicing)?$request->practicing:'';
            $workExperience=isset($request->experience)?$request->experience:'';
            $licenceNumber=isset($request->license_number)?$request->license_number:'';
            $bankAccount=isset($request->bank_details)?$request->bank_details:'';
            $ifscCode=isset($request->ifsc_code)?$request->ifsc_code:'';
            $country=isset($request->country)?$request->country:'';
            $state=isset($request->state)?$request->state:'';
            $city=isset($request->city)?$request->city:'';
            $pin_code=isset($request->pin_code)?$request->pin_code:'';
            
            DB::table('userprofiles')
            ->insert([
                'user_id'=>$user->id, 
                'name'=>$user->name,
                'first_name'=>$user->first_name,
                'last_name'=>$user->last_name,
                'username'=>$user->username,
                'email'=>$user->email,
                'mobile'=>$user->mobile,
                'date_of_birth'=>$user->date_of_birth,
                'avatar'=>$user->avatar,
                'practicing'=>$practiceType,
                'experience'=>$workExperience,
                'license_number'=>$licenceNumber,
                'bank_details'=>$bankAccount,
                'ifsc_code'=>$ifscCode,
                'country'=>$country,
                'state'=>$state,
                'city'=>$city,
                'pin_code'=>$pin_code,
            ]);
        }
                        
        $user->notify(new UserNeedsConfirmation($user->confirmation_code));
        if (config('access.users.confirm_email'))
        {
        }
        

        $resultArray['status']=1;
        $resultArray['message']=trans('api.messages.created_confirm');
        $resultArray['data']=$user;
        return response()->json($resultArray); exit;
    }


    //Social Login api start
    public function socialLogin(Request $request)
    {   
    $validation = Validator::make($request->all(), [
        'provider' => 'required',
        'provider_id'=>'required',
        'device_id' => 'required',
        'device_type' => 'required',
        'username' => 'required',
        'user_type' => 'required',
        'email' => 'required',
        ]);

    if($validation->fails())
    {
        $resultArray['status']='0';
        $resultArray['message']=trans('Invalid parameters.');
        echo json_encode($resultArray); exit;      
    }
        //$access_token=123456;
        $email = isset($request->email) && !empty($request->email) ? $request->email: '';
        $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';

        $userdatacheck=DB::table('users')->where('email',$request->email)->first();

        if(empty($userdatacheck))
        {
            $fileName='default-user-profile.png';
            if(!empty($request->image))
            {
                $content = file_get_contents($request->image);
                $rand=rand(11111,99999);
                if($request->user_type==2)
                {
                    file_put_contents('img/avatars/'.$rand.'.jpg', $content);
                }
                if($request->user_type==3)
                {
                    file_put_contents('img/avatars/'.$rand.'.jpg', $content);
                }
                    $fileName=$rand.'.jpg';
            }
                $user= new User;
                $user->user_type=$request->user_type;
                $user->username=$request->username;
                $user->first_name=$request->first_name;
                $user->last_name=$request->last_name;
                $user->email=isset($request->email)?$request->email:'';
                $user->mobile=$request->mobile;
                $user->confirmed=1;
                //$user->active=1;
                $user->avatar= $fileName;
                $user->confirmation_code=md5(uniqid(mt_rand(), true));
                $user->password=bcrypt($request->password);
                $user->save();
       
                $social= new SocialAccount; 
                $social->user_id=$user->id;
                $social->provider=$request->provider;
                    if($request->provider=='facebook')
                    {
                        $social->facebook_provider_id=$request->provider_id;

                    }
                    else
                    {
                        $social->provider_id=$request->provider_id;
                    }
                $social->save();

                $userpro= new Userprofile; 
                $userpro->user_id=$user->id;
                $userpro->username=$request->username;
                $userpro->email=isset($request->email)?$request->email:'';
                $userpro->save();

            if(!empty($user))
             {
                DB::table('users')->where('id',$user->id)->update(['device_type'=>$request->device_type,'device_id'=>$request->device_id]);
             }
             else{

            // DB::table('users')->insert(['device_type'=>$request->device_type,'device_id'=>$request->device_id]); 
            } 
         }
        else
        {
            $user= DB::table('users')->where('id',$userdatacheck->id)->first();
            if(isset($request->image) && !empty($request->image))
            {
                    $content = file_get_contents($request->image);
                    $rand=rand(11111,99999);
                    if($request->user_type==2)
                    {
                         file_put_contents('img/avatars/'.$rand.'.jpg', $content);
                         if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
                        {
                            unlink(public_path('img/avatars/'.$user->avatar));
                        }
                    }
                    if($request->user_type==3)
                    {
                         file_put_contents('img/avatars/'.$rand.'.jpg', $content);
                        if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
                        {
                            unlink(public_path('img/avatars/'.$user->avatar));
                        }
                    }
                    $fileName=$rand.'.jpg';    
            }else
            {
                $fileName=isset($user->avatar)?$user->avatar:'default-user-profile.png';
            }
            $chackmail= isset($request->email)?$request->email:$user->email;

            $userupdate=array('user_type'=>$request->user_type,
                                'username'=>$request->username,
                                'email'=>$chackmail,
                                'first_name'=>$request->first_name,
                                'last_name'=>$request->last_name,
                                'avatar'=>$fileName,
                                'mobile'=>$request->mobile,
                                'lat'=>$request->lat,
                                'lng'=>$request->lng
                                    );
            DB::table('users')->where('id',$userdatacheck->id)->update($userupdate);
           
            
            $updatesocial=SocialAccount::where('user_id',$userdatacheck->id)->first();
            if(empty($updatesocial))
            {
                $social= new SocialAccount; 
                $social->id=$user->id;
                $social->provider=$request->provider;
                if($request->provider=='facebook')
                {
                    $social->facebook_provider_id=$request->provider_id; 
                }
                else
                {
                    $social->provider_id=$request->provider_id;
                }
                $social->save();
            }
            else
            {
                $updatesocial->provider=$request->provider;
                
                if($request->provider=='facebook')
                {
                   $updatesocial->facebook_provider_id=$request->provider_id ;
                }
                else
                {
                    $updatesocial->provider_id=$request->provider_id; 
                }
                 $updatesocial->save();
            }
            

            //DB::table('social_accounts')->where('user_id',$userdatacheck->id)->update($social); 

            DB::table('users')->where('id',$userdatacheck->id)->update(['device_type'=>$request->device_type,'device_id'=>$request->device_id]);
        }
            // echo '<pre>'; print_r($user);exit;
            $devicetoken=DB::table('users')->where('id',$user->id)->first();
            $user= DB::table('users')->where('id',$user->id)->first();
            $user->id= isset($user->id)?$user->id:'';
            $user->user_type= isset($user->user_type)?$user->user_type:'';
            $user->first_name= !empty($user->first_name) ? $user->first_name:'';
            $user->last_name=!empty($user->last_name) ? $user->last_name:'';
            $user->username=!empty($user->username)? $user->username:'';
            $user->email=!empty($user->email)? $user->email:'';
            $user->mobile=!empty($user->mobile)? $user->mobile:'';
            $user->device_id= isset($devicetoken->device_id)?$devicetoken->device_id:'';
            $user->device_type= isset($devicetoken->device_type)?$devicetoken->device_type:'';
            $user->lat= isset($devicetoken->lat)?$devicetoken->lat:'';
            $user->lat= isset($devicetoken->lat)?$devicetoken->lat:'';
            //$user->notification=$user->notification;'';

                if(!empty($user->avatar) && ($user->user_type==3))
                {
                    if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
                    {
                        $user->avatar=url('img/avatars/'.$user->avatar);
                    }
                }
                if(!empty($user->avatar) && ($user->user_type==2))
                {
                    if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
                    {
                       $user->avatar=url('img/avatars/'.$user->avatar);
                    }
                }

                
            //$resultdata= $this->intToString($user);
            $resultArray['status']=1;
            $resultArray['message']=trans('api.messages.login.success');
            $resultArray['data']=$user;
            return response()->json($resultArray); exit;
    }

    //New V isCheckedSocial
    public function isCheckedSocial(Request $request)
    {
    $validation = Validator::make($request->all(), [
        'provider'=>'required',
        'provider_id'=>'required',
    ]);

    if($validation->fails())
    {
        $resultArray['status']='0';
        $resultArray['message']=trans('api.Invalid parameters.');
        echo json_encode($resultArray); exit;      
    }  

    $lang = !empty($request->lang) ? $request->lang : 'en' ;
    App::setLocale($lang);
    $access_token=123456;

    if($request->provider=='google' || $request->provider=='Google')
    {
        $userData=DB::table('social_accounts')->where('provider_id',$request->provider_id)->first();
    }
    else
    {
         $userData=DB::table('social_accounts')->where('facebook_provider_id',$request->provider_id)->first();
    }
        
        if(!empty($userData))
        {
            
            $updatesocial=SocialAccount::where('user_id',$userData->user_id)->first();
           
                $updatesocial->provider=$request->provider;
                
                if($request->provider=='facebook')
                {
                   $updatesocial->facebook_provider_id=$request->provider_id ;
                }
                else
                {
                    $updatesocial->provider_id=$request->provider_id; 
                }
                 $updatesocial->save();
            

           
                $user= DB::table('users')->where('id',$userData->user_id)->first();
                $devicetoken=DB::table('users')->where('user_id',$user->id)->first();
                $user= DB::table('users')->where('id',$user->id)->first();
                $user->id= isset($user->id)?$user->id:'';
                $user->user_group_id= isset($user->user_group_id)?$user->user_group_id:'';
                $user->first_name= !empty($user->first_name) ? $user->first_name:'';
                $user->last_name=!empty($user->last_name) ? $user->last_name:'';
                $user->username=!empty($user->username)? $user->username:'';
                $user->email=!empty($user->email)? $user->email:'';
                $user->mobile=!empty($user->mobile)? $user->mobile:'';
                $user->device_id= isset($devicetoken->device_id)?$devicetoken->device_id:'';
                $user->device_type= isset($devicetoken->device_type)?$devicetoken->device_type:'';
                $user->notification=$user->notification;'';

                $user->avatar='';
                if(!empty($user->avatar_location) && ($user->user_group_id==3))
                {
                    if(!empty($user->avatar_location) && file_exists(public_path('img/user/profile/'.$user->avatar_location)))
                    {
                        $user->avatar=url('img/user/profile/'.$user->avatar_location);
                    }
                }
                if(!empty($user->avatar_location) && ($user->user_group_id==2))
                {
                    if(!empty($user->avatar_location) && file_exists(public_path('img/business/profile/'.$user->avatar_location)))
                    {
                       $user->avatar=url('img/business/profile/'.$user->avatar_location);
                    }
                }

                if($user->user_group_id == 2)
                {

                    $businsinfo=DB::table('business_infos')->where('user_id',$user->id)->first();
                    if(!empty($businsinfo))
                    {
                        if(!empty($businsinfo->certificate)){
                         $certificates =  explode("|",$businsinfo->certificate);
                        }

                        $business_certi=array();
                        foreach ($certificates as $key => $certificate)
                        {
                            if(!empty($certificate) && file_exists(public_path('img/certificate/'.$certificate)))
                            {
                             $business_certi1['certificate']=$certificate=url('img/certificate/'.$certificate);
                             array_push($business_certi, $business_certi1);
                             }
                          
                        }
                       
                        $user->business_info =array('business_name'=>!empty($businsinfo->business_name)? $businsinfo->business_name: '','official_id'=>!empty($businsinfo->official_id) ? $businsinfo->official_id :'','certificate'=>!empty($business_certi)? $business_certi:'','facebook_url'=>$businsinfo->facebook_url?$businsinfo->facebook_url:'','instagram_url'=>$businsinfo->instagram_url?$businsinfo->instagram_url:'','google_url'=>$businsinfo->google_url?$businsinfo->google_url:''
                        );
                    }

                     $businsaddress=DB::table('business_address')->where('user_id',$user->id)->first();
                    if(!empty($businsaddress))
                    {
                       $user->business_address=array('business_address'=>!empty($businsaddress->business_address)? $businsaddress->business_address :'','apart_number'=>!empty($businsaddress->apart_number)? $businsaddress->apart_number :'','city'=>!empty($businsaddress->city)? $businsaddress->city :'','zip_code'=>!empty($businsaddress->zip_code)? $businsaddress->zip_code :'','business_lat'=>!empty($businsaddress->business_lat)? $businsaddress->business_lat :'','business_long'=>!empty($businsaddress->business_long)? $businsaddress->business_long :'' 
                        );
                    }
                   
                }

            $resultdata= $this->intToString($user);
            $resultArray['status']=1;
            $resultArray['message']=trans('api.messages.login.success');
            $resultArray['session_key']=$check_auth['Data']['randnumber'];
            $resultArray['data']=$resultdata;
            return response()->json($resultArray); exit;
        }
        else
        {
                $resultArray['status']=2;
                $resultArray['message']='User not register.';
                return response()->json($resultArray); exit;
        }
    }

    /* get services api */
    public function getServices()
    {
    $getServices=Service::where('status',1)->get();
    $serviceInfo=array();
    foreach($getServices as $p=>$services)
    {
        $serviceInfo[$p]['id']=$services->id;
        $serviceInfo[$p]['name']=$services->service_name;
        $serviceInfo[$p]['price']=$services->price;
    }
        $resultArray['status']=1;
        $resultArray['message']=trans('Service list get successfully');
        $resultArray['services']= $serviceInfo;
        echo json_encode($resultArray); exit;  
    }

    public function updateProfile(Request $request)
    { 
    $validation = Validator::make($request->all(), [
        'user_id'=>'required',
        //'id'=>'required',
    ]);

    if($validation->fails()) {
        $resultArray['status']='0';
        $resultArray['message']=$validation->errors()->all();
        return response()->json($resultArray); exit;
    }
    $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
    $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
    App::setLocale($lang);

    $usercheck=DB::table('users')->where('id',$userId)->first();
    if ($request->hasFile('avatar'))
    {
        if(!empty($usercheck->avatar) && file_exists(public_path('img/avatars/'.$usercheck->avatar)))
        {   
            unlink(public_path('img/avatars/'.$usercheck->avatar));
        }
        $image = $request->file('avatar');
        $myname = rand(11111,99999).'.'.$image->getClientOriginalExtension();
        $destinationPath = public_path('/img/avatars/');
        $image->move($destinationPath, $myname);
        $profileupdate['avatar']= $myname;
    }

    //1st Table Users Data Update Profile
    $profileupdate['name']=isset($request->name)?$request->name:'';
    // $profileupdate['email']=isset($request->email)?$request->email:'';
    $profileupdate['mobile']=isset($request->mobile)?$request->mobile:'';
    $profileupdate['date_of_birth']=isset($request->date_of_birth)?$request->date_of_birth:'';       
    $profileupdate['gender']=isset($request->gender)?$request->gender:'';
    $profileupdate['service_id']=isset($request->service_id)?$request->service_id:'';
    //$profileupdate['user_type']=isset($request->user_type)?$request->user_type:'';
    DB::table('users')->where('id',$userId)->update($profileupdate);

    //2nd Table Data Update Profle
    $profileupdatenew['name']=isset($request->name)?$request->name:'';
    $profileupdatenew['mobile']=isset($request->mobile)?$request->mobile:'';
    $profileupdatenew['gender']=isset($request->gender)?$request->gender:'';
    $profileupdatenew['date_of_birth']=isset($request->date_of_birth)?$request->date_of_birth:'';
    //$profileupdatenew['avatar']=isset($request->myname)?$request->myname:'';

    $profileupdatenew['specializations']=isset($request->specializations)?$request->specializations:'';
    $profileupdatenew['practicing']=isset($request->practicing)?$request->practicing:'';
    $profileupdatenew['experience']=isset($request->experience)?$request->experience:'';
    $profileupdatenew['license_number']=isset($request->license_number)?$request->license_number:'';
    $profileupdatenew['bank_details']=isset($request->bank_details)?$request->bank_details:'';
    $profileupdatenew['ifsc_code']=isset($request->ifsc_code)?$request->ifsc_code:'';

    $profileupdatenew['country']=isset($request->country)?$request->country:'';
    $profileupdatenew['state']=isset($request->state)?$request->state:'';
    $profileupdatenew['city']=isset($request->city)?$request->city:'';
    $profileupdatenew['pin_code']=isset($request->pin_code)?$request->pin_code:'';
    $profileupdatenew['address']=isset($request->address)?$request->address:'';
    $profileupdatenew['bio']=isset($request->bio)?$request->bio:'';

    $profileupdatenew['url_website']=isset($request->url_website)?$request->url_website:'';
    $profileupdatenew['url_facebook']=isset($request->url_facebook)?$request->url_facebook:'';
    $profileupdatenew['url_twitter']=isset($request->url_twitter)?$request->url_twitter:'';
    $profileupdatenew['url_instagram']=isset($request->url_instagram)?$request->url_instagram:'';
    $profileupdatenew['url_linkedin']=isset($request->url_linkedin)?$request->url_linkedin:'';

     DB::table('userprofiles')->where('user_id',$userId)->update($profileupdatenew);

    //Get user Data
    $user=DB::table('users')->where('users.id',$userId)
    ->join('userprofiles','userprofiles.user_id','=','users.id')
    ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin')
    ->first();
    $result['id']=isset($user->id)?$user->id:'';
    $result['name']=isset($user->name)?$user->name:'';
    // $result['email']=isset($user->email)?$user->email:'';
    $result['mobile']=isset($user->mobile)?$user->mobile:'';
    $result['date_of_birth']=isset($user->date_of_birth)?$user->date_of_birth:'';
    $result['gender']=isset($user->gender)?$user->gender:'';
    $result['user_type']=isset($user->user_type)?$user->user_type:'';
    $result['service_id']=isset($user->service_id)?$user->service_id:'';
    $result['country']=isset($user->country)?$user->country:'';
    $result['state']=isset($user->state)?$user->state:'';
    $result['city']=isset($user->city)?$user->city:'';
    $result['pin_code']=isset($user->pin_code)?$user->pin_code:'';
    $result['avatar']='';
    if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
        {
            $result['avatar']=url('img/avatars/'.$user->avatar);
        }
    else
        {
            $result['avatar']=url('img/avatars/default-user-profile.png');
        }    
    $result['specializations']=isset($user->specializations)?$user->specializations:'';
    $result['practicing']=isset($user->practicing)?$user->practicing:'';
    $result['experience']=isset($user->experience)?$user->experience:'';
    $result['license_number']=isset($user->license_number)?$user->license_number:'';
    $result['bank_details']=isset($user->bank_details)?$user->bank_details:'';
    $result['ifsc_code']=isset($user->ifsc_code)?$user->ifsc_code:'';
    $result['address']=isset($user->address)?$user->address:'';
    $result['bio']=isset($user->bio)?$user->bio:'';

    $result['device_id']=isset($user->device_id)?$user->device_id:'';
    $result['device_type']=isset($user->device_type)?$user->device_type:'';

    $result['url_website']=isset($user->url_website)?$user->url_website:'';
    $result['url_facebook']=isset($user->url_facebook)?$user->url_facebook:'';
    $result['url_twitter']=isset($user->url_twitter)?$user->url_twitter:'';
    $result['url_instagram']=isset($user->url_instagram)?$user->url_instagram:'';
    $result['url_linkedin']=isset($user->url_linkedin)?$user->url_linkedin:'';

    $resultArray['status']=1;
    $resultArray['message']=trans('api.messages.update_profile');
    $resultArray['data']= $result;
    return response()->json($resultArray); exit;
    }

    /* Delete profile image */

    public function updateProfileImage(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

        if ($validation->fails()) {
            $resultArray['status']=0;
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

        $user=DB::table('users')
        ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")->first();
        if(empty($user))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('Invalid user');
            echo json_encode($resultArray); exit; 
        }
        else
        {   
            $name='';
            if(file_exists(public_path('img/avatars/'.$user->avatar))&& !empty($user->avatar))
            {   
                unlink(public_path('img/avatars/'.$user->avatar));
            }
            
            DB::table('users')->where('id',$userId)->update(['avatar'=> Null]);
            $user=DB::table('users')->where('users.id',$userId)
            ->join('userprofiles','userprofiles.user_id','=','users.id')
            ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin')
            ->first();
            $image['id']=isset($user->id)?$user->id:'';
            $image['name']=isset($user->name)?$user->name:'';
            $image['mobile']=isset($user->mobile)?$user->mobile:'';
            $image['date_of_birth']=isset($user->date_of_birth)?$user->date_of_birth:'';
            $image['gender']=isset($user->gender)?$user->gender:'';
            $image['user_type']=isset($user->user_type)?$user->user_type:'';
            $image['service_id']=isset($user->service_id)?$user->service_id:'';
            $image['country']=isset($user->country)?$user->country:'';
            $image['state']=isset($user->state)?$user->state:'';
            $image['city']=isset($user->city)?$user->city:'';
            $image['pin_code']=isset($user->pin_code)?$user->pin_code:'';
            $image['avatar']='';
            if(!empty($user->avatar))
            {
                $image['avatar']=url('img/avatars/'.$user->avatar);
            }
            else
            {
                $image['avatar']=url('img/avatars/default-user-profile.png');
            }

            $image['specializations']=isset($user->specializations)?$user->specializations:'';
            $image['practicing']=isset($user->practicing)?$user->practicing:'';
            $image['experience']=isset($user->experience)?$user->experience:'';
            $image['license_number']=isset($user->license_number)?$user->license_number:'';
            $image['bank_details']=isset($user->bank_details)?$user->bank_details:'';
            $image['ifsc_code']=isset($user->ifsc_code)?$user->ifsc_code:'';
            $image['address']=isset($user->address)?$user->address:'';
            $image['bio']=isset($user->bio)?$user->bio:'';

            $image['device_id']=isset($user->device_id)?$user->device_id:'';
            $image['device_type']=isset($user->device_type)?$user->device_type:'';

            $image['url_website']=isset($user->url_website)?$user->url_website:'';
            $image['url_facebook']=isset($user->url_facebook)?$user->url_facebook:'';
            $image['url_twitter']=isset($user->url_twitter)?$user->url_twitter:'';
            $image['url_instagram']=isset($user->url_instagram)?$user->url_instagram:'';
            $image['url_linkedin']=isset($user->url_linkedin)?$user->url_linkedin:'';

            $resultArray['status']=1;
            $resultArray['message']=trans('Profile image updated successfully');
            $resultArray['data']=$image;
            echo json_encode($resultArray); exit;
        }
    }



    /* Get Profile of user */
    public function getProfile(Request $request)
    {  
    $validation = Validator::make($request->all(), [
        'user_id'=>'required',
    ]);

    if ($validation->fails()) {
        $resultArray['status']='0';
        $resultArray['message']=$validation->errors()->all();
        return response()->json($resultArray); exit;
    }
    $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
    $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
    App::setLocale($lang);

    // Get Data of user
    $user=DB::table('users')->where('users.id',$userId)
    ->join('userprofiles','userprofiles.user_id','=','users.id')
    ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin')
    ->first();
    if(!empty($user))
    { 
    $result['name']=isset($user->name)?$user->name:'';
    $result['email']=isset($user->email)?$user->email:'';
    $result['mobile']=isset($user->mobile)?$user->mobile:'';
    $result['date_of_birth']=isset($user->date_of_birth)?$user->date_of_birth:'';
    $result['gender']=isset($user->gender)?$user->gender:'';
    $result['service_id']=isset($user->service_id)?$user->service_id:'';
    $result['country']=isset($user->country)?$user->country:'';
    $result['state']=isset($user->state)?$user->state:'';
    $result['city']=isset($user->city)?$user->city:'';
    $result['pin_code']=isset($user->pin_code)?$user->pin_code:'';
    //$result['avatar']=isset($user->avatar)?$user->avatar:'';
    $result['avatar']='';
    if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
    {
        $result['avatar']=url('img/avatars/'.$user->avatar);
    }
    else
    {
        $result['avatar']=url('img/avatars/default-user-profile.png');
    }

    $result['specializations']=isset($user->specializations)?$user->specializations:'';
    $result['practicing']=isset($user->practicing)?$user->practicing:'';
    $result['experience']=isset($user->experience)?$user->experience:'';
    $result['license_number']=isset($user->license_number)?$user->license_number:'';
    $result['bank_details']=isset($user->bank_details)?$user->bank_details:'';
    $result['ifsc_code']=isset($user->ifsc_code)?$user->ifsc_code:'';

    $result['address']=isset($user->address)?$user->address:'';
    $result['bio']=isset($user->bio)?$user->bio:'';

    $result['url_website']=isset($user->url_website)?$user->url_website:'';
    $result['url_facebook']=isset($user->url_facebook)?$user->url_facebook:'';
    $result['url_twitter']=isset($user->url_twitter)?$user->url_twitter:'';
    $result['url_instagram']=isset($user->url_instagram)?$user->url_instagram:'';
    $result['url_linkedin']=isset($user->url_linkedin)?$user->url_linkedin:'';

    $resultArray['status']=1;
    $resultArray['data']= $result;
    $resultArray['message']=trans('api.messages.get_profile');
    return response()->json($resultArray); exit;
    }
    else
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.messages.no_profile');
            return response()->json($resultArray); exit; 
        }
    }

    /* UPDATE PASSWORD API START HERE */
    public function updatePassword(Request $request)
    {
    //print_r($request->all());die;
    $validator = Validator::make($request->all(), [
    'user_id' => 'required',
    'old_password'=>'required',
    'new_password' => 'required',
    'conf_password' => 'required',
    ]);

    if($validator->fails())
    {
        $resultArray['status']='0';
        $resultArray['message']=trans('Invalid parameters.');
        echo json_encode($resultArray); exit;      
    }

    $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
    $new_password = !empty($request->new_password) ? $request->new_password : '' ;
    $conf_password = !empty($request->conf_password) ? $request->conf_password : '' ;
    if(!empty($userid) && !empty($new_password) && !empty($conf_password))
    {
        
        $user_arr = DB::table('users')->whereRaw("(id = '".$userid."' AND deleted_at IS null )")->first();

        if(!Hash::check($request->old_password, $user_arr->password))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('Your_old_password_do_not_match');
            echo json_encode($resultArray); exit;
        }
        if($new_password === $conf_password)
        {
            if(strlen(trim($new_password)) < 6)
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('Password must be greater than 6 characters');
                echo json_encode($resultArray); exit;
            }
            else
            {
                $updatePassword_Arr['password'] = Hash::make($new_password);
                $updatePassword_Arr['updated_at'] = Carbon::now()->toDateTimeString();                  
                if(DB::table('users')->where('id', $user_arr->id)->update($updatePassword_Arr))
                {
                    $resultArray['status']='1';     
                    $resultArray['message']=trans('Password update successfully.');
                    echo json_encode($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('Password not update.');
                    echo json_encode($resultArray); exit;
                }
            }
        }
        else
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('Do not match new password and confirm password.');
            echo json_encode($resultArray); exit;
        }
    }
    else
    {
        $resultArray['status']='0';
        $resultArray['message']=trans('Invalid parameters.');
        echo json_encode($resultArray); exit;
    }
    }


    /* forgot password */

    public function forgetPasswordUpdate(Request $request)
    {
        $validator = Validator::make($request->all(), [
        'email'=>'required',
        'password'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $access_token=123456;
        $email= $request->email;
        if (filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $credentials = User::where('email',$request->email)->first();
        }
        else
        {   
            $credentials = User::where('mobile',$request->email)->first();
        }

        if(empty($credentials))
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('Details does not exist');
                return response()->json($resultArray); exit;
            }
           
        $user_arr = DB::table('users')->whereRaw("(email='". $credentials->email."' AND deleted_at IS null )")->first();
        if(!empty($user_arr))
        {  
                    
        DB::table('users')->where('id',$user_arr->id)->update(['password'=>Hash::make($request->password),'updated_at'=>now()]);
        $deviceId=DB::table('users')->where('id',$request->user_id)->first(); 
        //echo "<pre>"; print_r($deviceId); die();
        $device_id=isset($deviceId->device_id)?$deviceId->device_id:''; 

        $title='Forgot Password';
        $message='Your Password updated successfully';      
        
        $this->postpushnotification($device_id,$title,$message);
        
        $device_id=isset($deviceid->device_id)?$deviceid->device_id:'';
        if(!empty($deviceid->device_id) && $deviceid->device_type!='ios' )
        {
            $this->postpushnotification($device_id,$title,$message,$orderid,$orderstatus);
        }
        else
        {
            $this->iospush($device_id,$title,$message,$orderid,$orderstatus);
        }
        $resultArray['status']=1;
        $resultArray['message']=trans('api.password_reset_successfully');
        echo json_encode($resultArray); exit;
        }
        else
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.phone_number_does_not_exist');
            echo json_encode($resultArray); exit;
        }
    }

    /* resend otp */
    public function resendOtp(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'email'=>'required',
        ]);

        if ($validation->fails()) {
                $resultArray['status']=0;
                $resultArray['message']=trans('Invalid parameters.');
                 return response()->json($resultArray); exit;
        }
            //$otpcode= rand(1111,9999);
            $otpcode= 1234;
            $email= $request->email;
            if (filter_var($email, FILTER_VALIDATE_EMAIL))
            {
                $credentials = User::where('email',$request->email)->first();
            }
            else
            {   
                $credentials = User::where('mobile',$request->email)->first();
            }
            if(empty($credentials))
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('Details does not exist');
                return response()->json($resultArray); exit;
            }
           $credentials->verify_otp=$otpcode;
           $credentials->save();
           $user=User::where('email',$credentials->email)->first();

            $result['email']=isset($user->email)?$user->email:'';
            $result['mobile']=isset($user->mobile)?$user->mobile:'';
            $result['verify_otp']=isset($user->verify_otp)?$user->verify_otp:'';

            //$user->notify(new UserNeedsResendOtp($user->confirmation_code)); 
            $resultArray['status']=1;
            $resultArray['message']=trans('otp resend successfully');
            $resultArray['data']=$result;
            return response()->json($resultArray); exit;
    }  

    /* Verify otp */

    public function verifyOtp(Request $request)
    {
        $validation = Validator::make($request->all(), [
            'verify_otp'=>'required',
        ]);

        if ($validation->fails()) {
                $resultArray['status']=0;
                $resultArray['message']=trans('Invalid parameters.');
                 return response()->json($resultArray); exit;
        }

        $email= $request->email;
        if (filter_var($email, FILTER_VALIDATE_EMAIL))
        {
            $credentials = User::where('email',$request->email)->first();
        }
        else
        {   
            $credentials = User::where('mobile',$request->email)->first();
        }

        if(empty($credentials))
            {
                $resultArray['status']=0;
                $resultArray['message']=trans('Details does not exist');
                return response()->json($resultArray); exit;
            }

        $checkotp= User::whereRaw("(email = '".$credentials->email."' AND verify_otp ='".$request->verify_otp."')")->first();

        if(!empty($checkotp))
        {
            $checkotp->is_mobile_verified=1;
            $checkotp->save();

            $resultArray['status']=1;
            $resultArray['message']=trans('otp verified successfully.');
            return response()->json($resultArray); exit;
        }else
        {
           $resultArray['status']=0;
            $resultArray['message']=trans('invalid opt, please enter valid otp code.');
            return response()->json($resultArray); exit; 
        }
    }

    /* Delete User Account */

    public function deleteAccount(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']=0;
            $resultArray['message']=trans('Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

        User::where('id',$userId)->delete();
       
        $resultArray['status']=1;
        $resultArray['message']=trans('User account successfully deleted');
        echo json_encode($resultArray); exit;
    }



    //public function getServices(Request $request)
    public function getNursingList(Request $request)
    {
        
        $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

        $getNursing=User::where('user_type',2)
        ->join('userprofiles','userprofiles.user_id','=','users.id')
        ->join('services','services.id','=','users.service_id')
        ->where('users.confirmed',1)
        ->where('users.status',1)
        ->whereNotNull('users.email')->whereNotNull('users.mobile')->whereNotNull('users.service_id')->whereNotNull('users.date_of_birth')->whereNotNull('userprofiles.specializations')->whereNotNull('userprofiles.experience')->whereNotNull('userprofiles.license_number')->whereNotNull('userprofiles.bank_details')->whereNotNull('userprofiles.ifsc_code')
        ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin','services.id as servics_id','services.service_name','services.price')
        ->paginate(5);
        //echo '<pre>';print_r($getNursing);exit;
        
                 
        //favoritedata
        $checkfavorite = array();
        if(!empty($userid)){
        $checkfavorite=DB::table('favorites')->where('user_id',$userid)->pluck('doctor_id')->toArray();
        }
        $nursingInfo=array();
        foreach($getNursing as $p=>$nursinglist)
        {
            $nursingInfo[$p]['user_id']=$nursinglist->id;
            $nursingInfo[$p]['ratings']=0;
            $avg_stars = DB::table('user_feedbacks')->where('user_feedbacks.doctor_id',$nursinglist->id)->avg('ratings');
            if(!empty($avg_stars))
            {
                $nursingInfo[$p]['ratings']=number_format($avg_stars,1);
            }

            $nursingInfo[$p]['time_slot']=getLatestslot($nursinglist->id);
            $nursingInfo[$p]['name']=$nursinglist->name;
            $nursingInfo[$p]['email']=$nursinglist->email;
            $nursingInfo[$p]['mobile']=$nursinglist->mobile;
            $nursingInfo[$p]['user_type']=$nursinglist->user_type;
            $nursingInfo[$p]['service_id']=$nursinglist->service_id;
            $nursingInfo[$p]['gender']=$nursinglist->gender;
            $nursingInfo[$p]['favorites']=0;
            if(isset($checkfavorite) && in_array($nursinglist->id, $checkfavorite))
            {
                $nursingInfo[$p]['favorites']=1;
            }

            $nursingInfo[$p]['date_of_birth']=$nursinglist->date_of_birth;
            //$nursingInfo[$p]['avatar']=$nursinglist->avatar;
            $nursingInfo[$p]['avatar']='';
            if(!empty($nursinglist->avatar) && file_exists(public_path('img/avatars/'.$nursinglist->avatar)))
            {
                $nursingInfo[$p]['avatar']=url('img/avatars/'.$nursinglist->avatar);
            }
            else
            {
                $nursingInfo[$p]['avatar']=url('img/avatars/default-user-profile.png');
            }
            $nursingInfo[$p]['specializations']=$nursinglist->specializations;
            $nursingInfo[$p]['practicing']=$nursinglist->practicing;
            $nursingInfo[$p]['experience']=$nursinglist->experience;
            $nursingInfo[$p]['license_number']=$nursinglist->license_number;
            $nursingInfo[$p]['bank_details']=$nursinglist->bank_details;
            $nursingInfo[$p]['ifsc_code']=$nursinglist->ifsc_code;
            $nursingInfo[$p]['country']=$nursinglist->country;
            $nursingInfo[$p]['state']=$nursinglist->state;
            $nursingInfo[$p]['city']=$nursinglist->city;
            $nursingInfo[$p]['pin_code']=$nursinglist->pin_code;
            $nursingInfo[$p]['address']=$nursinglist->address;
            $nursingInfo[$p]['bio']=$nursinglist->bio;

        }
            $resultArray['status']=1;
            $resultArray['message']=trans('Nursing list get successfully');
            $resultArray['nursinglist']= $nursingInfo;
            $resultArray['page']= $getNursing->lastPage();
            echo json_encode($resultArray); exit;  
    }

    /* Get Nursing Details */
    public function getNursingDetails(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id'=>'required',
        ]);

        if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }
        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
        App::setLocale($lang);

        // Get Data of user
        $user=DB::table('users')->where('users.id',$userId)
        ->join('userprofiles','userprofiles.user_id','=','users.id')
        ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin')
        ->first();
        if(!empty($user))
        { 
        $result['id']=isset($user->id)?$user->id:'';
        $result['name']=isset($user->name)?$user->name:'';
        $result['email']=isset($user->email)?$user->email:'';
        $result['mobile']=isset($user->mobile)?$user->mobile:'';
        $result['date_of_birth']=isset($user->date_of_birth)?$user->date_of_birth:'';
        $result['gender']=isset($user->gender)?$user->gender:'';
       
        // Get Service Name and Price (Explode String to Array) 
        $serviceid=explode(',',$user->service_id);
        //echo '<pre>';print_r($serviceid);exit;
        $servicename=array();
        foreach($serviceid as $key=>$value){
            $selected = DB::table('services')
            ->where('id',$value) 
            ->first();
            $resultSrv['service_name']= isset($selected->service_name)?$selected->service_name:'';
            $resultSrv['price']= isset($selected->price)?$selected->price:'';
            $resultSrv['id']= isset($selected->id)?$selected->id:'';
             array_push($servicename,$resultSrv);

        }
        $result['service_id']=isset($servicename)?$servicename:'';

        $result['country']=isset($user->country)?$user->country:'';
        $result['state']=isset($user->state)?$user->state:'';
        $result['city']=isset($user->city)?$user->city:'';
        $result['pin_code']=isset($user->pin_code)?$user->pin_code:'';
        $result['avatar']='';
        if(!empty($user->avatar) && file_exists(public_path('img/avatars/'.$user->avatar)))
        {
            $result['avatar']=url('img/avatars/'.$user->avatar);
        }
        else
        {
            $result['avatar']=url('img/avatars/default-user-profile.png');
        }

        $result['specializations']=isset($user->specializations)?$user->specializations:'';
        $result['practicing']=isset($user->practicing)?$user->practicing:'';
        $result['experience']=isset($user->experience)?$user->experience:'';
        $result['license_number']=isset($user->license_number)?$user->license_number:'';
        $result['bank_details']=isset($user->bank_details)?$user->bank_details:'';
        $result['ifsc_code']=isset($user->ifsc_code)?$user->ifsc_code:'';

        $result['address']=isset($user->address)?$user->address:'';
        $result['bio']=isset($user->bio)?$user->bio:'';
        
        $result['url_website']=isset($user->url_website)?$user->url_website:'';
        $result['url_facebook']=isset($user->url_facebook)?$user->url_facebook:'';
        $result['url_twitter']=isset($user->url_twitter)?$user->url_twitter:'';
        $result['url_instagram']=isset($user->url_instagram)?$user->url_instagram:'';
        $result['url_linkedin']=isset($user->url_linkedin)?$user->url_linkedin:'';
        

        //get 7 days date
        $todayDay = \Carbon\Carbon::now();
        $date = date('Y-m-d',strtotime('-1 day'));
        $mydate=array();
        for($i =1; $i <= 7; $i++)
        {
            $date = date('D Y/m/d', strtotime('+1 day', strtotime($date)));
            $dates=explode(' ',$date);
            //print_r($dates);
            $day['day']=date('D',strtotime($date));
            $day['date']=$dates[1];
            array_push($mydate,$day);
        }
        //exit;

        $result['dates']=isset($mydate)?$mydate:'';
        $mergedate=date('Y-m-d');
        //print_r($mergedate);exit;
        $bookingslot= DB::table('booking_appointments')->where('doctor_id', $userId)->whereDate('booking_date',$mergedate)->pluck('booking_time')->toArray();
        //print_r($bookingslot);exit;
        //Nursing Time Slots
        $slots=getAllslots($user->id);
        
        $myslots=array();
        $nursingSlot=array();

        if(count($slots)>0)
        {
            foreach ($slots as $key => $slotday)
            {
                if($slotday->title=='mor'){
                    $nursingSlot[$key]['title']=$slotday->title;
                }
                if($slotday->title=='aft'){
                     $nursingSlot[$key]['title']=$slotday->title;
                }
                if($slotday->title=='eve'){
                    $nursingSlot[$key]['title']=$slotday->title;
                }
                $slotbooking=array();
                foreach ($slotday->getSlots as $d => $time)
                {   
                    if(in_array($time->slot_time, $bookingslot))
                    {
                        $slotbooking[$d]['time']=$time->slot_time;
                        $slotbooking[$d]['booking']=true;  
                    }
                    else
                    {
                        $slotbooking[$d]['time']=$time->slot_time;
                        $slotbooking[$d]['booking']=false;
                    }
                }
                $nursingSlot[$key]['slotes']=$slotbooking;
            }
        }

       // $result['allSlots']=isset($findarray)?$findarray:'';
        $result['allSlots']=isset($nursingSlot)?$nursingSlot:'';

        $resultArray['status']=1;
        $resultArray['data']= $result;
        $resultArray['message']=trans('api.messages.get_nursing_details');
        return response()->json($resultArray); exit;
        }
        else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.messages.no_nursing_details');
                return response()->json($resultArray); exit; 
            }
    }


    /* Get All Nursing Booking Slots, which is booked by CareSeeker */
    public function getAllBookingSlots(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id'=>'required',
            'date'=>'required',
            //'day_code'=>'required',
        ]);

        if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }
        
        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
        App::setLocale($lang);

        
        // Get Data of user
        $user=DB::table('users')->where('users.id',$userId)
        ->join('userprofiles','userprofiles.user_id','=','users.id')
        ->select('users.*','userprofiles.specializations','userprofiles.practicing','userprofiles.experience','userprofiles.license_number','userprofiles.bank_details','userprofiles.ifsc_code','userprofiles.country','userprofiles.state','userprofiles.city','userprofiles.pin_code','userprofiles.address','userprofiles.bio','userprofiles.url_website','userprofiles.url_facebook','userprofiles.url_twitter','userprofiles.url_instagram','userprofiles.url_linkedin')
        ->first();
        if(!empty($user))
        { 
        $result['name']=isset($user->name)?$user->name:'';
                            

        //get 7 days date
        $todayDay = \Carbon\Carbon::now();
        $date = date('Y-m-d',strtotime('-1 day'));
        $mydate=array();
        for($i =1; $i <= 7; $i++)
        {
            $date = date('D Y-m-d', strtotime('+1 day', strtotime($date)));
            $dates=explode(" ",$date);
            array_push($mydate,$date); 
        }

        $result['dates']=isset($mydate)?$mydate:'';
        $mergedate=date('Y-m-d');
        //print_r($mergedate);exit;
        $bookingslot= DB::table('booking_appointments')->where('doctor_id',$userId)->where('booking_date',$mergedate)->pluck('booking_time')->toArray();
        //Nursing Time Slots
        //print_r($bookingslot);exit;
        $slots=getAllBookingSlots($user->id,$request->date);
        
        $myslots=array();
        $nursingSlot=array();

        if(count($slots)>0)
        {
            foreach ($slots as $key => $slotday)
            {
                if($slotday->title=='mor'){
                    $nursingSlot[$key]['title']=$slotday->title;
                }
                if($slotday->title=='aft'){
                     $nursingSlot[$key]['title']=$slotday->title;
                }
                if($slotday->title=='eve'){
                    $nursingSlot[$key]['title']=$slotday->title;
                }
                $slotbooking=array();
                foreach ($slotday->getSlots as $d => $time)
                {   
                    if(in_array($time->slot_time, $bookingslot))
                    {
                        $slotbooking[$d]['time']=$time->slot_time;
                        $slotbooking[$d]['booking']=true;  
                    }
                    else
                    {
                        $slotbooking[$d]['time']=$time->slot_time;
                        $slotbooking[$d]['booking']=false;
                    }
                }
                $nursingSlot[$key]['slotes']=$slotbooking;
            }
        }

       // $result['allSlots']=isset($findarray)?$findarray:'';
        $result['allSlots']=isset($nursingSlot)?$nursingSlot:'';
        //$result['date']=getAllBookingSlots($date);

        $resultArray['status']=1;
        $resultArray['data']= $result;
        $resultArray['message']=trans('api.messages.get_nursing_details');
        return response()->json($resultArray); exit;
        }
        else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.messages.no_nursing_details');
                return response()->json($resultArray); exit; 
            }
    }

    
    /* Get All Nursing Availability Slots, All Doctor Time-Table */
    public function getAllNursingSlots(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            
        ]);

        if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }
         
        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $day = isset($request->day) && !empty($request->day) ? $request->day: '';
        $date = isset($request->date) && !empty($request->date) ? $request->date: '';

        if(!empty($day) && !empty($date))
        {
                $todaydate= $date;
                $myday= date('D', strtotime($todaydate));
                $resStr = $day;//strtolower($myday); 
        }
        else{
                $todaydate= date('Y-m-d');
                $myday= date('D', strtotime($todaydate));
                $resStr = strtolower($myday);  
        }
        

        /* Get All Nursing Slots */            
        $nursingSlots=WeekData::with('getDayData')->where('day_name',$resStr)->get();
        //print_r($nursingSlots);exit;   
                
        $result=array();
        if(!empty($nursingSlots))
            { 
                foreach ($nursingSlots as $key => $allSlots)
                //echo"<pre>";  print_r($allSlots);exit;
                {                                                        
                    $result[$key]['day_name']=isset($allSlots->day_name)?$allSlots->day_name:'';
                    $result[$key]['status']=isset($allSlots->status)?$allSlots->status:'';
                    $result[$key]['day_section']=isset($allSlots->day_section)?$allSlots->day_section:'';
                    
                    $result2=array();
                    foreach($allSlots->getDayData as $tkey => $timeSlots)
                    {   
                        
                        $doctorSlots = DB::table('calendar_day_sections')
                        ->where('calendar_day_sections.doctor_id',$userId)
                        //->where('calendar_day_sections.status',1)
                        ->join('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
                        ->where('calendar_day_sections.day_code',$resStr)
                        ->pluck('slot_time')->toArray();
                    
                      //  echo"<pre>";  print_r($checkstatus);exit;
                        $result2[$tkey]['id']=isset($timeSlots->id)?$timeSlots->id:'';
                       
                        $result2[$tkey]['available']=0;
                        if(!empty($doctorSlots) && in_array($timeSlots->time_slot, $doctorSlots))
                        {    
                        $result2[$tkey]['available']=1;
                        }
                        $result2[$tkey]['time_slot']=isset($timeSlots->time_slot)?$timeSlots->time_slot:'';

                    }
                
                    $result[$key]['slotes']=$result2;     
                }
               
                   $checkstatus =DB::table('calendar_day_sections')
                        ->where('calendar_day_sections.doctor_id',$userId)
                        //->where('calendar_day_sections.status',1)
                        ->join('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
                        ->where('calendar_day_sections.day_code',$resStr)
                        ->select('calendar_day_sections.*')
                        ->first();
                $myresult['status']=isset($checkstatus->status)?$checkstatus->status:''; 
                $myresult['allSlots']=isset($result)?$result:'';

                $resultArray['status']=1;
                $resultArray['data']= $myresult;
                $resultArray['message']=trans('Get Nursing Slots Successfully');
                return response()->json($resultArray); exit;
            }
                 
        $resultArray['status']='0';
        $resultArray['message']=trans('Nursing Not Available');
        return response()->json($resultArray); exit; 
    }


    /* Update All Nursing Availability Slots, All Doctor Time-Table */
    public function updateNursingSlot(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id' => 'required',
        ]);

        if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }
        
        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $status = isset($request->status) && !empty($request->status) ? $request->status: '';
        $slots = isset($request->slots) && !empty($request->slots) ? $request->slots: '';

       

        $myslots=json_decode($slots);
        if(!empty($myslots[0]->day_name))
            {
                $daycodeid=   DB::table('calendar_day_sections')
                ->Join('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
                ->where('calendar_day_sections.doctor_id',$userId)->where('calendar_day_sections.day_code',$myslots[0]->day_name)->get();
                foreach ($daycodeid as $key => $value) {
                   
                   DB::table('calendar_day_section_times')->where('doctor_id',$userId)->where('calendar_day_section_id',$value->id)->delete();
                }

             DB::table('calendar_day_sections')
                ->Join('calendar_day_section_times','calendar_day_section_times.calendar_day_section_id','=','calendar_day_sections.id')
                ->where('calendar_day_sections.doctor_id',$userId)->where('calendar_day_sections.day_code',$myslots[0]->day_name)->delete();
                 
            }
      //  echo '<pre>'; print_r($myslots[0]->day_name);exit;

        foreach ($myslots as $key => $nursingSlots)
        {
            
            if($nursingSlots->day_section=='morning')
            {
                $daysection_name='mor';
                $start_time='7:00 AM';
                $end_time='12:00 PM';
            }
            elseif($nursingSlots->day_section=='afternoon')
            {
                $daysection_name='aft';
                $start_time='12:00 PM';
                $end_time='17:00 PM';
            }
            elseif($nursingSlots->day_section=='evening')
            {
                $daysection_name='eve';
                $start_time='17:00 PM';
                $end_time='23:00 PM';
            }
           //print_r($nursingSlots);exit;
            
            $day= array('title'=>$daysection_name,'doctor_id'=>$userId,'day_code'=>$nursingSlots->day_name,'status'=>$status, 'start_time'=>$start_time, 'end_time'=>$end_time);
                $lastid= DB::table('calendar_day_sections')->insertGetId($day);
                          
            foreach($nursingSlots->slotes as $vkey => $ntimeSlots)
            {
                // //print_r($value);exit;
                if($ntimeSlots->available==1)
                {
                   $insert= array('calendar_day_section_id'=>$lastid,'doctor_id'=>$userId,'slot_time'=>$ntimeSlots->time_slot); 
                    DB::table('calendar_day_section_times')->insert($insert);     
                }
                
            }   

        }
        /* Get All Nursing Slots */            
        $nursingSlots=WeekData::with('getDayData')->get();
        //print_r($nursingSlots);exit;   
                
        // $result=array();
        // if(!empty($nursingSlots))
        //     { 
        //         foreach ($nursingSlots as $key => $allSlots)
        //         //print_r($allSlots);exit;
        //         {                                                        
        //             $result[$key]['day_name']=isset($allSlots->day_name)?$allSlots->day_name:'';
        //             $result[$key]['status']=isset($allSlots->status)?$allSlots->status:'';
        //             $result[$key]['day_section']=isset($allSlots->day_section)?$allSlots->day_section:'';
                    
        //             $result2=array();
        //             foreach($allSlots->getDayData as $tkey => $timeSlots)
        //             {   
                        
        //                 $doctorSlots = AvailabilityTimes::where('doctor_id',$userId)->pluck('slot_time')->toArray();
        //                echo"<pre>"; print_r($doctorSlots);exit;
        //                 $result2[$tkey]['id']=isset($timeSlots->id)?$timeSlots->id:'';
                       
        //                 $result2[$tkey]['available']=0;
        //                 if(!empty($doctorSlots) && in_array($timeSlots->time_slot, $doctorSlots))
        //                 {    
        //                 $result2[$tkey]['available']=1;
        //                 }
        //                 $result2[$tkey]['time_slot']=isset($timeSlots->time_slot)?$timeSlots->time_slot:'';

        //             }
        //             $result[$key]['slotes']=$result2;     
        //         }
               
        //         $myresult['allSlots']=isset($result)?$result:'';

        //         $resultArray['status']=1;
        //         //$resultArray['data']= $myresult;
        //         $resultArray['message']=trans('Get Nursing Slots Successfully');
        //         return response()->json($resultArray); exit;
        //     }
                 
        $resultArray['status']='0';
        $resultArray['message']=trans('Nursing Slots Update successfully');
        return response()->json($resultArray); exit; 
    }

    /*  Slots full day block  */
    public function fullDaySlotsBlock(Request $request)
    {  
        $validation = Validator::make($request->all(), [
            'user_id' => 'required',
            'day_code' => 'required',
            'status' => 'required',

        ]);

        if ($validation->fails()) {
            $resultArray['status']='0';
            $resultArray['message']=$validation->errors()->all();
            return response()->json($resultArray); exit;
        }
        
        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $day_code = isset($request->day_code) && !empty($request->day_code) ? $request->day_code: '';
        $status = isset($request->status) && !empty($request->status) ? $request->status: '';

        $slots=DB::table('calendar_day_sections')->where('day_code',$request['day_code'])
        ->where('calendar_day_sections.doctor_id',$userId)->update(['status'=>$request['status']]);

        $resultArray['status']=1;
        //$resultArray['data']= $slots;
        $resultArray['message']=trans('Slots status updated successfully');
        return response()->json($resultArray); exit;
    }
}   