<?php

// Scooter Management
Route::group(['namespace' => 'Products'], function () {
    //Route::resource('business', 'BusinessController', ['except' => ['show']]);
    Route::get('products', 'ProductsController@index')->name('products.show');
    Route::get('products/create', 'ProductsController@create')->name('products.create');
    Route::post('products/store', 'ProductsController@Store')->name('products.store');
    Route::get('products/{id}/edit', 'ProductsController@edit')->name('products.edit');
    Route::post('products/update/{id}', 'ProductsController@Update')->name('products.update');
    Route::DELETE('products/{id}', 'ProductsController@productsDelete')->name('products.delete');
    Route::get('products/image/{id}', 'ProductsController@deleteImage')->name('products.deleteimage');


    //Drop Routes
     Route::get('scooters/drop', 'ScooterController@drop')->name('scooters.drop');
    Route::post('scooters/drop/store', 'ScooterController@dropStore')->name('scooters.drop.store');
    Route::get('scooters/drop/create', 'ScooterController@dropCreate')->name('scooters.drop.create');
    Route::get('scooters/drop/{id}/edit', 'ScooterController@dropEdit')->name('scooters.drop.edit');
    Route::PATCH('scooters/drop/update/{id}', 'ScooterController@dropUpdate')->name('scooters.drop.update');
    Route::DELETE('scooters/drop/{id}', 'ScooterController@dropDelete')->name('scooters.drop.delete');

});
