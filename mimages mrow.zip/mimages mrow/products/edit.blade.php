@extends('backend.layouts.app')

@section('title', __('products Management') . ' | ' . __('labels.backend.access.blogs.edit'))

@section('breadcrumb-links')
    @include('backend.products.includes.breadcrumb-links')
@endsection

@section('content')
<form method="post" action="{{route('admin.products.update',$products->id)}}" enctype="multipart/form-data">
  @csrf
    <div class="card">
        @include('backend.products.editform')
        @include('backend.components.footer-buttons', [ 'cancelRoute' => 'admin.products.show', 'id' => $products->id ])
    </div><!--card-->
</form>
@endsection