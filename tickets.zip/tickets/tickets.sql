-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 09, 2023 at 04:58 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clean_smart_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `site_id` int(11) DEFAULT NULL,
  `task` longtext,
  `description` longtext,
  `date` date DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '0=>hide,1=>show',
  `ticket_type` int(11) NOT NULL DEFAULT '0' COMMENT '0=>Standard,1=>Red Flagged',
  `ticket_status` int(11) NOT NULL DEFAULT '0' COMMENT '0=>Pending,1=>Complete,2=>Reopen',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site` (`site_id`)
) ENGINE=InnoDB AUTO_INCREMENT=105 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`id`, `user_id`, `site_id`, `task`, `description`, `date`, `image`, `status`, `ticket_type`, `ticket_status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 200, 1, 'Unclean Sink', 'ut also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop', '2022-11-10', NULL, 1, 1, 0, '2022-11-11 01:33:13', '2022-11-13 17:35:47', NULL),
(2, 204, 2, 'Demo', 'just demo ticket', '2022-11-23', NULL, 1, 1, 1, '2022-11-13 13:24:41', '2022-11-13 13:32:27', NULL),
(3, 206, 3, 'Ticket test1', 'Ticket test1Ticket test1Ticket test1Ticket test1Ticket test1', '2022-11-15', NULL, 1, 1, 0, '2022-11-13 18:17:48', '2022-11-13 18:17:48', NULL),
(10, 206, 3, 'Ticket test2', 'Ticket test2Ticket test2Ticket test2Ticket test2', '2022-11-14', NULL, 1, 1, 1, '2022-11-13 19:09:06', '2022-11-15 17:29:13', NULL),
(52, 206, 3, 'CEO Meeting Tomorrow TEST', 'A clean room (or cleanroom) is an enclosed space in which airborne particulates, contaminants, and pollutants are kept within strict limits. In industry, clean rooms are used in the manufacture and servicing of hardware such as integrated circuits ( IC s) and hard drive..', '2022-11-16', NULL, 1, 1, 0, '2022-11-14 00:54:03', '2022-11-14 00:54:03', NULL),
(53, 217, 6, 'Test 1001', 'Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001 Test 1001', '2022-11-16', NULL, 1, 1, 0, '2022-11-15 18:22:00', '2022-11-15 18:22:35', NULL),
(54, 212, 4, 'Testing 2001', 'Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001 Testing 2001', '2022-11-16', NULL, 1, 1, 0, '2022-11-15 18:43:38', '2022-11-15 18:43:45', NULL),
(55, 234, 7, 'unclean bathroom', 'Fungus, including mold, mildew, yeasts and some types of bacteria rapidly build up in bathroom environments,\" Reynolds says. \"These humidity-loving microbes can be seen in the corners and crevices of showers, sinks, faucet handles and toilet bowls, and they can even grow on floors and walls', '2022-11-09', NULL, 1, 1, 0, '2022-11-15 23:15:49', '2022-11-16 00:30:40', NULL),
(56, 234, 7, 'Room unclean', 'A messy room can be a sign of depression or another mental health issue. Clutter affects your mood and can cause more anxiety or stress.', '2022-11-09', NULL, 1, 1, 1, '2022-11-15 23:17:08', '2022-11-16 00:25:56', NULL),
(57, 234, 7, 'unclean room', 'Is a messy house a sign of mental illness, you might ask. Psychology says that messiness can indeed be a sign that a person is having trouble. Just like someone who is suffering from OCD', '2022-11-11', NULL, 1, 1, 1, '2022-11-15 23:18:10', '2022-11-16 00:26:28', NULL),
(58, 234, 7, 'Messiness Room', 'OCD and has to control everything, being a messy person might show that they are dealing with depression or some other mental illness', '2022-11-07', NULL, 1, 1, 1, '2022-11-15 23:19:08', '2022-11-16 00:26:28', NULL),
(59, 235, 8, 'unclean room', 'What does a dirty room say about a person?\r\nImage result for unclean room\r\nIs a messy house a sign of mental illness, you might ask. Psychology says that messiness can indeed be a sign that a person is having trouble', '2022-11-06', NULL, 1, 1, 1, '2022-11-15 23:21:54', '2022-11-16 00:37:25', NULL),
(60, 235, 8, 'room unclean', 'Just like someone who is suffering from OCD and has to control everything, being a messy person might show that they are dealing with depression or some other', '2022-11-07', NULL, 1, 1, 1, '2022-11-15 23:22:51', '2022-11-16 00:37:40', NULL),
(61, 235, 8, 'unclean bedroom', 'A dirty bedroom is about more than an untidy space with clothes on the floor. The simple fact of the matter is that your bedroom can quickly become full of', '2022-11-08', NULL, 1, 1, 1, '2022-11-15 23:24:14', '2022-11-16 00:47:24', NULL),
(62, 235, 8, 'bedroom unclean', 'Memes for when you\'re feeling a little naughty. But before you get going, get your weekend that much closer with these Thursday memes all about bringing the weekend into your grasp.', '2022-11-11', NULL, 1, 1, 1, '2022-11-15 23:25:48', '2022-11-16 22:18:49', NULL),
(63, 236, 9, 'dirty bedroom', 'Room is untidy with all clothes that were laundry but cannot manage to the closet', '2022-11-07', NULL, 1, 1, 0, '2022-11-15 23:27:54', '2022-11-15 23:28:03', NULL),
(64, 236, 9, 'unclean bedroom', 'While extreme messiness can be the result of depression or behavioral issues, extreme organization can be a sign of obsessive-compulsive disorder (OCD). Teens with OCD experience intense anxiety if anything in their room or their surroundings is out of place.', '2022-11-08', NULL, 1, 1, 0, '2022-11-15 23:29:16', '2022-11-15 23:29:16', NULL),
(65, 236, 9, 'unclean room', 'Is being messy a mental illness?\r\nWhile extreme messiness can be the result of depression or behavioral issues, extreme organization can be a sign of obsessive-compulsive disorder (OCD). Teens with OCD experience intense anxiety if anything in their room or their surroundings is out of place.', '2022-11-10', NULL, 1, 1, 0, '2022-11-15 23:30:03', '2022-11-15 23:30:03', NULL),
(66, 236, 9, 'unclean room', 'Is being messy a mental illness?\r\nWhile extreme messiness can be the result of depression or behavioral issues, extreme organization can be a sign of obsessive-compulsive disorder (OCD). Teens with OCD experience intense anxiety if anything in their room or their surroundings is out of place.', '2022-11-10', NULL, 1, 1, 0, '2022-11-15 23:31:44', '2022-11-15 23:31:44', NULL),
(67, 237, 10, 'unclean room', 'Is being messy a mental illness?\r\nWhile extreme messiness can be the result of depression or behavioral issues, extreme organization can be a sign of obsessive-compulsive disorder (OCD). Teens with OCD experience intense anxiety if anything in their room or their surroundings is out of place.', '2022-11-07', NULL, 1, 1, 0, '2022-11-15 23:35:24', '2022-11-15 23:35:24', NULL),
(68, 237, 10, 'room unclean', 'Are intelligent people messy?\r\nConsequently, we all know how creativity is a common trait of genius people. The study conducted by the University of Minnesota goes on to state that genius leaves their desk messy because they invest the time needed to clean and organize the more important stuff.', '2022-11-10', NULL, 1, 1, 0, '2022-11-15 23:36:10', '2022-11-15 23:36:10', NULL),
(69, 237, 10, 'unclean bedroom', 'A dirty bedroom is about more than an untidy space with clothes on the floor. The simple fact of the matter is that your bedroom can quickly become full of', '2022-11-11', NULL, 1, 1, 0, '2022-11-15 23:37:02', '2022-11-15 23:37:02', NULL),
(70, 237, 10, 'bedroom unclean', 'A dirty bedroom is about more than an untidy space with clothes on the floor. The simple fact of the matter is that your bedroom can quickly become', '2022-11-12', NULL, 1, 1, 0, '2022-11-15 23:37:54', '2022-11-15 23:37:54', NULL),
(71, 235, 8, 'Capital', 'Welcome to Capital Hair & Beauty, the UK\'s largest independent supplier to hair and beauty professionals. Choose from our vast range of great value hair and beauty supplies and book training courses at a location near you, we have 60 stores throughout the UK & Ireland.', '2022-11-09', NULL, 1, 1, 0, '2022-11-16 00:50:16', '2022-11-16 00:50:39', NULL),
(103, 206, 3, 'Manager Meeting', 'Manager Meeting Today for office cleaning', '2022-11-29', NULL, 1, 1, 0, '2022-11-29 03:28:04', '2022-11-29 03:28:04', NULL),
(104, 206, 3, 'CEO Meeting Tomorrow', 'CEO Meeting Tomorrow TEST', '2022-11-30', NULL, 1, 1, 0, '2022-11-29 03:31:26', '2022-11-29 03:31:26', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
