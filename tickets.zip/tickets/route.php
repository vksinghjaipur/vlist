<?php

/*********** Tickets *********/
    Route::get("/tickets", [TicketsController::class, "index"])->name('tickets');
    Route::get("/tickets/site/{SITE_ID}", [TicketsController::class, "index"])->name('tickets.site');
    Route::get("/tickets/add", [TicketsController::class, "create"])->name('tickets.add');
    Route::post("/tickets/add", [TicketsController::class, "store"]);
    Route::get("/tickets/edit/{id}", [TicketsController::class, "edit"])->name('tickets.edit');
    Route::PUT("/tickets/edit/{id}", [TicketsController::class, "update"]);
    Route::get("/tickets/delete/{id}", [TicketsController::class, "destroy"])->name('tickets.destroy');
    Route::get("/tickets-details/{id}", [TicketsController::class, "show"])->name('tickets.details');
    Route::post("/tickets/update-status", [TicketsController::class, "updateStatus"])->name('tickets.updateStatus');
    Route::post("/tickets/update-type", [TicketsController::class, "updateType"])->name('tickets.updateType');
    /***********End  Mnager Tickets *********/