<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Cleaningcompanies;
use App\Models\Tickets;
use App\Models\Sites;
use App\Models\TicketImage;
use App\Models\AssignSite;
use App\Models\ManagerSite;
use App\Mail\Registration;
use App\Mail\TicketNotification;

use Illuminate\Http\Request;
use View,Session,DB,Auth,Validator,Response,File,Mail;

class TicketsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request, $siteId="")
    {
        
        $userDetails    =   Auth::user();

        $DB             =   Tickets::query();
        $DB->with('site');

        if($userDetails->user_role_id == ADMIN_ROLE){
            if($siteId){
                $DB->where('site_id',$siteId);
            }else{
                return back()->with('error', 'Invalid Request!');
            }
        }else if($userDetails->user_role_id == CLIENT_ROLE){
            if($siteId){
                $DB->where('site_id',$siteId);
            }else{
                return back()->with('error', 'Invalid Request!');
            }
        }else if($userDetails->user_role_id == CLEANING_COMPANY_ROLE){
            if($siteId){
                $DB->where('site_id',$siteId);
            }else{
                return back()->with('error', 'Invalid Request!');
            }
        }else if($userDetails->user_role_id == CLEANING_MANAGER_ROLE){
            if($siteId){
                $DB->where('site_id',$siteId);
            }else{
                return back()->with('error', 'Invalid Request!');
            }
        }else{
            $DB->where('user_id',Auth::user()->id);
        }

        $tickets = $DB->paginate(PAGE_LIMIT);
        
        //pr($tickets); die;
        return view('tickets.index',compact('tickets'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $userDetails = Auth::user();

        $clientDetails  =   User::with('parent')->where('id',$userDetails->id)->first();

        //pr($userDetails->site->cleaningCompany->companyDetails); die;

        return view('tickets.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */


    public function store(Request $request) {
        $emailUser = Auth::user(); 
       // pr($emailUser);die();

        $siteId     =   Auth::user()->site->id ?? 0;
        
        $reqData    =   $request->all();

        $this->validate($request,[
            'task'          =>  'required',
            'description'   =>  'required',
            'date'          =>  'required',
            'images.0'      =>  'required|image',
        ]);

        $ticket                 =   new Tickets();
        $ticket->task           =   $request->task;
        $ticket->user_id        =   Auth::user()->id;
        $ticket->site_id        =   $siteId;
        $ticket->description    =   $request->description;
        $ticket->ticket_type    =   $request->ticket_type;
        $ticket->date           =   date('Y-m-d', strtotime($request->date));
        if($ticket->save()) {
            if(!empty($reqData['images'])){
                foreach($reqData['images'] as $file){
                    if(!empty($file)){
                        $filename   = time().$file->getClientOriginalName();
                        $folderPath = date("Y").DS.strtoupper(date("M")).DS;
                        $path       = TICKET_IMAGE_ROOT_PATH.$folderPath;
                        if(! File::exists($path)) {
                            File::makeDirectory($path, $mode = 0777, true, true);
                        }
                        if($file->move($path, $filename)){
                            $ticketImage                =   new TicketImage();
                            $ticketImage->ticket_id     =   $ticket->id;
                            $ticketImage->image         =   $folderPath.$filename;
                            $ticketImage->save();
                        }
                    }
                }

            }

            $siteMgrName = $emailUser->full_name;

            if($ticket->ticket_type == 1){
                Mail::to($emailUser->parent->email)->send(new TicketNotification($ticket, $siteMgrName));
                
                $companyUserIds =   AssignSite::where('site_id',$siteId)->pluck('company_user_id','company_user_id')->toArray(); 
                if(!empty($companyUserIds)){
                    foreach($companyUserIds as $companyUserId){
                        $companyUser = User::where('id',$companyUserId)->where('user_role_id',CLEANING_COMPANY_ROLE)->first();
                        //pr($companyUser->full_name);die();
                        if(!empty($companyUser)){
                            Mail::to($companyUser->email)->send(new TicketNotification($ticket, $siteMgrName));
                        }
                    }
                }
                $companyMangUserIds =   ManagerSite::where('site_id',$siteId)->pluck('user_id','user_id')->toArray();
                if(!empty($companyMangUserIds)){
                    foreach($companyMangUserIds as $companyMangUserId){
                        $companyMangUser = User::where('id',$companyMangUserId)->where('user_role_id',CLEANING_MANAGER_ROLE)->first();
                        if(!empty($companyMangUser)){
                            Mail::to($companyMangUser->email)->send(new TicketNotification($ticket, $siteMgrName));
                        }
                    }
                } 
            }
            
            return redirect()->route('tickets')->with('success', 'Ticket Added Successfully');
        }
        else {
            return Redirect::back()->with('error', 'Ticket not added! Please try again.'); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tickets  $tickets
     * @return \Illuminate\Http\Response
     */
    public function show($id) {

        $details = Tickets::find($id);
        if(!$details){
            return redirect()->route('tickets')->with('error','Tickets not found!');
        }

        return view('tickets.details',compact('details'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tickets  $tickets
     * @return \Illuminate\Http\Response
     */
    public function edit($id) {
        $details = Tickets::find($id);
        if(!$details){
            return redirect()->route('tickets')->with('error','Tickets not found!');
        }

        return view('tickets.edit',compact('details'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tickets  $tickets
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id){
        $reqData    =   $request->all();

        $this->validate($request,[
            'task'          =>  'required',
            'description'   =>  'required',
            'date'          =>  'required'
        ]);
        

        $ticket                 =   Tickets::find($id);
        $ticket->task           =   $request->task;
        $ticket->description    =   $request->description;
        $ticket->ticket_type    =   $request->ticket_type;
        $ticket->date           =   date('Y-m-d', strtotime($request->date));
        if($ticket->save()) {
            if(!empty($reqData['images'])){
                foreach($reqData['images'] as $file){
                    if(!empty($file)){
                        $filename   = time().$file->getClientOriginalName();
                        $folderPath = date("Y").DS.strtoupper(date("M")).DS;
                        $path       = TICKET_IMAGE_ROOT_PATH.$folderPath;
                        if(! File::exists($path)) {
                            File::makeDirectory($path, $mode = 0777, true, true);
                        }
                        if($file->move($path, $filename)){
                            $ticketImage                =   new TicketImage();
                            $ticketImage->ticket_id     =   $ticket->id;
                            $ticketImage->image         =   $folderPath.$filename;
                            $ticketImage->save();
                        }
                    }
                }
                
            }

            return redirect()->route('tickets')->with('success', 'Tickets updated successfully.');
        }else{
            return redirect()->route('tickets')->with('error', 'Something went wrong! Ticket not updated.');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tickets  $tickets
     * @return \Illuminate\Http\Response
     */
    public function destroy($id) {
        $result = Tickets::find($id);
        if(!$result){
            return redirect()->route('tickets')->with('error','Ticket not found!');
        }

        TicketImage::where('ticket_id',$result->id)->delete();
        $result->delete();

        return back()->with('success', 'Tickets delete successfully.');
    }

    public function updateStatus(Request $request){
        if(!empty($request->ticket_id)){
            $ticket = Tickets::find($request->ticket_id);
            if(!empty($ticket)){
                if($request->ticket_status){
                    $newStatus  =   $request->ticket_status ?? 0;
                }else{
                    if($ticket->ticket_status == 1){
                        $newStatus  =   0;
                    }else{
                        $newStatus  =   1;
                    }
                }
                $ticket->ticket_status  =   $newStatus;
                $ticket->save();

                $response['success']        =   true;
                $response['ticket_status']  =   $newStatus;
            }else{
                $response['error']        =   false;
            }
        }else{
            $response['error']        =   false;
        }
        return Response::json($response);
    }
    
    public function updateType(Request $request){
        if(!empty($request->ticket_id)){
            $ticket = Tickets::find($request->ticket_id);
            if(!empty($ticket)){
                $newType  =   $request->ticket_type;
                $ticket->ticket_type  =   $newType;
                $ticket->save();

                $response['success']        =   true;
                $response['ticket_type']    =   $newType;
            }else{
                $response['error']        =   false;
            }
        }else{
            $response['error']        =   false;
        }
        return Response::json($response);
    }
    
}