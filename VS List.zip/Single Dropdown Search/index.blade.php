@extends('backend.layouts.app')

@section('title', app_name() . ' | ' . __('labels.backend.access.guessfixtures.management'))

@section('breadcrumb-links')
@include('backend.guessfixtures.includes.breadcrumb-links')
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    {{ __('labels.backend.access.guessfixtures.management') }} <small class="text-muted">{{ __('labels.backend.access.guessfixtures.active') }}</small>
                </h4>
            </div>
            <!--col-->
        </div>
        <!--row-->
        <center><h4><u>Create Matches (Fixtures) By Admin For Guess Matches</u></h4></center>
        <?php $matches_count = DB::table('guessfixtures')->count(); ?>
        <strong><span>Total Matches (API): </span><span class="text-danger"> {{ $matches_count }}</span></strong><span><center><strong>Status->  <span class="text-success">Active = Guess On,</span> <span class="text-danger">Inactive = Guess Off</span></center></strong></span><br>
          <center><a class="btn btn-info" href="http://localhost/guesszone/public/import/fixtures" target="_blank">Click for Update Matches From API</a></center>

        <div class="row mt-4">
            <div class="col">
                {{-- <div class="table-responsive"> --}}
                <div class="row">   
                    <div class="col-md-4">
                        <div class="category-filter">
                            <select id="selectjobtitle" class="form-control text-info font-weight-bold">
                                <option value="">Select League Name (All)</option>
                            </select>
                        </div>
                    </div>
                             
                    <div class="col-md-4">
                        <div class="category-filter">
                            <select id="selectjobtitle2" class="form-control text-dark font-weight-bold">
                                <option value="">Select Country Name (All)</option>
                            </select>
                        </div>
                    </div>
                </div><br>    


                <table id="example" class="table-sm table-bordered" data-ajax_url="{{ route("admin.guessfixtures.get") }}">
                    <thead>
                        <tr>
                            <th><input type="checkbox" name="main_checkbox"><label></label></th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.league_id') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.league_name') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.league_country') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.team_home_name') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.team_home_logo') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.team_away_name') }}</th>
                            <th>{{ trans('labels.backend.access.guessfixtures.table.team_away_logo') }}</th>
                            
                            <th class="text-center">{{ trans('labels.backend.access.guessfixtures.table.publish_datetime') }}</th>
                            
                            <th>{{ trans('labels.backend.access.guessfixtures.table.date') }}</th>                              
							<th class="text-center"><button class="btn btn-sm btn-success d-none" id="activeInactiveBtn">Active-Inactive</button>{{ trans('labels.backend.access.guessfixtures.table.status') }}</th>

                            {{-- <th>{{ trans('labels.backend.access.fixtures.table.createdby') }}</th>
                            <th>{{ trans('labels.backend.access.fixtures.table.createdat') }}</th> --}}
                                                           
                            <th class="text-center"><button class="btn btn-sm btn-danger d-none" id="deleteAllBtn">Delete All</button>{{ trans('labels.general.actions')}}</th>
                        </tr>
                    </thead>
                    

                    @foreach($guessfixture as $lead)
                     <tr>
                        <td><input type="checkbox" name="league_name" value="{{ $lead->id }}" data-id="{{ $lead->id }}"></td>
                        <td>{{ $lead->id }}</td>
                        <td class="text-info font-weight-bold">{{ $lead->league_name }}</td>
                        <td class="text-dark font-weight-bold">{{ $lead->league_country }}</td>
                        <td>{{ $lead->team_home_name }}</td>
                        <td>
                            <?php $data= explode('https',$lead->team_home_logo);?>
                            @if(isset($data) && !empty ($data[1]))
                            <img src="{{ $lead->team_home_logo }}" height="40">
                                 
                            @else
                            <img src="{{asset('/img/guessfixtures/'.$lead->team_home_logo)}}" height="40" width="60">
                               
                            @endif
                        </td>

                        <td>{{ $lead->team_away_name }}</td>
                        <td>    
                            <?php $data= explode('https',$lead->team_away_logo);?>
                            @if(isset($data) && !empty ($data[1]))
                            <img src="{{ $lead->team_away_logo }}" height="40">
                                 
                            @else
                            <img src="{{asset('/img/guessfixtures/'.$lead->team_away_logo)}}" height="40">
                               
                            @endif

                        </td>

                        <td>{{$lead->publish_datetime}}</td>
                        <td>{{$lead->date}}</td>
                        
                        <td class="text-center">
                            @if($lead->status==1)
                            <label class="btn btn-success">Active</label>
                            @else
                              <label class="btn btn-danger">Inactive</label>  
                            @endif
                        </td>

                        <td class="btn-td text-center"><div class="btn-group" role="group" aria-label="User Actions"><a href="{{ url('/admin/guessfixtures/'.$lead->id.'/edit') }}" data-toggle="tooltip" data-placement="top" title="Edit" class="btn btn-primary btn-sm">
                        <i class="fas fa-edit"></i></a>
                        <a href="#" class="btn btn-primary btn-danger btn-sm" data-method="delete" data-trans-button-cancel="Cancel" data-trans-button-confirm="Delete" data-trans-title="Are you sure you want to do this?" style="cursor:pointer;" onclick="$(this).find(&quot;form&quot;).submit();">
                        <i data-toggle="tooltip" data-placement="top" title="Delete" class="fa fa-trash"></i>
                
                        <form action="{{ url('admin/guessfixtures/'.$lead->id) }}" method="POST" name="delete_item" style="display:none">
                        <input type="hidden" name="_method" value="delete">
                        {{ csrf_field() }}
                        </form>

                        </a>
                        </div>
                        </td>
                    </tr>
                    @endforeach
                </table>
                </div>
            </div>
            <!--col-->
        </div>
        <!--row-->

    </div>
    <!--card-body-->
</div>
<!----------------------V Delete All Function Start------------------------------------->
<script src="{{ asset('vkalldelete/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('vkalldelete/sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ asset('vkalldelete/toastr/toastr.min.js') }}"></script>
<script type="text/javascript">
    toastr.options.preventDuplicates = true;
         $.ajaxSetup({
             headers:{
                 'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
             }
         });
</script>    
            
<script type="text/javascript">
    $(document).on('click','input[name="main_checkbox"]', function(){
          if(this.checked){
            $('input[name="league_name"]').each(function(){
                this.checked = true;
            });
          }else{
             $('input[name="league_name"]').each(function(){
                 this.checked = false;
             });
          }
          toggledeleteAllBtn();
    });


    $(document).on('change','input[name="league_name"]', function(){

       if( $('input[name="league_name"]').length == $('input[name="league_name"]:checked').length ){
           $('input[name="main_checkbox"]').prop('checked', true);
       }else{
           $('input[name="main_checkbox"]').prop('checked', false);
       }
       toggledeleteAllBtn();
    });



    function toggledeleteAllBtn(){
       if( $('input[name="league_name"]:checked').length > 0 ){
           $('button#deleteAllBtn').text('Delete ('+$('input[name="league_name"]:checked').length+')').removeClass('d-none');
       }else{
           //$('button#deleteAllBtn');
           $('button#deleteAllBtn').addClass('d-none');
       }
    }


/* V Delete All Button */
$(document).on('click','button#deleteAllBtn', function(){
            var checkedCountries = [];
            $('input[name="league_name"]:checked').each(function(){
               checkedCountries.push($(this).data('id'));
            });
            var url = '{{ route("deleteallleagues") }}';
            if(checkedCountries.length > 0){
            swal.fire({
                   title:'Are you sure?',
                   html:'You want to delete <b>('+checkedCountries.length+')</b> countries',
                   showCancelButton:true,
                   showCloseButton:true,
                   confirmButtonText:'Yes, Delete',
                   cancelButtonText:'Cancel',
                   confirmButtonColor:'#556ee6',
                   cancelButtonColor:'#d33',
                   width:300,
                   allowOutsideClick:false
                }).then(function(result){
                   if(result.value){
                       $.post(url,{countries_ids:checkedCountries},function(data){
                          if(data.code == 1){
                              $('#guessfixtures-table').DataTable().ajax.reload(null, true);
                              toastr.success(data.msg);
                              window.location.reload();
                          }
                       },'json');
                   }
                })
            }
        });    

</script>
<!---------------------------V Delete All Function End------------------------------------>


<!---------------------------V Active Inactive Start ------------------------------------->
<script type="text/javascript">
    toastr.options.preventDuplicates = true;
         $.ajaxSetup({
             headers:{
                 'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
             }
         });
</script>    
            

<script type="text/javascript">
    $(document).on('click','input[name="main_checkbox"]', function(){
          if(this.checked){
            $('input[name="league_name"]').each(function(){
                this.checked = true;
            });
          }else{
             $('input[name="league_name"]').each(function(){
                 this.checked = false;
            });
          }
          toggleactiveInactiveBtn();
    });


    $(document).on('change','input[name="league_name"]', function(){

       if( $('input[name="league_name"]').length == $('input[name="league_name"]:checked').length ){
           $('input[name="main_checkbox"]').prop('checked', true);
       }else{
           $('input[name="main_checkbox"]').prop('checked', false);
       }
       toggleactiveInactiveBtn();
    });

    function toggleactiveInactiveBtn(){
       if( $('input[name="league_name"]:checked').length > 0 ){
           $('button#activeInactiveBtn').text('Active-Inactive ('+$('input[name="league_name"]:checked').length+')').removeClass('d-none');
       }else{
           //$('button#activeInactiveBtn');
           $('button#activeInactiveBtn').addClass('d-none');
       }
    }


/* V Delete All Button */
$(document).on('click','button#activeInactiveBtn', function(){
            var checkedCountries = [];
            $('input[name="league_name"]:checked').each(function(){
               checkedCountries.push($(this).data('id'));
            });
            //alert(checkedCountries);
            var url = '{{ route("changeStatusfixture") }}';
            if(checkedCountries.length > 0){
            swal.fire({
                   title:'Are you sure?',
                   html:'Active or Inactive <b>('+checkedCountries.length+')</b> Leagues',
                   showCancelButton:true,
                   showCloseButton:true,
                   confirmButtonText:'Yes, Active or Inactive',
                   cancelButtonText:'Cancel',
                   confirmButtonColor:'#556ee6',
                   cancelButtonColor:'#d33',
                   width:300,
                   allowOutsideClick:false
                }).then(function(result){
                   if(result.value){
                       $.get(url,{leagues_ids:checkedCountries},function(data){
                          if(data.code == 1){
                              $('#guessfixtures-table').DataTable().ajax.reload(null, true);
                              toastr.success(data.msg);
                              window.location.reload();
                          }
                       },'json');
                   }
                })
            }
        });    

</script>
<!----------------------------V Active Inactive End -------------------------------------->
<script>
/* When the user clicks on the button,
toggle between hiding and showing the dropdown content */
function myFunction() {
  document.getElementById("myDropdown").classList.toggle("show");
}

function filterFunction() {
  var input, filter, ul, li, a, i;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  div = document.getElementById("myDropdown");
  a = div.getElementsByTagName("a");
  for (i = 0; i < a.length; i++) {
    txtValue = a[i].textContent || a[i].innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      a[i].style.display = "";
    } else {
      a[i].style.display = "none";
    }
  }
}
</script>


<!----------------------V GS Drop Down League Search Start-------------------------------->
<script>
    $(document).ready(function() {

    var table = $('#example').DataTable( {
    
    initComplete: function () {
        this.api().columns( [ 2 ] ).every(function () {
            var column = this;
            var select = $('#selectjobtitle')
                .on('change', function () {
                    var val = $(this).val();
                    column.search(val).draw();
            });

            column.data().unique().sort().each(function (d, j) {
                select.append('<option value="' + d + '">' + d + '</option>')
            });
        });

          this.api().columns( [ 3 ] ).every(function () {
            var column = this;
            var select = $('#selectjobtitle2')
                .on('change', function () {
                    var val = $(this).val();
                    column.search(val).draw();
            });
            column.data().unique().sort().each(function (a, b) {
                select.append('<option value="' + a + '">' + a + '</option>')
            });
        });
    }    
  } );

} );
</script>
<!-----------------------V GS Drop Down League Search Start-------------------------------->











@endsection


@section('pagescript')
<script>
    FTX.Utils.documentReady(function() {
        FTX.Guessfixtures.list.init();
    });
</script>



@stop

