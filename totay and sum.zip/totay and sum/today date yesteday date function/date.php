<?php

$today=date('Y-m-d');
//$today=date('Y-m-d'-'1 days'));
$yesterday=date('Y.m.d',strtotime("-1 days"));

echo "Today Date: ".$today .'<br>';

echo "Yesterday: ".$yesterday;
?>