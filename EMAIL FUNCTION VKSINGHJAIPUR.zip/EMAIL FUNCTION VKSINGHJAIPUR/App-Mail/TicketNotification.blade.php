<?php
 
namespace App\Mail;
 
use App\Models\User;
use App\Models\Tickets;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Hash,Helper;

class TicketNotification extends Mailable
{
    use Queueable, SerializesModels;
 
    /**
     * The user instance.
     *
     * @var \App\Models\User
     */
    protected $ticket;
    //protected $pstring;
 
    /**
     * Create a new message instance.
     *
     * @param  \App\Models\User  $user
     * @return void
     */
    public function __construct($ticket, $siteMgrName="")
    {
        $this->ticket = $ticket;

        $this->siteMgrName = $siteMgrName;
    }
 
    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        
        /* if($this->user->user_role_id == CLIENT_ROLE){
            $password       =   $this->pstring;
            $sitename       =   '';
        }else{
            $password       =   Helper::random_password();
            $passwordHash   =   Hash::make($password);
            $this->user->update(['password'=>$passwordHash]);
            $sitename       = $this->user->site->name;
        } */

        $sitename       =   '';
        $addedBy    =   "Site Manager";
        

        return $this->view('emails.ticket_notification')
                    ->with([
                        'userId' => $this->ticket->user_id,
                        'userName' => $this->siteMgrName,
                        'task'    => $this->ticket->task,
                        'description'    => $this->ticket->description,
                        'addedBy'  => $addedBy,
                    ]);
        
        /* return $this->markdown('emails.registration',[
                        'userName' => $this->user->full_name,
                        'email' => $this->user->email,
                        'password' => $password,
                        'siteName' => $sitename,
                        'userRole' => $this->user->user_role_id,
                    ]); */
    }
}