<?php 

namespace App\Http\Controllers; 

use App\Http\Controllers\Controller; 
use Illuminate\Http\Request;  
use View,Session,DB,Auth,Validator,Response;

use App\Models\User;
use App\Models\UserMeta;

//for V mail function
use App\Mail\Registration;
use Mail;  


class ClientController extends Controller 
{ 
    public $modalClass;
    public $viewPath;

    public function __construct()
    {
        $this->modalClass   =   "client";
        $this->viewPath     =   "client";

        View::share('viewPath', $this->viewPath);
    }
    
    public function index(Request $request)
    { 
        //$this->authorize('show-store', User::class);

        /* $DB     =   User::query();
        $data   =   $request->all();
        if(!empty($data)){
            foreach($data as $field => $value){
                if($value != ""){
                    $DB->where($field,'like','%'.$value.'%');
                }
            }
        }
        $result = $DB->where('user_role',2)->paginate(15); */

        $users=db::table('users')
        ->where('users.user_role_id', 2)
        ->where('users.deleted_at', null)
        ->get();
        //return view('dashboard.index',compact('users'));  
        return view($this->viewPath.'.index',compact('users'));
    }



    public function show($id)
    { 
    	// $this->authorize('show-store', User::class);

    	$users = User::find($id);

    	if(!$users){
        	$this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route('admin.store.index');
        }  

        return view($this->viewPath.'.show',compact('users'));
    }

    public function create()
    {
        // $this->authorize('create-user', User::class);

        return view($this->viewPath.'.create');
    }

    public function store(Request $request)
    {
        $data   =   $request->all();
        Validator::extend('mobile_valid', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^(\+61\d{0,9})|(\d{0,9})$/', $value); //regex:/^(\+61\d{0,9})|(\d{0,9})$/
        });
        $validator = Validator::make($data, [
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'mobile' => "required|mobile_valid|unique:users,mobile",
            'mobile_1' => "sometimes|mobile_valid",
            'email' => "required|string|email|max:255|unique:users,email",
            'industry_id' => 'required',
            'password' => 'required|string|min:6',
            'confirm_password' => 'required|same:password',
            'avtar' => 'sometimes|image|max:2048',
            'bio' => 'sometimes|max:500',
        ],[
            'mobile.mobile_valid' =>  'Enter a valid mobile number',
            'mobile_1.mobile_valid' =>  'Enter a valid alternate mobile number',
            'industry_id.required' =>  'Select a industry type',
            'avtar.max' =>  'Avtar can not be more then 2mb',
        ]);

        if ($validator->fails()) {
			return Response::json(array(
                'success' => false,
                'errors' => $validator->getMessageBag()->toArray()
            ));
            //return redirect()->back()->withInput($request->all())->withErrors($validator->errors());
		} else {
            
            $request->merge(['password' => bcrypt($request->password)]);
            
            $data   =   $request->all();
            $data['user_role_id']   =   2;
            if(!isset($request->status)){
                $data['status']   =   0;
            }
            if($request->file('avtar')){
                $fileName = $request->file('avtar')->store(USER_IMAGE_ROOT_PATH);
                $data['avtar']   =   $fileName;
            }
            $data['full_name'] = $request->get('first_name')." ".$request->get('last_name');

            $user = User::create($data);
            
            $metaData['user_id']        =   $user->id;
            $metaData['industry_id']    =   $request->industry_id;
            $metaData['bio']            =   $request->bio;
            $user->meta()->create($metaData);

            Mail::to($request->email)->send(new Registration($user));
            Session::flash('success', 'Client added successfully.');
            return Response::json(array('success' => true, 'message'=>'Client added successfully.'));
        }
    }

    public function edit($id=null)
    { 
    	// $this->authorize('edit-user', User::class);

    	$result = User::with('meta')->find($id);
        //pr($result);exit();

    	if(!$result){
        	$this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index');
        }  

        return view($this->viewPath.'.edit',compact('result'));
    }

    public function update(Request $request, $id)
    {
        $result = User::find($id);
        //echo "<pre>"; print_r($result); exit;
        if($request->file('avtar')){
            $fileName = $request->file('avtar')->store(USER_IMAGE_ROOT_PATH);
            $result['avtar']   =   $fileName;
        }
        $result->first_name = $request->first_name;
        $result->last_name = $request->last_name;
        $result->mobile = $request->mobile;
        $result->email = $request->email;
        $result->save(); 
        //pr($result);die();     
        $result2 = UserMeta::find($id);
        //echo ($id); exit;
        $result2 = UserMeta::where('user_id',$id)->first();
        $result2->bio = $request->input('bio');
        $result2->industry_id = $request->input('industry_id');
        $result2->update(); 
        // DB::table('user_metas')->where('id',$userId)->update($result);

        return redirect()->route($this->viewPath.'.index')->with('success','User has been updated successfully');
    }

    public function updatePassword(Request $request,$id)
    {
    	// $this->authorize('edit-user', User::class);

    	// $result = User::find($id);
     //    if(!$result){
     //    	$this->flashMessage('warning', 'Store not found!', 'danger');            
     //        return redirect()->route($this->viewPath.'.index');
     //    }
     //    $request->merge(['password' => bcrypt($request->get('password'))]);\
     //    $result->update($request->all());
     //    $this->flashMessage('check', 'Store password updated successfully!', 'success');
        return redirect()->route($this->viewPath.'.index');
    }


    public function editPassword($id)
    { 
    	// $this->authorize('edit-user', User::class);

    	$result = User::find($id);
    	if(!$result){
        	$this->flashMessage('warning', 'Store not found!', 'danger');            
            return redirect()->route($this->viewPath.'.index');
        }              	               
        return view($this->viewPath.'.edit_password',compact('result'));
    }



    public function destroy($id)
    {
        // $this->authorize('destroy-user', User::class);

        $result = User::find($id);
        if(!$result){
            $this->flashMessage('warning', 'Data Not Deleted');            
            return redirect()->route($this->viewPath.'.index');
        }
        $result->delete();
        $this->flashMessage('check', 'Store successfully deleted!', 'success');
        return redirect()->route($this->viewPath.'.index');
    }
}