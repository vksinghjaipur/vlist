@extends('frontend.layouts.app')

@section('title', app_name())
@section('meta_description', '')
@section('meta_keyword',"FAQs")

@section('content')

<div class="inner-section">
  	<div class="league-bg news-blog">
  	 	<div class="container">
  	 	    <h2>The News<span class="border-line"></span></h2>
           
            <div class="row">
                <div class="col-md-12">
                    <div class="google-add-top">
                      {{-- <img src="img/add-ggogle.PNG"> --}}
                      @php
                      $googleads_header= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'news-page-ads-header-horizontal')->get();
                        //echo '<pre>'; print_r($googleads);die();
                      @endphp
                      @foreach ($googleads_header as $adshere)
                        <?php echo '<center>'.$adshere->adsensecode.'</center>';  ?>       
                      @endforeach
                    </div>
                </div> 
            </div>

            <a class="news-link" href="{{ url('/news')}}">
            <span class="news-link">News,</span> <span class="news-link">Football News</span>
            </a>
            
  	 	    <div class="row">
                <div class="col-md-8">
                    @foreach($newsblogs as $news)   
        	 	   	 	<div class="league-box league-detail-box">
        	 	   	 	    <div class="player-img">

                                <?php
                                    $info = pathinfo(public_path().'/img/news_blog/'.$news->featured_image);
                                    $ext = $info['extension'];
                                ?>    
                                @if($ext=='mp4')
                                <a href="{{ url('/news-blogs/'.$news->id)}}">
                                    <iframe id="video1" width="750" height="280" src="{{ asset('/img/news_blog/'.$news->featured_image) }}" frameborder="0" allowtransparency="true" allowfullscreen>
                                    </iframe>
                                </a>
        	 	   	 	   	    @else
                                    <img src="{{ asset('/img/news_blog/'.$news->featured_image) }}"><br>
                                @endif
                            </div>
        	 	   	 	    
                            <div class="player-info">
        	 	   	 	   	    {{--<h5>August 4, 2021</h5>--}}
                                <h5>{{ date('j F Y', strtotime($news->publish_datetime)) }}</h5>
                                <h3>{{ $news->name }}</h3>
        	 	   	 	   	    <p>{!! $news->content !!}</p>
                                
        	 	   	 	    </div>

                             <div class="socal-icon-bt">
                          <div class="row mt-2 ml-2">
                            <span class="font-weight-bold">Share it:</span>
                            <span>{!! $shareComponent !!}</span>
                          </div>
                        </div>
        	 	   	 	</div>
                    @endforeach    
                </div>
      	 	   	<div class="col-md-4">

                    <div class="recent-blog">
                        <h3>Recent Posts</h3>
                        @foreach($newsblog as $news)      
                            <ul>
                                <li>
                                    <div class="recent-blog-img">
                                    <?php
                                        $info = pathinfo(public_path().'/img/news_blog/'.$news->featured_image);
                                        $ext = $info['extension'];
                                    ?>    
                                    @if($ext=='mp4')
                                        <iframe id="video1" width="100" height="50" src="{{ asset('/img/news_blog/'.$news->featured_image) }}" frameborder="0" allowtransparency="true">
                                        </iframe>
                                    
                                    @else
                                        <img src="{{ asset('/img/news_blog/'.$news->featured_image) }}">
                                    @endif
                                        
                                    </div>
                                    <div class="recent-blog-detail">
                                        <span>{{ date('j F Y', strtotime($news->publish_datetime)) }}</span>
                                        <a href="{{ url('/news-blogs/'.$news->id)}}">
                                            <h4>{!! Str::limit($news->name,30) !!}</h4>
                                            <p>{!! Str::limit($news->content,40) !!}</p>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        @endforeach        
                    </div>     
      	 	   		
                    <br><br>
                    <div class="news-video">
                        <div class="col-md-4">
                            <div class="news-video v-video">
                                @php
                                   $googleads= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'news-page-ads-sidebar-vertical')->get();
                                  //echo '<pre>'; print_r($googleads);die();
                                @endphp
                                @foreach ($googleads as $adshere)
                                  <?php echo '<center>'.$adshere->adsensecode.'</center>'; ?>   
                                @endforeach
                            </div>
                        </div> 
                    </div>                    
      	 	   	</div>

  	 	   </div>
  	 	</div>
  	</div>
  	<div class="add-here">
  	 	<div class="container">
  	 	   <div class="add-img">
  	 	   	  @php
                $googleads_footer= App\Models\Googlead::where('status','1')->orderBy('id')->where('title', 'news-page-ads-footer-horizontal')->get();
              //echo '<pre>'; print_r($googleads);die();
              @endphp
              @foreach ($googleads_footer as $adshere)
                <?php echo '<center>'.$adshere->adsensecode.'</center>'; ?>   
              @endforeach
  	 	   </div>
  	 	</div>
  	</div>
</div>


<script>
 $(document).ready(function() { 
    $('.faq_question').click(function() { 
        if ($(this).parent().is('.open')){
            $(this).closest('.faq').find('.faq_answer_container').animate({'height':'0'},500);
            $(this).closest('.faq').removeClass('open');
 
        }else{
            var newHeight =$(this).closest('.faq').find('.faq_answer').height() +'px';
            $(this).closest('.faq').find('.faq_answer_container').animate({'height':newHeight},500);
            $(this).closest('.faq').addClass('open');
        }
    });
});
</script>

<script> 
var myVideo = document.getElementById("myVid");
function playVideo() { 
 myVideo.play(); 
} 
function pauseVideo() { 
 myVideo.pause(); 
} 
</script>

<script type="text/javascript">
function playPause() {
    var video = document.getElementById("myVid");
    if (video.paused)
    video.play(); 
    else 
    video.pause();
}
</script> 

@endsection