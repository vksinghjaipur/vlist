<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Testimonial;
use App\Property;
use App\Newsletter;
use App\Service;
use App\Slider;
use App\Post;
use DB;
use Toastr;
use Carbon\Carbon;
use Auth;
class FrontpageController extends Controller
{
    
    public function index()
    {       

        $sliders        = Slider::latest()->get();
        $properties     = Property::latest()->where('featured',1)->with('rating')->withCount('comments')->take(8)->get();
        $services       = Service::orderBy('service_order')->get();
        $testimonials   = Testimonial::latest()->get();
        $posts          = Post::latest()->where('status',1)->take(6)->get();

        return view('frontend.index', compact('sliders','properties','services','testimonials','posts'));
    }


    public function search(Request $request)
    {   


      
        $con = "`is_active` = 'Yes'";
        //echo $request->purpose;
       // echo "<pre>"; print_r($request->all()); 
        #Price Condition Start
        $minprice = $request->minprice;
        $maxprice = $request->maxprice;
        if(!empty($minprice)) {           
            $con.= (" AND price >=".$minprice);
            if(!empty($maxprice)) {
                $con.= (" AND price <=".$maxprice);
            }
        }
        if(empty($minprice) && !empty($maxprice)) {
            $con.= (" AND price <=".$maxprice);
        }
        #Price Condition End


        #Floar Area Condition Start
        $minarea = $request->minarea;
        $maxarea = $request->maxarea;
        if(!empty($minarea)) {           
            $con.= (' AND area >='.$minarea);
            if(!empty($maxarea)) {

                $con.= (' AND area <='.$maxarea);
            }
        }
        if(empty($minarea) && !empty($maxarea)) {
       
            $con.= (' AND area <='.$maxarea);
        }
        #Floar Area Condition End


        $type1  = $request->type;
        if(!empty($type1)) {
            $con.= (" AND `type` ='".$type1."'");
        }
        
        $purpose  = $request->purpose;
        if(!empty($purpose)) {
            $con.= (" AND `purpose` ='".$purpose."'");
        }

        $bedroom  = $request->bedroom;
        if(!empty($bedroom)) {
            $con.= ("AND bedroom =".$bedroom);
        }

        $bathroom = $request->bathroom;
        if(!empty($bathroom)) {
            $con.= (" AND bathroom =".$bathroom);
        }

        $featured = $request->featured;
        if (!empty($featured)) {
            $con.= (" AND featured = 1");
        }


        //echo  $con; exit;

        $query = Property::whereRaw($con);
        $city = $request->city;
        $search_cities = array();
        if(!empty($city))
        {
            $search_cities = DB::table('cities')
                ->where('name', 'like', $city.'%')
                ->pluck('id')->toArray();
            if(!empty($search_cities))
            {
                $query->whereIn('city_id',$search_cities);
            }
            $search_countries = DB::table('countries')
                ->where('name', 'like', $city.'%')
                ->pluck('id')->toArray();
            if(!empty($search_countries))
            {
                $query->whereIn('city_id',$search_countries);
            }
            $search_states = DB::table('states')
                ->where('name', 'like', $city.'%')
                ->pluck('id')->toArray();
            if(!empty($search_states))
            {
                $query->whereIn('city_id',$search_states);
            }
            if(empty($search_cities) && empty($search_countries) && empty($search_states))
            {  // die('aasdasd');
                $query->where('zipcode','like', $city.'%');                
            }
        }

       
         $properties = $query->paginate(10); 
        //  echo "<pre>"; print_r($properties); exit;

       
        /*$zipcode  = $request->zipcode;
        $type     = $request->type;
        $purpose  = $request->purpose;
        $bedroom  = $request->bedroom;
        $bathroom = $request->bathroom;
        $minprice = $request->minprice;
        $maxprice = $request->maxprice;
        $minarea  = $request->minarea;
        $maxarea  = $request->maxarea;
        $featured = $request->featured;


         $properties = Property::latest()->withCount('comments')
                                ->when($city, function ($query, $city) {
                                    return $query->whereIn('city_id', $city_ids);              
                                })
                                ->when($city, function ($query, $city) {
                                    return $query->whereIn('state_id', $state_ids);              
                                })
                                 ->when($city, function ($query, $city) {
                                    return $query->whereIn('country_id', $country_ids);              
                                })
                                ->when($type, function ($query, $type) {
                                    return $query->where('type', '=', $type);
                                })
                                ->when($purpose, function ($query, $purpose) {
                                    return $query->where('purpose', '=', $purpose);
                                })
                                ->when($bedroom, function ($query, $bedroom) {
                                    return $query->where('bedroom', '=', $bedroom);
                                })
                                ->when($bathroom, function ($query, $bathroom) {
                                    return $query->where('bathroom', '=', $bathroom);
                                })
                                ->when($minprice, function ($query, $minprice) {
                                    return $query->where('price', '>=', $minprice);
                                })
                                ->when($maxprice, function ($query, $maxprice) {
                                    return $query->where('price', '<=', $maxprice);
                                })
                                ->when($minarea, function ($query, $minarea) {
                                    return $query->where('area', '>=', $minarea);
                                })
                                ->when($maxarea, function ($query, $maxarea) {
                                    return $query->where('area', '<=', $maxarea);
                                })
                                ->when($featured, function ($query, $featured) {
                                    return $query->where('featured', '=', 1);
                                })
                                ->paginate(10); 
*/



         // $properties = Property::latest()->withCount('comments')
         //                ->when($city, function ($query, $city) {
         //                    return $query->where('city', 'like', $city.'%');
         //                })                   
         //                ->when($type, function ($query, $type) {
         //                    return $query->where('type', '=', $type);
         //                })
         //                ->when($purpose, function ($query, $purpose) {
         //                    return $query->where('purpose', '=', $purpose);
         //                })
         //                ->when($bedroom, function ($query, $bedroom) {
         //                    return $query->where('bedroom', '=', $bedroom);
         //                })
         //                ->when($bathroom, function ($query, $bathroom) {
         //                    return $query->where('bathroom', '=', $bathroom);
         //                })
         //                ->when($minprice, function ($query, $minprice) {
         //                    return $query->where('price', '>=', $minprice);
         //                })
         //                ->when($maxprice, function ($query, $maxprice) {
         //                    return $query->where('price', '<=', $maxprice);
         //                })
         //                ->when($minarea, function ($query, $minarea) {
         //                    return $query->where('area', '>=', $minarea);
         //                })
         //                ->when($maxarea, function ($query, $maxarea) {
         //                    return $query->where('area', '<=', $maxarea);
         //                })
         //                ->when($featured, function ($query, $featured) {
         //                    return $query->where('featured', '=', 1);
         //                })
         //                ->paginate(10); 

      

                        // echo "<pre>";
                        // print_r($properties);
                        // die('hereer');
        return view('pages.search', compact('properties'));
    }

    public function newsLetter(Request $request) {  

        $request->validate([
            'email'     => 'max:255',           
        ]);
       
        DB::table('news_letters')->insert(
            ['email' => $request->email, 'created_at' =>  Carbon::now()]
        );        

        Toastr::success('message', 'News Letters Subscribed successfully.');
        return back();   

    }
    

    public function paypalSuccessResponse(Request $request) {
            
        //echo "<pre>"; print_r($request->all()); die;
        if($request->input('st') == 'Completed') 
        {   
            $start_date = date("Y-m-d");
            $end_date = date('Y-m-d',strtotime('+30 days',strtotime($start_date))) . PHP_EOL;

            $inser_arr['user_id'] =  Auth::id();
            $inser_arr['plan_type'] =  $request->input('item_name');
            $inser_arr['listing_per_month'] =  $request->input('item_number');
            $inser_arr['payment_status'] =  $request->input('st');
            $inser_arr['plan_status'] = 1;
            $inser_arr['start_date'] =  $start_date;
            $inser_arr['end_date'] =  $end_date;
            $inser_arr['currency_code'] =  $request->input('cc');
            $inser_arr['transaction_id'] =  $request->input('tx');
            $inser_arr['created_at'] =  Carbon::now();

            $insert_id = DB::table('paypal_transaction')->insertGetId($inser_arr);

            if($insert_id) {
                return redirect()->route('agent.properties.create');   
            } else {
                return redirect()->route('agent.properties.index');
            }

        } else {
            return redirect()->route('agent.properties.index');
        }
       
    }


    public function paypalCancelResponse() {
      
        return redirect()->route('agent.properties.index');
       
    }

    public function getAllTransactions() 
    {
       $data = DB::table('paypal_transaction')->get();
       echo "<pre>"; print_r($data); die('All transactions');
    }

    public function removeTransaction($id) {
        DB::table('paypal_transaction')->where('id',$id)->delete();
    }





}
