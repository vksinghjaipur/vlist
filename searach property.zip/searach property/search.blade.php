@extends('frontend.layouts.app')

@section('styles')

@endsection

@section('content')

<style type="text/css">
    .sidebar-search .searchbar input {
    margin: 0;
}
</style>
    <section class="inner-section">
        <div class="container">
            <div class="row">
                <div class="search-property">
                <div class="col s12 m4 card ">
                    <h2 class="sidebar-title">search property </h2>
                    <form class="sidebar-search" action="{{ route('search')}}" method="GET">

                        <div class="searchbar">
                            <div class="input-field col s12">
                                <input type="text" name="city" id="autocomplete-input-sidebar" class=" custominputbox" value="<?php if(isset($_GET['city']) && !empty($_GET['city']) ) { echo $_GET['city']; } ?>" >
                                <label for="autocomplete-input-sidebar">Enter City or Province</label>
                            </div>
    
                            <div class="input-field col s12">
                                <select name="type" class="browser-default">
                                    <option value="" disabled selected>Choose Type</option>
                                    <option value="apartment" <?php if(isset($_GET['type']) && $_GET['type'] == 'apartment') { ?> selected  <?php } ?> >Apartment</option>
                                    <option value="house" <?php if( isset($_GET['type']) && $_GET['type'] == 'house') { ?> selected  <?php } ?>>House</option>
                                    <option value="acreage_lots" <?php if(isset($_GET['type']) && $_GET['type'] == 'acreage_lots') { ?> selected  <?php } ?> >ACREAGE/LOTS</option>
                                    <option value="condo_townhouse" <?php if(isset($_GET['type']) && $_GET['type'] == 'condo_townhouse') { ?> selected  <?php } ?> >CONDO/TOWNHOUSE</option>
                                    <option value="house_and_acreage" <?php if(isset($_GET['type']) && $_GET['type'] == 'house_and_acreage') { ?> selected  <?php } ?> >HOUSE AND ACREAGE</option>
                                    <option value="farm_ranch" <?php if(isset($_GET['type']) && $_GET['type'] == 'farm_ranch') { ?> selected  <?php } ?> >FARM/RANCH</option>
                                    <option value="commercial_industrial" <?php if(isset($_GET['type']) && $_GET['type'] == 'commercial_industrial') { ?> selected  <?php } ?> >COMMERCIAL/INDUSTRIAL</option>
                                    <option value="multi-family" <?php if(isset($_GET['type']) && $_GET['type'] == 'multi-family') { ?> selected  <?php } ?> >MULTI-FAMILY</option>
                                    <option value="rent_lease" <?php if(isset($_GET['type']) && $_GET['type'] == 'rent_lease') { ?> selected  <?php } ?> >RENT/LEASE</option>
                                </select>
                            </div>
    
                            <?php /*<div class="input-field col s12">
                                <select name="purpose" class="browser-default">
                                    <option value="" disabled selected>Choose Purpose</option>
                            <option value="rent" <?php if(isset($_GET['purpose']) && $_GET['purpose'] == 'rent' ) { ?> selected  <?php } ?> >Rent</option>
                                <option value="sale" <?php if(isset($_GET['purpose']) &&  $_GET['purpose'] == 'sale')  { ?> selected  <?php } ?> >Sale</option>
                                </select>
                            </div> */ ?>
    
                            <div class="input-field col s12">
                                <select name="bedroom" class="browser-default">
                                    <option value="" disabled selected>Choose Bedroom</option>
                                    @foreach($bedroomdistinct as $bedroom)
                                        <option value="{{$bedroom->bedroom}}" <?php if(isset($_GET['bedroom']) && $_GET['bedroom'] == $bedroom->bedroom ) { ?>   selected  <?php } ?> >{{$bedroom->bedroom}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="input-field col s12">
                                <select name="bathroom" class="browser-default">
                                    <option value="" disabled selected>Choose Bathroom</option>
                                    @foreach($bathroomdistinct as $bathroom)
                                        <option value="{{$bathroom->bathroom}}"  <?php if(isset($_GET['bathroom']) && $_GET['bathroom'] == $bathroom->bathroom ) { ?>  selected  <?php } ?> >{{$bathroom->bathroom}}</option>
                                    @endforeach
                                </select>
                            </div>
    
                            <div class="input-field col s12">
                                <input type="number" name="minprice" id="minprice" value="<?php if(isset($_GET['minprice']) && !empty($_GET['minprice']) ) { echo $_GET['minprice']; } ?>" class="custominputbox" min="1">
                                <label for="minprice">Min Price</label>
                            </div>
    
                            <div class="input-field col s12">
                                <input type="number" name="maxprice" id="maxprice" value="<?php if(isset($_GET['maxprice']) && !empty($_GET['maxprice']) ) { echo $_GET['maxprice']; } ?>" class="custominputbox" min="1">
                                <label for="maxprice">Max Price</label>
                            </div>
    
                            <div class="input-field col s12">
                                <input type="number" name="minarea" value="<?php if(isset($_GET['minarea']) && !empty($_GET['minarea']) ) { echo $_GET['minarea']; } ?>" id="minarea" class="custominputbox" min="1">
                                <label for="minarea">Floor Min Area</label>
                            </div>
    
                            <div class="input-field col s12">
                                <input type="number" name="maxarea" value="<?php if(isset($_GET['maxarea']) && !empty($_GET['maxarea']) ) { echo $_GET['maxarea']; } ?>" id="maxarea" class="custominputbox" min="1">
                                <label for="maxarea">Floor Max Area</label>
                            </div>
                            
                            <div class="input-field col s12">
                                <div class="switch">
                                    <label>
                                        <input type="checkbox" <?php if(isset($_GET['featured'])) { ?> checked <?php } ?> name="featured">
                                        <span class="lever"></span>
                                        Featured
                                    </label>
                                </div>
                            </div>
                            <div class="input-field col s12">
                                <button class="btn btnsearch indigo" type="submit">
                                    <i class="material-icons">search</i> SEARCH
                                </button>
                            </div>
                        </div>
    
                    </form>

                </div>

                <div class="col s12 m8">
                    @if(isset($properties) && !empty($properties))
                    @foreach($properties as $property)
                        <div class="card horizontal">
                            <div>
                                <div class="card-content property-content">
                                    @if(!empty($property->image) && file_exists(public_path('/img/property/'.$property->image)))
                                        <div class="card-image blog-content-image">
                                            <img src="{{asset('img/property/'.$property->image)}}" alt="{{$property->title}}">
                                        </div>
                                    @endif
                                    <span class="card-title search-title" title="{{$property->title}}">
                                        <a href="{{ route('property.show',$property->slug) }}">{{ $property->title }}</a>
                                    </span>
                                    
                                    <div class="address">
                                        <i class="small material-icons left">location_city</i>
                                        <span>{{ ucfirst($property->city) }}</span>
                                    </div>
                                    <div class="address">
                                        <i class="small material-icons left">place</i>
                                        <span>{{ ucfirst($property->address) }}</span>
                                    </div>

                                    <h5>
                                        &dollar;{{ $property->price }}
                                        <small class="right">{{ $property->type }} for {{ $property->purpose }}</small>
                                    </h5>

                                </div>
                                <div class="card-action property-action clearfix">
                                    <span class="btn-flat">
                                        <i class="material-icons">check_box</i>
                                        Bedroom: <strong>{{ $property->bedroom}}</strong> 
                                    </span>
                                    <span class="btn-flat">
                                        <i class="material-icons">check_box</i>
                                        Bathroom: <strong>{{ $property->bathroom}}</strong> 
                                    </span>
                                    <span class="btn-flat">
                                        <i class="material-icons">check_box</i>
                                        Area: <strong>{{ $property->area}}</strong> Sq Ft
                                    </span>
                                    <span class="btn-flat">
                                        <i class="material-icons">comment</i>
                                        {{ $property->comments_count}}
                                    </span>

                                    @if($property->featured == 1)
                                        <span class="right featured-stars">
                                            <i class="material-icons">stars</i>
                                        </span>
                                    @endif                                    

                                </div>
                            </div>
                        </div>
                    @endforeach
                    @else
                    <div>No Record Matches</div>
                    @endif


                    <div class="m-t-30 m-b-60 center">
                        {{ 
                            $properties->appends([
                                'city'      => Request::get('city'),
                                'type'      => Request::get('type'),
                                'purpose'   => Request::get('purpose'),
                                'bedroom'   => Request::get('bedroom'),
                                'bathroom'  => Request::get('bathroom'),
                                'minprice'  => Request::get('minprice'),
                                'maxprice'  => Request::get('maxprice'),
                                'minarea'   => Request::get('minarea'),
                                'maxarea'   => Request::get('maxarea'),
                                'featured'  => Request::get('featured')
                            ])->links() 
                        }}
                    </div>
        
                </div>
            </div>

            </div>
        </div>
    </section>

@endsection

@section('scripts')

@endsection