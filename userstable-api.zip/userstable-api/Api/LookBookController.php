<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Lookbook;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Models\Product\AddCart;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsConfirmation;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class LookBookController extends APIController
{
    public function lookBookCreate(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'seller_id'=>'required',
                'staff_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $checkproduct= DB::table('business_infos')->where('user_id',$request->seller_id)->first();
            $business['business_name']=$checkproduct->business_name??'';
            
            $sellerStaff= DB::table('staff_members')->where('staff_id',$request->staff_id)->first();
            $business['staff_name']=$sellerStaff->name??'';
            $business['staff_id']=$sellerStaff->staff_id??'';
            
             //Business Type
            $categorys=DB::table('business_types')->where('status',1)->get();
            $businessCat=array();
            foreach($categorys as $c=>$category)
            {
                $businessCat[$c]['id']=$category->id;
                $businessCat[$c]['category_name']=$category->business_name;
            }

            $resultArray['status']='1';
            $resultArray['message']='Lookbook Create form';
            $resultArray['data']=$business;
            $resultArray['category']=$businessCat;
            return response()->json($resultArray); exit ;
    }

    public function getSubServices(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $catgory= isset($request->category_id)?$request->category_id:'';
        $validator = Validator::make($request->all(), [
                'category_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $getsubcat=DB::table('business_services')->where('business_id',$catgory)->get();
            $subServices=array();
            foreach($getsubcat as $cat=>$subcat)
            {   
                $subServices[$cat]['sub_cat_id']=$subcat->id;
                $subServices[$cat]['category_name']=$subcat->service_name;
            }

            $serviceLength[0]['name']='middle';
            $serviceLength[1]['name']='small';
            $serviceLength[2]['name']='large';
            $serviceType[0]['name']='male';
            $serviceType[1]['name']='female';

            $resultArray['status']='1';
            $resultArray['message']='Lookbook sub services';
            $resultArray['data']=$subServices;
            $resultArray['length']=$serviceLength;
            $resultArray['service_type']=$serviceType;
            return response()->json($resultArray); exit ;
    }

    public function storeLookbook(Request $request)
    {  
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $catgory= isset($request->category_id)?$request->category_id:'';
        $validator = Validator::make($request->all(), [
                'seller_id'=>'required',
                'staff_id'=>'required',
                'category_id'=>'required',
                'sub_cat_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

                $addlookBook=new Lookbook;

                if($request->hasFile('look_book_image'))
                {
                    $images = $request->file('look_book_image');
                    $name = rand(1111,9999).'.'.$images->getClientOriginalExtension();
                    $destinationPath = public_path('/img/lookbook/');
                    $images->move($destinationPath, $name);
                    $addlookBook->look_book_image=$name;
                }
                $addlookBook->seller_id=$request->seller_id;
                $addlookBook->staff_id=$request->staff_id;
                $addlookBook->category_id=$request->category_id;
                $addlookBook->sub_cat_id=$request->sub_cat_id;
                $addlookBook->description=$request->description;
                $addlookBook->service_type=$request->service_type;
                $addlookBook->service_length=$request->service_length;
                $addlookBook->tag=$request->tag;
                $addlookBook->save();
                
                $resultArray['status']='1';
                $resultArray['message']=trans('api.messages.look_book_add');
                return response()->json($resultArray); exit; 
    }

    public function getSellerLookBook(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
            'seller_id'=> 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']= trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
        $getlookbooks=DB::table('look_books')->where('seller_id',$request->seller_id)->get();
        $lookbooksArray=array();
        foreach($getlookbooks as $l=>$lookbook)
        {
            $lookbooksArray[$l]['look_book_id']=$lookbook->id;  
            $lookbooksArray[$l]['seller_id']=$lookbook->seller_id;  
            $lookbooksArray[$l]['staff_id']=$lookbook->staff_id;  
            $lookbooksArray[$l]['image']=url('img/lookbook/'.$lookbook->look_book_image);  
        }
            $resultArray['status']='1';
            $resultArray['message']=trans('api.messages.look_book_get');
            $resultArray['data']=$lookbooksArray;
            return response()->json($resultArray); exit;
    }

    public function getSellerLookBookDetail(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
            'look_book_id'=> 'required',
           // 'seller_id'=> 'required',
            //'staff_id'=> 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']= trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $getlookbooks=DB::table('look_books')
                        ->join('staff_members','staff_members.staff_id','=','look_books.staff_id')
                        ->select('look_books.*','staff_members.name','staff_members.staff_image','staff_members.staff_id')
                        ->where('look_books.id',$request->look_book_id)->first();
        if(!empty($getlookbooks))
        {   
            $lookbooksArray['staff_name']=$getlookbooks->name; 
            if(!empty($getlookbooks->staff_image))
            {
                $lookbooksArray['staff_image']=url('img/staff/'.$getlookbooks->staff_image);  
            }
            $lookbooksArray['look_book_id']=$getlookbooks->id;  
            $lookbooksArray['seller_id']=$getlookbooks->seller_id;  
            $lookbooksArray['staff_id']=$getlookbooks->staff_id;  
            $lookbooksArray['image']=url('img/lookbook/'.$getlookbooks->look_book_image);  
            $lookbooksArray['description']=$getlookbooks->description;  
            $lookbooksArray['tag']=explode('#',$getlookbooks->tag);  

            $resultArray['status']='1';
            $resultArray['message']=trans('api.messages.look_book_detail');
            $resultArray['data']=$lookbooksArray;
            return response()->json($resultArray); exit; 
        }
        else
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.messages.look_book_not_found');
            return response()->json($resultArray); exit; 
        }
    }
    

    public function lookBookDetailFilter(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
            'category_id'=> 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']= trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $filterQuery= DB::table('look_books')
                    ->leftJoin('business_address','business_address.user_id','=','look_books.seller_id')
                    ->where('look_books.category_id',$request->category_id);
        if(isset($_REQUEST['service_type']) && !empty($_REQUEST['service_type']))
        {
            $filterQuery->where('look_books.service_type',$request->service_type);
        }
        if(isset($_REQUEST['service_length']) && !empty($_REQUEST['service_length']))
        {
            $filterQuery->where('look_books.service_length',$request->service_length);
        }
        if(isset($_REQUEST['area']) && !empty($_REQUEST['area']))
        {
            $filterQuery->where('business_address.business_address',$request->area);
        }
        
        $filterData=$filterQuery->select('look_books.*','business_address.business_address')->get();

            $lookbookfilterData=array();
            $sellerArea=array();
            $sellerArea1=array();

            foreach($filterData as $k=>$filter)
            {
                if(!in_array($filter->business_address, $sellerArea))
                {
                    if(!empty($filter->business_address))
                    {
                        $arealocation['areaname']=$filter->business_address;
                        array_push($sellerArea,$filter->business_address);
                        array_push($sellerArea1,$arealocation);
                    }
                }
                $lookbookfilterData[$k]['look_book_id']=$filter->id;
                $lookbookfilterData[$k]['seller_id']=$filter->seller_id;
                $lookbookfilterData[$k]['staff_id']=$filter->staff_id;
                $lookbookfilterData[$k]['image']=url('img/lookbook/'.$filter->look_book_image);  
            }

            //Business Type
            $categorys=DB::table('business_types')->where('status',1)->get();
            $businessCat=array();
            foreach($categorys as $c=>$category)
            {
                $businessCat[$c]['id']=$category->id;
                $businessCat[$c]['category_name']=$category->business_name;
            }

            $resultArray['status']='1';
            $resultArray['message']=trans('api.messages.look_book_filter_data');
            $resultArray['category']=$businessCat;
            $resultArray['details']=$lookbookfilterData;
            $resultArray['area']=$sellerArea1;
            return response()->json($resultArray); exit; 
    }

    public function getAddFavourites(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
            'look_book_id'=> 'required',
            'user_id'=> 'required',
        ]);

        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']= trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
        $lookBookId = isset($request->look_book_id) && !empty($request->look_book_id) ? $request->look_book_id: '';
                                   
        $checkfavorite=DB::table('look_book_favorites')->whereRaw("(user_id='".$userId."' AND look_book_id='".$lookBookId."')")->first();
        if(empty($checkfavorite))
        {
            DB::table('look_book_favorites')->insert([
                                    'user_id'=>$userId,
                                    'look_book_id'=>$lookBookId
                                    ]);
            $message='Favorite';
            $isfavorite=true; 
        }else
        {
            DB::table('look_book_favorites')->whereRaw("(user_id='".$userId."' AND look_book_id='".$lookBookId."')")->delete();
            $isfavorite=false;
            $message='Unfavorite';
        }

            $totalfavorite=DB::table('look_book_favorites')->where('look_book_id',$lookBookId)->count();
            $resultArray['status']='1';
            $resultArray['message']=$message;
            $resultArray['is_favorite']=$isfavorite;
            $resultArray['favorite_count']=$totalfavorite;
            return response()->json($resultArray); exit;

    }

}   