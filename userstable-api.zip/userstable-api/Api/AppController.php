<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB,Mail;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Lookbook;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsConfirmation;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class AppController extends APIController
{
    
        public function pages(Request $request)
        {
            $pageType = isset($request->page_type) && !empty($request->page_type) ? $request->page_type : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;

            App::setLocale($lang);

            $validator = Validator::make($request->all(), [
            'page_type' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $pageSlug=DB::table('pages')->where('page_slug',$pageType)->select('title','description')->first();
            if(!empty($pageSlug))
            {
                $dataArray['title']= $pageSlug->title;
                $dataArray['description']= $pageSlug->description;
                $resultArray['status']='1';
                $resultArray['message']=trans('api.page_result_successfully');
                $resultArray['data']=$dataArray;
                echo json_encode($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.data_not_found');
                echo json_encode($resultArray); exit;
            }
        }

        public function addCard(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            'card_holder'=>'required',
            'card_number'=>'required',
            'zip_code'=>'required',
            'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $cardHolder = isset($request->card_holder) && !empty($request->card_holder) ? $request->card_holder : '' ;
            $cardNumber = isset($request->card_number) && !empty($request->card_number) ? $request->card_number : '' ;
            $cardCvv = isset($request->cvv) && !empty($request->cvv) ? $request->cvv : '' ;
            $cardZip = isset($request->zip_code) && !empty($request->zip_code) ? $request->zip_code : '' ;
            $session_key = !empty($request->session_key) ? $request->session_key : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $user_arr = DB::table('users')->whereRaw("(id = '".$userid."' AND deleted_at IS null )")->first();

                if(!empty($user_arr))
                {
                    $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {   
                        $addcard= array(
                                'user_id'=>$userid,
                                'card_holder'=>$cardHolder,
                                'card_number'=>$cardNumber,
                                'cvv'=>$cardCvv,
                                'zip_code'=>$cardZip,
                                );

                       // print_r($addcard);exit;

                        DB::table('add_cards')->insert($addcard);
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.card_add_successfully');
                        echo json_encode($resultArray); exit;
                    }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit;
                }
        }

        public function cardUpdate(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'cardid' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  

            $access_token=123456;
            $userid = isset($request->userid) && !empty($request->userid) ? $request->userid : '' ;
            $cardid = isset($request->cardid) && !empty($request->cardid) ? $request->cardid : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $cvv = $request->cvv;
            $updatecard= array(
                        'card_holder'=>$request->card_holder,
                        'card_number'=>$request->card_number,
                        'zip_code'=>$request->zip_code,
                        );
             if($cvv){
              $updatecard['cvv'] = $cvv;
             }
             DB::table('add_cards')->where('id',$cardid)->update($updatecard);
            $resultArray['status']=1;
            $resultArray['message']=trans('api.card_update_successfully');
            echo json_encode($resultArray); exit;
        }

        public function cardDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'cardid' => 'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $cardid = isset($request->cardid) && !empty($request->cardid) ? $request->cardid : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            DB::table('add_cards')->where('id',$cardid)->where('user_id',$userid)->delete();
                $resultArray['status']='1';
                $resultArray['message']=trans('api.card_delete_successfully');
                echo json_encode($resultArray); exit;
        }

        public function cardList(Request $request)
        {
           $validator = Validator::make($request->all(), [
                'user_id' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

               $cardlists= DB::table('add_cards')->where('user_id',$userid)->get();

                if(count($cardlists)>0)
                {   
                    $cartData=[];
                    foreach ($cardlists as $key => $cardlist)
                    {
                        $cartData[$key]['card_id']=$cardlist->id;
                        $cartData[$key]['card_holder']=$cardlist->card_holder;
                        $cartData[$key]['card_number']=$cardlist->card_number;
                        $cartData[$key]['cvv']=$cardlist->cvv;
                        $cartData[$key]['zip_code']=$cardlist->zip_code;
                    }
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.cart_list');
                    $resultArray['data']= $cartData;
                    echo json_encode($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.data_not_found');
                    echo json_encode($resultArray); exit; 
                }
                   
        }


        public function businessInfo(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $aboutbusiness = isset($request->about) && !empty($request->about) ? $request->about: '';
                $businessName = isset($request->business_name) && !empty($request->business_name) ? $request->business_name: '';
                $officialId = isset($request->official_id) && !empty($request->official_id) ? $request->official_id: '';
                $googleUrl = isset($request->google_url) && !empty($request->google_url) ? $request->google_url: '';
                $instagramUrl = isset($request->instagram_url) && !empty($request->instagram_url) ? $request->instagram_url: '';
                $facebookUrl = isset($request->facebook_url) && !empty($request->facebook_url) ? $request->facebook_url: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

                    $buscertificate='';
                    if(isset($request->certificate) && !empty($request->certificate))
                    { 
                        $images=array();
                        foreach ($request->certificate as $key => $image)
                        {
                           $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                            $destinationPath = public_path('/img/certificate');
                            $image->move($destinationPath, $name);
                            $images[]=$name;
                        } 
                        $buscertificate= implode("|",$images);
                    }
                   
                    $checkInfo=DB::table('business_infos')->where('user_id', $userId)->first();

                    $infodata=array('user_id'=> $userId,'business_name'=>$businessName,'official_id'=>$officialId,'certificate'=>$buscertificate,'facebook_url'=> $facebookUrl,'instagram_url'=>$instagramUrl,'google_url'=>$googleUrl,'about'=>$aboutbusiness);
               
                if(empty($checkInfo))
                {
                    DB::table('business_infos')->insert($infodata);
                }
                else
                {
                    if(!empty($checkInfo->certificate))
                    {
                        $buscertificate=$checkInfo->certificate.'|'.$buscertificate;
                    }
                    $infodata1=array('user_id'=> $userId,'business_name'=>$businessName,'official_id'=>$officialId,'certificate'=>$buscertificate,'facebook_url'=> $facebookUrl,'instagram_url'=>$instagramUrl,'google_url'=>$googleUrl);
                    DB::table('business_infos')->where('user_id',$userId)->update($infodata1);
                }
                $businessDatas = DB::table('business_infos')->where('user_id',$userId)->first();
                $certificates=[];
                if(!empty($businessDatas->certificate)){
                 $certificates =  explode("|",$businessDatas->certificate);
                }
                 
                $business_certi=array();
                if(count($certificates)>0)
                {
                    foreach ($certificates as $key => $certificate)
                    {
                        if(!empty($certificate) && file_exists(public_path('img/certificate/'.$certificate)))
                        {
                            $business_certi2['certificate']=$certificate=url('img/certificate/'.$certificate);
                            array_push($business_certi, $business_certi2);
                         }
                    }
                }
                $business=array();
                $business['business_name']=$businessDatas->business_name;
                $business['official_id']=$businessDatas->official_id;
                $business['certificate']= $business_certi;
                $business['google_url']= isset($businessDatas->google_url)?$businessDatas->google_url:'';
                $business['facebook_url']= isset($businessDatas->facebook_url)?$businessDatas->facebook_url:'';
                $business['instagram_url']= isset($businessDatas->instagram_url)?$businessDatas->instagram_url:'';
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_info');
                $resultArray['business_info']=$business;
                return($resultArray); exit;

            }
        }
        public function businessAddress(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $businessAddress = isset($request->business_address) && !empty($request->business_address) ? $request->business_address: '';
                $apartmentNumber = isset($request->apartment_number) && !empty($request->apartment_number) ? $request->apartment_number: '';
                $city = isset($request->city) && !empty($request->city) ? $request->city: '';
                $zipCode = isset($request->zip_code) && !empty($request->zip_code) ? $request->zip_code: '';
                $businessLat = isset($request->business_lat) && !empty($request->business_lat) ? $request->business_lat: '';
                $businessLong = isset($request->business_long) && !empty($request->business_long) ? $request->business_long: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }
                $infodata=array('user_id'=>$userId,'business_address'=>$businessAddress,'apart_number'=>$apartmentNumber,'city'=>$city,'zip_code'=>$zipCode,'business_lat'=>$businessLat,'business_long'=>$businessLong);
                $checkInfo=DB::table('business_address')->where('user_id', $userId)->first();
                if(empty($checkInfo))
                {
                    DB::table('business_address')->insert($infodata);
                }
                else
                {
                    DB::table('business_address')->where('user_id',$userId)->update($infodata);
                }

               $businessAddressData = DB::table('business_address')->where('user_id',$userId)->first();

               if(!empty($businessAddressData))
               {
                   $businessAddress = array();
                   $businessAddress['id'] = $businessAddressData->id;
                   $businessAddress['user_id'] = $businessAddressData->user_id;
                   $businessAddress['business_address'] = $businessAddressData->business_address;
                   $businessAddress['apart_number'] = $businessAddressData->apart_number;
                   $businessAddress['city'] = $businessAddressData->city;
                   $businessAddress['zip_code'] = $businessAddressData->zip_code;
                   $businessAddress['business_lat'] = $businessAddressData->business_lat;
                   $businessAddress['business_long'] = $businessAddressData->business_long;
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.business_address');
                    $resultArray['business_address']=$businessAddress;
                    return ($resultArray); exit;
                }
            }
        }

        public function businessTravel(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $travelService = isset($request->travel_service) && !empty($request->travel_service) ? $request->travel_service: 0;
                $minTravelFee = isset($request->min_travel_fee) && !empty($request->min_travel_fee) ? $request->min_travel_fee: '';
                $maxTravelDistance = isset($request->max_travel_distance) && !empty($request->max_travel_distance) ? $request->max_travel_distance: '';
                $travelPolicy = isset($request->travel_policy) && !empty($request->travel_policy) ? $request->travel_policy: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
             else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

                $travelinfo=array('user_id'=> $userId,'travel_service'=>$travelService,'min_travel_fee'=>$minTravelFee,'max_travel_distance'=>$maxTravelDistance,'travel_policy'=>$travelPolicy);
                $checkTravel=DB::table('business_travels')->where('user_id', $userId)->first();
                if(empty($checkTravel))
                {
                    DB::table('business_travels')->insert($travelinfo);
                }
                else
                {
                    DB::table('business_travels')->where('user_id',$userId)->update($travelinfo);
                }

                $businesstravel = DB::table('business_travels')->where('user_id',$userId)->first();
                
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_travel');
                $resultArray['business_travels']=$businesstravel;
                echo json_encode($resultArray); exit;

            }
        }

        public function businessHours(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $businessHours = isset($request->business_hours) && !empty($request->business_hours) ? $request->business_hours:'';

                // $startTime = isset($request->start_time) && !empty($request->start_time) ? $request->start_time: '';
                // $endTime = isset($request->end_time) && !empty($request->end_time) ? $request->end_time: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);


            $variable_fields_data = json_decode($businessHours);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
             else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }
               
                $checkHours=DB::table('business_hours')->where('user_id', $userId)->first();
                if(empty($checkHours))
                {   
                    foreach ($variable_fields_data as $key => $value)
                    {
                        $businesshourd['day'] = $value->day;
                        $businesshourd['start_time'] = $value['start_time'];
                        $businesshourd['end_time'] = $value['end_time'];
                        DB::table('business_hours')->insert($businesshourd);
                    }
                }
                else
                {   
                    DB::table('business_hours')->where('user_id',$userId)->delete();
                    foreach ($variable_fields_data as $key => $value)
                    {
                       $businesshourd['day'] = $value['day'];
                       $businesshourd['start_time'] = $value['start_time'];
                       $businesshourd['end_time'] = $value['end_time'];
                      DB::table('business_hours')->insert($businesshourd);
                    }
                }

                $businessHour = DB::table('business_hours')->where('user_id',$userId)->first();
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_travel');
                $resultArray['business_hours']=$businessHour;
                echo json_encode($resultArray); exit;
            }
        }

        public function businessImage(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }
               
                $checkImage=DB::table('business_images')->where('user_id', $userId)->first();
                if(empty($checkImage))
                {   
                    if ($request->hasFile('business_image'))
                    {
                        $image = $request->file('business_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/businessimage');
                        $image->move($destinationPath, $name);
                    }
                    DB::table('business_images')->insert(['user_id'=>$userId,'image'=>$name]);
                              
                }
                else
                {   
                    if (file_exists(public_path('img/businessimage/'.$checkImage->image)) && !empty($checkImage->image))
                    {
                         unlink(public_path('img/businessimage/'.$checkImage->image));
                    }
                    if ($request->hasFile('business_image'))
                    {
                        $image = $request->file('business_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/businessimage');
                        $image->move($destinationPath, $name);
                    }
                     DB::table('business_images')->where('user_id',$userId)->update(['image'=>$name]);
                }

                $businessImage = DB::table('business_images')->where('user_id',$userId)->first();
                
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_travel');
                $resultArray['business_images']=$businessImage;
                echo json_encode($resultArray); exit;
            }
        }

        public function businessType(Request $request)
        {
            $busineestypes=DB::table('business_types')->where('status',1)->where('deleted_at', '=', Null)->get();

            $checkservice=DB::table('seller_business_services')->where('user_id',$request->user_id)->whereRaw("(deleted_at IS null)")->groupBy('business_type_id')->get()->pluck('business_type_id')->toArray();
         
            $business=array();
            foreach ($busineestypes as $key => $businesstype)
            {
               
                $business[$key]['id']=$businesstype->id;
                $business[$key]['business_name']=$businesstype->business_name;
                if(!empty($checkservice) && in_array($businesstype->id,$checkservice))
                {
                  $business[$key]['is_checked']=true;
                }
                else
                {
                     $business[$key]['is_checked']=false;  
                }
            }
                $resultArray['status']=1;
                $resultArray['message']=trans('api.Businesstype list found');
                $resultArray['data']=$business;
                return ($resultArray); die;
        }

        public function sellerBusinessType(Request $request)
        {

            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {
                        $businestyp=DB::table('saller_business_types')->where('user_id',$userId)->first();
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.business_service');
                        $resultArray['data']=isset($businestyp->business_type_id)?$businestyp->business_type_id:'';
                            echo json_encode($resultArray); exit;
                    }
        }

        public function businessServices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'business_type_id'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {
                       $businessType=DB::table('business_types')->where('id',$request->business_type_id)->select('business_name')->first();
                        $services=DB::table('business_services')->where('business_id',$request->business_type_id)->where('status',1)->get();
                        $servicelist=array();
                        foreach ($services as $key => $service)
                        {
                            $servicelist[$key]['id']=$service->id;
                            $servicelist[$key]['service_name']=$service->service_name;
                        }
                            $resultArray['status']='1';
                            $resultArray['message']=trans('api.business_service');
                            $resultArray['businesstype']=$businessType->business_name;
                            $resultArray['data']=$servicelist;
                            echo json_encode($resultArray); exit;
                    }
         }

        public function SellerBusinessServices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {
                        $businessservice=DB::table('seller_business_services')->where('user_id',$userId)->whereRaw("(deleted_at IS null)")->first();
                            $resultArray['status']='1';
                            $resultArray['message']=trans('api.business_service');
                            $resultArray['data']=isset($businessservice->service_type_id)?$businessservice->service_type_id:'';
                            echo json_encode($resultArray); exit;
                    }
        }

        public function bookingType(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $inperson = isset($request->in_person) && !empty($request->in_person) ? $request->in_person: '';
                $athome = isset($request->at_home) && !empty($request->at_home) ? $request->at_home: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $bookingdata= array('user_id'=>$userId,'in_person'=>$inperson,'at_home'=>$athome);

                    $bookingty=DB::table('booking_types')->where('user_id',$userId)->first();
                    if(empty($bookingty))
                    {
                        DB::table('booking_types')->insert($bookingdata);
                    }
                    else
                    {
                        DB::table('booking_types')->where('user_id',$userId)->update($bookingdata);
                    }
                    $bookingType = DB::table('booking_types')->where('user_id',$userId)->first();
                    $resultArray['status']='1';
                    $resultArray['Data']['message']=trans('api.booking_type_update');
                    $resultArray['booking_types']=$bookingType;
                    return ($resultArray); die;
                }
        }

        public function checkToken($access_token,$user_id='',$session_key='',$lang='')
        {
            $token=123456;
            if($access_token!=$token)
            {
                $resultArray['status']='0';
                $resultArray['message']=__('Invalid token!');
                return $resultArray;
                die;
            }
            else
            {
                if($user_id!='')
                {
                    $user_arr = DB::table('users')->where('id',trim($user_id))->where('active',1)->first();
                    if($session_key=='')
                    {
                    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
                    $session_key=substr(str_shuffle($chars),0,8);
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->first();
                    
                    if($checkuser)
                    {
                        $update_arr= array('session_key' => $session_key);
                        DB::table('mobile_session')->where('id',$checkuser->id)->update($update_arr);
                        
                    }
                    else
                    {
                        $mobile['user_id'] = $user_id; 
                        $mobile['session_key'] = $session_key;
                        $savemobile = DB::table('mobile_session')->insert($mobile);
                                       
                    }
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray);
                    }
                    else
                    {
                    
                    $checkuser = DB::table('mobile_session')->where('user_id',trim($user_id))->where('session_key',$session_key)->first();

                    if($checkuser)
                    {
                    $resultArray['status']='1';
                    $resultArray['Data']['randnumber']=$session_key;
                    return ($resultArray); die;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.Invalid session.');
                        return ($resultArray); die;
                    }
                    }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['Data']['message']='';
                    return ($resultArray); die;
                }   
            }
        }
         /*
          * CHECK AUTHENTICATION API END HERE
          */

        public function intToString($data=null,$indent='')
        {
            $userdata= array();
            if ($data) {
                foreach ($data as $key=> $value)
                {
                    if (is_array($value))
                    {
                        $userdata[$key]= $this->intToString($value,$indent);
                    }
                    else
                    {   
                        if(is_numeric($value))
                        {
                            $userdata[$key]=strval($value);
                        }
                        else
                        {
                            $userdata[$key]= $value;
                        }
                    }
                }
            }
                 return $userdata;
                exit;
        }
        public function businessStaticPages(Request $request)
        {
            $pageType = isset($request->page_type) && !empty($request->page_type) ? $request->page_type : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;

            App::setLocale($lang);

            $validator = Validator::make($request->all(), [
            'page_type' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $pageSlug=DB::table('pages')->where('page_slug',$pageType)->select('title','description')->first();
            if(!empty($pageSlug))
            {
                $dataArray['title']= $pageSlug->title;
                $dataArray['description']= $pageSlug->description;
                $resultArray['status']='1';
                $resultArray['message']=trans('api.page_result_successfully');
                $resultArray['data']=$dataArray;
                echo json_encode($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.data_not_found');
                echo json_encode($resultArray); exit;
            }
        }

        public function subscription(Request $required)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $getplanList= DB::table('plans')->where('status',1)->whereRaw('deleted_at','is NULL')->get();
            $plan=array();
            foreach ($getplanList as $key => $value)
            {
               $plan[$key]['id']=$value->id;
               $plan[$key]['name']=$value->name;
               $plan[$key]['price']=$value->price;
            }
            $resultArray['status']=1;
            $resultArray['message']=trans('api.plan_list');
            $resultArray['data']=$plan;
            echo json_encode($resultArray); exit;  
        }
   
        public function userSettingShow(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

                $userData=DB::table('user_settings')->where('user_id',$userId)->first();
                $resultArray['status']='1';
                $resultArray['message']=trans('api.user_setting_list');
                $resultArray['data']=$userData;
                echo json_encode($resultArray); exit; 

            }
        }


        public function selectbusinessType(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'business_type_id'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $businessTypeId = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id: '';

                $business_type_id =  explode(",",$businessTypeId);
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
               
                $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {
                    $check_business = DB::table('saller_business_types')
                            ->where('user_id',$userId)
                            ->get();
                    if(!empty($check_business))
                    {
                       DB::table('saller_business_types')->where('user_id',$userId)
                            ->delete();
                    }

                    foreach ($business_type_id as $key => $value) {
                     $addbusinessType= array(
                            'user_id'=>$userId,
                            'business_type_id'=>$value,
                            );

                    DB::table('saller_business_types')->insert($addbusinessType);
                }
                $businessType=DB::table('saller_business_types')->where('user_id',$userId)->first();
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_type_saved_successfully');
                $resultArray['saller_business_types']=$businessType;
                echo json_encode($resultArray); exit;
              }
        }


        // public function deletebusinessType1(Request $request)
        // {
        //     $validator = Validator::make($request->all(), [
        //         'user_id'=>'required',
        //         'session_key'=>'required',
        //         'business_type_id'=>'required'
        //     ]);

        //     if($validator->fails())
        //     {
        //         $resultArray['status']='0';
        //         $resultArray['message']=trans('api.Invalid parameters.');
        //         echo json_encode($resultArray); exit;      
        //     }

        //     $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
        //     $cardid = isset($request->cardid) && !empty($request->cardid) ? $request->cardid : '' ;
        //     $lang = !empty($request->lang) ? $request->lang : 'en' ;
        //     App::setLocale($lang);

        //     $businessTypeId = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id: '';

        //     $business_type_id =  explode(",",$businessTypeId);

        //     foreach ($business_type_id as $key => $value) {           
        //     DB::table('saller_business_types')->where('business_type_id',$value)->where('user_id',$userid)->delete();
        //     }

        //     $resultArray['status']=1;
        //     $resultArray['message']=trans('api.business_type_delete_successfully');
        //     echo json_encode($resultArray); exit;
        // }

        public function businessDays(Request $request)
        {

            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $businessDays = isset($request->business_Days) && !empty($request->business_Days) ? $request->business_Days:'';

                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

               $variable_fields_data = json_decode($businessDays);

              $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
             else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }
               
               $checkHours=DB::table('business_hours')->where('user_id', $userId)->first();
                if(empty($checkHours))
                {   
                    foreach ($variable_fields_data as $key => $value)
                    {
                        $businesshourd['user_id'] = $userId;
                        $businesshourd['day'] = $value->day;
                        if(!empty($value->hour))
                        {
                            foreach ($value->hour as $hourvalue)
                            {
                                $businesshourd['status']='1';
                                $businesshourd['start_time'] =  $hourvalue->start_time;
                                $businesshourd['end_time'] = $hourvalue->end_time;
                                DB::table('business_hours')->insert($businesshourd);
                            }
                        }
                        else
                        {
                            $businesshourd['status']='0';
                            $businesshourd['start_time'] = '';
                            $businesshourd['end_time'] ='';
                            DB::table('business_hours')->insert($businesshourd);
                        }
                    }
                }
                else
                {   
                    DB::table('business_hours')->where('user_id',$userId)->delete();
                    foreach ($variable_fields_data as $key => $value)
                    {
                          $businesshourd['user_id'] = $userId;
                          $businesshourd['day'] = $value->day;
                          
                        if(!empty($value->hour))
                        {
                           foreach ($value->hour as $hourvalue)
                            {
                                $businesshourd['status'] ='1';
                                $businesshourd['start_time'] =  $hourvalue->start_time;
                                $businesshourd['end_time'] = $hourvalue->end_time;
                                DB::table('business_hours')->insert($businesshourd);
                           }
                       }
                       else
                       {
                            $businesshourd['start_time'] = '';
                            $businesshourd['end_time'] ='';
                            $businesshourd['status'] ='0';
                            DB::table('business_hours')->insert($businesshourd);
                        }
                    }
                }

            $businessHours=DB::table('business_hours')->where('user_id',$userId)->get();
            //print_r($)
            if(count($businessHours)>0)
            {
             
                $business=array(1=>array('day'=>'Monday', 'hour'=>array()),
                            2=>array('day'=>'Tuesday', 'hour'=>array()),
                           3=>array('day'=>'Wednesday', 'hour'=>array()),
                            4=>array('day'=>'Thursday', 'hour'=>array()),
                            5=>array('day'=>'Friday', 'hour'=>array()),
                            6=>array('day'=>'Saturday', 'hour'=>array()),
                            7=>array('day'=>'Sunday', 'hour'=>array()),
                     );
                    foreach ($businessHours as $key => $businessHour)
                    {   
                            
                        // $business[$key]['day']=$businessHour->day;
                        // $business[$key]['status']=$businessHour->status;
                       // $a = array();
                        if($businessHour->day=='Monday')
                        {   $business[1]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[1]['hour'][] = $a;
                            

                        }
                        if($businessHour->day=='Tuesday')
                        {
                            $business[2]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[2]['hour'][] = $a;
                        }
                        if($businessHour->day=='Wednesday')
                        {
                             $business[3]['status']=$businessHour->status;
                             $a['start_time'] = $businessHour->start_time;
                             $a['end_time'] = $businessHour->end_time;
                             $business[3]['hour'][] = $a;
                        }
                        if($businessHour->day=='Thursday')
                        {
                            $business[4]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[4]['hour'][] = $a;
                        }
                        if($businessHour->day=='Friday')
                        {
                            $business[5]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[5]['hour'][] = $a;
                        }
                        if($businessHour->day=='Saturday')
                        {
                            $business[6]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[6]['hour'][] = $a;
                        }
                        if($businessHour->day=='Sunday')
                        {
                            $business[7]['status']=$businessHour->status;
                            $a['start_time'] = $businessHour->start_time;
                            $a['end_time'] = $businessHour->end_time;
                            $business[7]['hour'][] = $a;
                        }
                    }
                        $hours=array();
                        foreach ($business as $key => $value)
                        {

                            array_push($hours, $value);
                        } 
            }        
                $resultArray['status']='1';
                $resultArray['message']=trans('api.business_hour');
                $resultArray['business_hours']=$hours;
                return ($resultArray); exit;

            }
        }
        public function businessSubservices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);
         

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $businessTypeId = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

               $subServices=DB::table('business_services')->where('business_id',$businessTypeId)->get();

               $business=array();
                foreach ($subServices as $key => $subService)
                {
                    $services=DB::table('seller_business_services')
                            ->leftjoin('business_services','business_services.id','=','seller_business_services.service_type_id')
                            ->where('service_type_id',$subService->id)
                            ->where('user_id',$userId)
                            ->whereRaw("(seller_business_services.deleted_at IS null)")
                            ->select('seller_business_services.*','business_services.service_name')
                            ->get();
                    $servicescheck=DB::table('seller_business_services')
                            ->where('service_type_id',$subService->id)
                            ->where('user_id',$userId)
                             ->whereRaw("(seller_business_services.deleted_at IS null)")
                            ->get()
                            ->pluck('service_type_id')
                            ->toArray();
                    if(in_array($subService->id,  $servicescheck))
                    {   
                        foreach ($services as $k => $value)
                        {   
                       
                            $value1['id']=$value->id;
                            $value1['user_id']=$value->user_id;
                            $value1['business_type_id']=$value->business_type_id;
                            $value1['service_id']=$value->service_type_id;
                            $value1['service_name']=isset($value->service_name)?$value->service_name:'';
                            $value1['price']=isset($value->price)?$value->price:0;
                            $value1['price_type']=isset($value->price_type)?$value->price_type:'Fixed';
                            $value1['special_offer']=isset($value->special_offer)?$value->special_offer:'';
                            $value1['person']=isset($value->person)?$value->person:0;
                            $value1['home']=isset($value->home)?$value->home:0;
                            $value1['virtual']=isset($value->virtual)?$value->virtual:0;
                            $value1['duration']=isset($value->duration)?$value->duration:'';
                            $value1['service_image']='';
                            if(!empty($value->service_image))
                            {
                                $value1['service_image']=url('img/serviceimage/'.$value->service_image);
                            }
                            
                            $value1['time_type']=$value->time_type;
                            $value1['in_time']=isset($value->in_time)?$value->in_time:'';
                            $value1['in_week']=isset($value->in_week)?$value->in_week:'';
                             $value1['checked']=true;
                             array_push($business, $value1);
                        }
                    }
                    else
                    {
                        $value1['service_id']=$subService->id;
                        $value1['checked']=false;
                        $value1['business_id']=$subService->business_id;
                        $value1['service_name']=$subService->service_name;
                        array_push($business, $value1);
                    }
                }

                if(empty($business)){
                $resultArray['status']='0';
                $resultArray['message']=trans('api.No_SubServices_list_found');
                return ($resultArray); die;
                }
                $resultArray['status']='1';
                $resultArray['message']=trans('api.SubServices_list_found');
                $resultArray['data']=$business;
                return ($resultArray); die;
           }  
        }

        public function image(Request $request)
        {

            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'business_image'=>'array',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=$validator->errors()->all();
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
             else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

               
                $checkImage=DB::table('business_images')->where('user_id',$userId)->first();
                if(empty($checkImage))
                {   
                    if ($request->hasFile('business_image'))
                    {
                        $files = $request->file('business_image');
                        foreach ($files as $image) {
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/businessimage');
                        $image->move($destinationPath, $name);
                        DB::table('business_images')->insert(['user_id'=>$userId,'image'=>$name]);

                       }
                    }
                              
                }
                else
                {   
                    if (file_exists(public_path('img/businessimage/'.$checkImage->image)) && !empty($checkImage->image))
                    {
                         unlink(public_path('img/businessimage/'.$checkImage->image));
                    }
                    if ($request->hasFile('business_image'))
                    {
                       $deleteImage=DB::table('business_images')->where('user_id', $userId)->delete();

                        $files = $request->file('business_image');
                        foreach ($files as $image) {
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/businessimage');
                        $image->move($destinationPath, $name);
                        DB::table('business_images')->insert(['user_id'=>$userId,'image'=>$name]);
                      }
                    }
                    
                }

            $businessimages=DB::table('business_images')->where('user_id',$userId)->get();
            if(!empty($businessimages))
            {
                $business_img=array();
                foreach ($businessimages as $key => $businessimage)
                {
                    if(!empty($businessimage->image) && file_exists(public_path('img/businessimage/'.$businessimage->image)))
                    {
                     $business_img[$key]['business_images']=$businessimage->image=url('img/businessimage/'.$businessimage->image);
                     }
                  
                }
            }
           
                $resultArray['status']=1;
                $resultArray['message']=trans('api.image_upload');
                $resultArray['business_images']=$business_img;
                return ($resultArray); exit;
            }
        }

        public function showbusinessHour(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

            $businessHours=DB::table('business_hours')->where('user_id',$userId)->get();
            $business=array();
            foreach ($businessHours as $key => $businessHour)
            {
                $business[$key]['day']=$businessHour->day;
                $business[$key]['id']=$businessHour->id;
                $business[$key]['status']=$businessHour->status;
                $business[$key]['hour']['start_time']=$businessHour->start_time;
                $business[$key]['hour']['end_time']=$businessHour->end_time;

            }
            return($business); die;
          }
        }




        public function addMultiService(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            'business_type_id'=>'required',
            'business_services'=>'required',
            'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $businessTypeId = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id : '' ;
            $businessServices = isset($request->business_services) && !empty($request->business_services) ? $request->business_services : '' ;

            $typeperson = isset($request->type_person) && !empty($request->type_person) ? $request->type_person :'' ;
            $typehome = isset($request->type_home) && !empty($request->type_home) ? $request->type_home :'' ;
            $typevirtual = isset($request->type_virtual) && !empty($request->type_virtual) ? $request->type_virtual :'' ;
           // $business_Services =  explode(",",$businessServices);
            $session_key = !empty($request->session_key) ? $request->session_key : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $user_arr = DB::table('users')->whereRaw("(id = '".$userid."' AND deleted_at IS null )")->first();

                if(!empty($user_arr))
                {
                    $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    { 

                       $businessServices=json_decode($businessServices);

                        $checkService = DB::table('seller_business_services')->where('business_type_id',$businessTypeId)->where('user_id',$userid)->whereRaw("(deleted_at IS null)")->get()->pluck('service_type_id')->toArray(); 
                        // if(!empty($checkService)){
                        //  $checkService = DB::table('seller_business_services')->where('user_id',$userid)->delete();   
                        // }

                        foreach ($businessServices as $key => $value)
                        {
                            if(!in_array($value->id, $checkService))
                            {   
                                $home=0;
                                if($value->home==1)
                                {
                                    $home=1;
                                }
                                $person=0;
                                if($value->person==1)
                                {
                                    $person=1;
                                }
                                $virtual=0;
                                if($value->virtual==1)
                                {
                                    $virtual=1;
                                }
                                $businessTypeServices= array(
                                'user_id'=>!empty($userid) ? $userid:'',
                                'business_type_id'=>!empty($businessTypeId) ? $businessTypeId:'',
                                'service_type_id'=>!empty($value->id) ? $value->id:'',
                                'person'=>$person,'home'=>$home,'virtual'=>$virtual
                                );
                               DB::table('seller_business_services')->insert($businessTypeServices);
                            }
                        }

                      $sellerbusiness = DB::table('seller_business_services')
                                        ->whereRaw("(deleted_at IS null)")
                                        ->where('user_id',$userid)->get();
                      $data['business_type_id'] = !empty($sellerbusiness[0]->business_type_id)?$sellerbusiness[0]->business_type_id:'';
                    

                      foreach ($sellerbusiness as $key => $sellerbus) {
                       $service_name = DB::table('business_services')->select('service_name')->where('id',$sellerbus->service_type_id)->first();
                       $sellerservices[$key]['id'] = !empty($sellerbus->id) ? $sellerbus->id:'';
                        $sellerservices[$key]['business_id'] = !empty($sellerbus->business_type_id) ? $sellerbus->business_type_id:'';
                       $sellerservices[$key]['service_type_id'] = !empty($sellerbus->service_type_id) ? $sellerbus->service_type_id:'';
                       $sellerservices[$key]['service_name'] = !empty($service_name->service_name)? $service_name->service_name:'';
                       $sellerservices[$key]['price'] = !empty($sellerbus->price)? $sellerbus->price:'';
                       $sellerservices[$key]['type'] = !empty($sellerbus->type)? $sellerbus->type:'';
                        $sellerservices[$key]['person'] = !empty($sellerbus->person)? $sellerbus->person:0;
                        $sellerservices[$key]['home'] = !empty($sellerbus->home)? $sellerbus->home:0;
                        $sellerservices[$key]['virtual'] = !empty($sellerbus->virtual)? $sellerbus->virtual:0;
                       $sellerservices[$key]['special_offer'] = !empty($sellerbus->special_offer)? $sellerbus->special_offer:'';
                       $sellerservices[$key]['price_type'] = !empty($sellerbus->price_type) ?$sellerbus->price_type:'';
                       $sellerservices[$key]['duration'] = !empty($sellerbus->duration) ?$sellerbus->duration:'';
                       $sellerservices[$key]['time_type'] = !empty($sellerbus->time_type) ?$sellerbus->time_type:'onetime';
                       $sellerservices[$key]['service_image'] = !empty($sellerbus->service_time) ?$sellerbus->service_image:'';
                     
                     }                      

                      $resultArray['status']='1';
                      $resultArray['message']=trans('api.service_add');
                       $data['seller_business_services']= $sellerservices;
                       $resultArray['seller_business_services'] =$data;
                      return ($resultArray); exit;
                  }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit;
                }
        }

        public function ShowServices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';

                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: ''; 
                
                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

               // $business_type=DB::table('business_types')->where('user_id',$userId)->first();

                $getservicesLists =  DB::table('seller_business_services')
                                    ->select('business_services.service_name','seller_business_services.id','seller_business_services.id','business_types.business_name','business_types.id as business_id','seller_business_services.business_type_id','seller_business_services.price','seller_business_services.special_offer','seller_business_services.duration','seller_business_services.price_type','seller_business_services.service_image','seller_business_services.time_type','seller_business_services.in_time','seller_business_services.in_week','seller_business_services.service_type_id','seller_business_services.type','seller_business_services.home','seller_business_services.person','seller_business_services.virtual')
                                    ->join('business_types','business_types.id','=','seller_business_services.business_type_id')
                                    ->join('business_services','business_services.id','=','seller_business_services.service_type_id')
                                    ->where('seller_business_services.user_id',$userId)
                                    ->whereRaw("(seller_business_services.deleted_at IS null)")
                                    ->get();
               //$business_name = $getservicesLists[0]->business_name;
               //echo $business_name;exit;
              
                $serviceData=array();
                if(count($getservicesLists)>0)
                {
                    foreach ($getservicesLists as $key => $getservicesList)
                    {
                        $service_time='';
                        if(!empty($getservicesList->time_type) == 1)
                        {
                            $service_time = $getservicesList->in_time.','.$getservicesList->in_week;
                        }  

                        if(!empty($getservicesList->service_image))
                        {
                          $image= url('img/serviceimage/'.$getservicesList->service_image);
                        }
                        else
                        {
                          $image = '';
                        } 
                        $serviceData[$key]['id']=!empty($getservicesList->id)? $getservicesList->id: '';
                        $serviceData[$key]['business_id']=!empty($getservicesList->business_id)? $getservicesList->business_id: '';
                        $serviceData[$key]['business_name']=!empty($getservicesList->business_name)? $getservicesList->business_name: '';
                        $serviceData[$key]['service_name']=!empty($getservicesList->service_name)? $getservicesList->service_name: '';
                       
                        $serviceData[$key]['service_id']=!empty($getservicesList->service_type_id)? $getservicesList->service_type_id: '';

                        $serviceData[$key]['price']=!empty($getservicesList->price) ? $getservicesList->price: '';
                        $serviceData[$key]['type']=!empty($getservicesList->type) ? $getservicesList->type: '';
                        $serviceData[$key]['home']=!empty($getservicesList->home) ? $getservicesList->home: 0;
                        $serviceData[$key]['person']=!empty($getservicesList->person) ? $getservicesList->person: 0;
                        $serviceData[$key]['virtual']=!empty($getservicesList->virtual) ? $getservicesList->virtual: 0;
                        $serviceData[$key]['duration']=!empty($getservicesList->duration) ? $getservicesList->duration: '';
                        $serviceData[$key]['multi_time']=$service_time;
                        $serviceData[$key]['time_type']=!empty($getservicesList->time_type) ? $getservicesList->time_type: '';
                        $serviceData[$key]['price_type']=!empty($getservicesList->price_type) ? $getservicesList->price_type: '';
                        $serviceData[$key]['service_image']=$image;
                        $serviceData[$key]['special_offer']=!empty($getservicesList->special_offer) ? $getservicesList->special_offer:'';
                       
                    }
              
                   // $result['business_services'] =$serviceData;
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.service_found');
                    $resultArray['data']=$serviceData;
                   return response()->json($resultArray); exit;

            }

            else{

                    $resultArray['status']='0';
                    $resultArray['message']='No service found';
                   return response()->json($resultArray); exit;

              }
        }

        public function DeleteServices(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'service_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $serviceid = isset($request->service_id) && !empty($request->service_id) ? $request->service_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $deldata = DB::table('seller_business_services')->where('id',$serviceid)->where('user_id',$userid)->delete();

            $resultArray['status']='1';
            $resultArray['message']=trans('api.service_delete');
            echo json_encode($resultArray); exit;
        }


        public function serviceDetails(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            'service_id'=> 'required',
            'business_type_id'=> 'required',
            'session_key'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';

            $serviceid = isset($request->service_id) && !empty($request->service_id) ? $request->service_id: '';

             $businesstypeid = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id: '';

            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
            App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {

                $serviceDetails =  DB::table('seller_business_services')
                                  ->where('user_id',$userid)
                                  ->where('id',$serviceid)
                                  ->where('business_type_id',$businesstypeid)
                                  ->whereRaw("(seller_business_services.deleted_at IS null)")
                                  ->first();

                if(!empty($serviceDetails->time_type) == 0)
                {
                   $service_time = 0;
                } 
                else
                {
                    $service_time = $serviceDetails->in_time.','.$serviceDetails->in_week;
                }
                //print_r($serviceDetails);exit;
                if(!empty($serviceDetails))
                {
                    $service_name = DB::table('business_services')->where('id',$serviceDetails->service_type_id)->first();
                    $business_name = DB::table('business_types')->where('id',$serviceDetails->business_type_id)->first();
                    $serviceDetails->service_name = !empty($service_name->service_name) ? $service_name->service_name:'';
                    $serviceDetails->business_name = !empty($business_name->business_name) ? $business_name->business_name:'';

                    if(!empty($serviceDetails->service_image))
                    {
                      $image= url('img/serviceimage/'.$serviceDetails->service_image);
                    }
                    else
                    {
                      $image = '';
                    }


                    $serviceDetails =array('id'=>!empty($serviceDetails->id)? $serviceDetails->id :'',
                    'business_id'=>!empty($serviceDetails->business_type_id)? $serviceDetails->business_type_id :'',
                    'business_name'=>!empty($serviceDetails->business_name)? $serviceDetails->business_name :'',
                    'service_id'=>!empty($serviceDetails->service_type_id)? $serviceDetails->service_type_id :'',
                    'service_name'=>!empty($serviceDetails->service_name)? $serviceDetails->service_name :'',
                    'price'=>!empty($serviceDetails->price)? $serviceDetails->price :'',
                    'price_type'=>!empty($serviceDetails->price_type)? $serviceDetails->price_type :'',
                    'duration'=>!empty($serviceDetails->duration)? $serviceDetails->duration :'',
                    'special_offer'=>!empty($serviceDetails->special_offer)? $serviceDetails->special_offer :'',
                    'type'=>!empty($serviceDetails->type)? $serviceDetails->type :'',
                    'person'=>!empty($serviceDetails->person)? $serviceDetails->person :'',
                    'home'=>!empty($serviceDetails->home)? $serviceDetails->home :'',
                    'virtual'=>!empty($serviceDetails->virtual)? $serviceDetails->virtual :'',
                    'multi_time'=>$service_time,
                    'service_image'=>!empty($image)? $image :'',
                    'time_type'=>$serviceDetails->time_type
                    );
                }

                if(empty($serviceDetails))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_service_found');
                    return ($resultArray); die;
                }
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.service_found');
                    $resultArray['data']=$serviceDetails;
                    return ($resultArray); die;
            }
        }
        public function addStaffMember(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'seller_id'=> 'required',
            //'session_key'=>'required',
            'email'=>'required',
            'phone'=>'required',          
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id : '' ;
            $staffName = isset($request->name) && !empty($request->name) ? $request->name : '' ;
            $position  = isset($request->position) && !empty($request->position) ? $request->position : '' ;
            $staffCardId = isset($request->staff_card_id) && !empty($request->staff_card_id) ? $request->staff_card_id : '' ;
            $phone = isset($request->phone) && !empty($request->phone) ? $request->phone : '' ;
            $staffImage = isset($request->staff_image) && !empty($request->staff_image) ? $request->staff_image : '' ;
            $session_key = !empty($request->session_key) ? $request->session_key : '' ;

            $editId  = isset($request->staff_id) && !empty($request->staff_id) ? $request->staff_id : '' ;

            $bio = isset($request->bio) && !empty($request->bio) ? $request->bio : '' ;
            $about = isset($request->about) && !empty($request->about) ? $request->about : '' ;

            $experience = isset($request->experience) && !empty($request->experience) ? $request->experience : '' ;

            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $user_arr = DB::table('users')->whereRaw("(id = '".$sellerId."' AND deleted_at IS null )")->first();

            $check_staff = DB::table('staff_members')->where("id",$editId)->first();
            $checkno = DB::table('users')->where('mobile_no',$request->phone)->first();
            if(!empty($checkno))
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.messages.phone_taken');
                return response()->json($resultArray); exit;
            }


            if(!empty($editId))
            {
                if(empty($check_staff))
                {
                     $resultArray['status']='0';
                     $resultArray['message']=trans('api.inval_editid');
                     echo json_encode($resultArray); exit;
                }
                   
                    if ($request->hasFile('staff_image'))
                    {
                        $image = $request->file('staff_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/staffimage');
                        $image->move($destinationPath, $name);
                    }

               $updatestaff= array(
                        'seller_id'=>$sellerId,
                       // 'staff_image'=>$name,
                      //  'name'=>$staffName,
                        'position'=>$position,
                        'staff_card_id'=>$staffCardId,
                        'phone'=>$phone,
                        'bio'=> $bio,
                        'experience'=>$experience
                        );

               DB::table('staff_members')->where('id',$editId)->update($updatestaff);
               $resultArray['status']=1;
               $resultArray['message']=trans('api.edit_staff');
               echo json_encode($resultArray); exit;
            }



            if(!empty($user_arr))
            {
                // $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                // if($check_auth['status']!=1)
                // {
                //     echo json_encode($check_auth); exit;
                // }
                // else
                // {  
                 $name='';
                  if ($request->hasFile('staff_image'))
                    {
                        $image = $request->file('staff_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/staffimage');
                        $image->move($destinationPath, $name);
                    }
                    $requestcode= rand(111111,9999999);
                    $staffCardId= 'SL'.rand(1111,9999);

                    $addstaff=new User;
                    $addstaff->first_name=$request->first_name;
                    $addstaff->last_name=$request->last_name;
                    $addstaff->username=$request->first_name.' '.$request->last_name;
                    $addstaff->email=$request->email;
                    $addstaff->confirmation_code=md5(uniqid(mt_rand(), true));
                    $addstaff->confirmed=1;
                    $addstaff->mobile_no=$request->phone;
                    $addstaff->password='';
                    $addstaff->avatar_location=$name;
                    $addstaff->user_group_id=5;
                    $addstaff->save();
                    DB::table('staff_members')->insert(['seller_id'=>$sellerId,'staff_id'=>$addstaff->id,'staff_image'=>$name,'name'=>$request->first_name.' '.$request->last_name,'position'=>$position,'staff_card_id'=>$staffCardId,'phone'=>$phone,'bio'=>$bio,'experience'=>$experience,'request_code'=>$requestcode]);
                       
                        $email=$request->email;
                        $requestcode1['code']=$requestcode;
                        Mail::send('frontend.mail.request_code', ['requestcode'=>$requestcode1], function($message)use($email) {
                         $message->to($email)->subject
                            (app_name().': '.__('Request confirmed code'));
                         $message->from(env('MAIL_FROM_ADDRESS'),app_name());
                      });
     
                        $resultArray['status']='1';
                        $resultArray['message']=trans('api.staff_member');
                        echo json_encode($resultArray); exit;
                   // }
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid_user');
                echo json_encode($resultArray); exit;
            }
        }

        public function EditStaffMember(Request $request)
        {
           $validator = Validator::make($request->all(), [
            'seller_id'=> 'required',
            'staff_id'=>'required'          
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            } 

                $staffdata = DB::table('staff_members')
                            ->join('business_infos','business_infos.user_id','=','staff_members.seller_id')
                            ->join('users','users.id','=','staff_members.staff_id')
                            ->where("staff_members.staff_id",$request->staff_id)->first();
                $staffArray['business_name']=isset($staffdata->business_name) && !empty($staffdata->business_name) ? $staffdata->business_name : '' ;
                $staffArray['staff_name']=isset($staffdata->name) && !empty($staffdata->name) ? $staffdata->name : '' ;
                $staffArray['staff_id']=isset($staffdata->staff_id) && !empty($staffdata->staff_id) ? $staffdata->staff_id : '' ;
                $staffArray['phone']=isset($staffdata->phone) && !empty($staffdata->phone) ? $staffdata->phone : '' ;
                $staffArray['email']=isset($staffdata->email) && !empty($staffdata->email) ? $staffdata->email : '' ;
                $staffArray['bio']=isset($staffdata->bio) && !empty($staffdata->bio) ? $staffdata->bio : '' ;
                $staffArray['about']=isset($staffdata->about) && !empty($staffdata->about) ? $staffdata->about : '' ;
                $staffArray['status']=isset($staffdata->request_status) && !empty($staffdata->request_status) ? $staffdata->request_status : '' ;
                $staffArray['staff_image']='';
                if(!empty($staffdata->staff_image) && file_exists(public_path('img/staffimage/'.$staffdata->staff_image)))
                {
                    $staffArray['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                }

                $gethours = DB::table('business_hours')
                ->where('user_id',$request->seller_id)->get();
                //print_r($gethours);die();

                $staffArrayhour=array();
                if(count($gethours)>0)
                {
                    foreach ($gethours as $key => $getservicesList)
                    {
                                                                     
                        $staffArrayhour[$key]['day']=!empty($getservicesList->day)? $getservicesList->day: '';
                        $staffArrayhour[$key]['start_time']=!empty($getservicesList->start_time)? $getservicesList->start_time: '';
                        $staffArrayhour[$key]['end_time']=!empty($getservicesList->end_time)? $getservicesList->end_time: '';
                        $staffArrayhour[$key]['status']=!empty($getservicesList->status)? $getservicesList->status: '';
                       
                    }
                }

                $resultArray['status']='1';
                $resultArray['message']=trans('api.staff_edit');
                $resultArray['data']=$staffArray;
                $resultArray['hours']=$staffArrayhour;

                 return response()->json($resultArray); exit;
        }

        public function reSendInvitationCode(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'phone'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $checkstaff=DB::table('staff_members')->where('phone',$request->phone)->first();
            if(empty($checkstaff))
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;     
            }

            $email=$request->email;
            $resendcode=rand(1111111,9999999);
            $requestcode['code']=$resendcode;
            DB::table('staff_members')->where('phone',$request->phone)->update(['request_code'=>$resendcode]);
            Mail::send('frontend.mail.request_code', ['requestcode'=>$requestcode], function($message)use($email) {
            $message->to($email)->subject
                (app_name().': '.__('Request confirmed code'));
             $message->from(env('MAIL_FROM_ADDRESS'),app_name());
          });

            $resultArray['status']='1';
            $resultArray['message']=trans('api.resend_code_successfully');
            echo json_encode($resultArray); exit;

            
        } 

        public function StaffMemberList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'seller_id' => 'required',
                //'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  

            $sellerId = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $stafflists= DB::table('staff_members')->where('seller_id',$sellerId)->get();

                if(count($stafflists)>0)
                {   
                    $staffData=[];
                    foreach ($stafflists as $key => $stafflist)
                    {
                        $staffData[$key]['id']=$stafflist->id;
                        $staffData[$key]['bio']=!empty($stafflist->bio) ? $stafflist->bio : ''; 
                        $staffData[$key]['experience']=!empty($stafflist->experience) ? $stafflist->experience : ''; 
                        $staffData[$key]['name']=$stafflist->name;
                        $staffData[$key]['position']=$stafflist->position;
                        $staffData[$key]['status']=$stafflist->request_status;
                       // $staffData[$key]['staff_card_id']=!empty($stafflist->staff_card_id) ? $stafflist->staff_card_id : '' ;
                        $staffData[$key]['phone']=$stafflist->phone;

                       if(!empty($stafflist->staff_image) && file_exists(public_path('img/staffimage/'.$stafflist->staff_image)))
                        {
                          $staffData[$key]['staff_image']= url('img/staffimage/'.$stafflist->staff_image);
                          
                        }

                          else
                          {
                              $staffData[$key]['staff_image']= '';  
                          }
                        $staffData[$key]['rating ']=0;

                    }
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.staff_list');
                        $resultArray['data']= $staffData;
                        return ($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.data_not_found');
                    return ($resultArray); exit; 
                }
        }

        public function staffBioAdd(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'bio'=>'required',
                'staff_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            DB::table('staff_members')->where('staff_id',$request->staff_id)->update(['bio'=>$request->bio]);
            $resultArray['status']='1';
            $resultArray['message']=trans('api.bio_update_successfully');
            echo json_encode($resultArray); exit;
        }

        public function staffAboutAdd(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'about'=>'required',
                'staff_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            DB::table('staff_members')->where('staff_id',$request->staff_id)->update(['about'=>$request->about]);
            $resultArray['status']='1';
            $resultArray['message']=trans('api.about_update_successfully');
            echo json_encode($resultArray); exit;
        }

        public function StaffMemberDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'staff_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $staffid = isset($request->staff_id) && !empty($request->staff_id) ? $request->staff_id : '' ;
          
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            DB::table('staff_members')->where('id',$staffid)->where('user_id',$userid)->delete();
           
            $resultArray['status']=1;
            $resultArray['message']=trans('api.staff_delete');
            echo json_encode($resultArray); exit;
        }

        public function StaffMemberDetail(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'staff_id' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

            $staffId = isset($request->staff_id) && !empty($request->staff_id) ? $request->staff_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $stafflists= DB::table('staff_members')->where('id',$staffId)->first();

            if(!empty($stafflists))
            {
               $result =array('id'=>!empty($stafflists->id)? $stafflists->id :'','name'=>!empty($stafflists->name)? $stafflists->name :'','bio'=>!empty($stafflists->bio)? $stafflists->bio :'','experience'=>!empty($stafflists->experience)? $stafflists->experience :'','position'=>!empty($stafflists->position)? $stafflists->position :'','staff_card_id'=>!empty($stafflists->staff_card_id)? $stafflists->staff_card_id :'','phone'=>!empty($stafflists->phone)? $stafflists->phone :'','staff_image'=>!empty($stafflists->staff_image && file_exists(public_path('img/staffimage/'.$stafflists->staff_image)))? url('img/staffimage/'.$stafflists->staff_image) :'' 
                );
           
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.staff_edit');
                    $resultArray['data']= $result;
                    return ($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.data_not_found');
                return($resultArray); exit; 
            }  
        } 


        public function addGiftCard(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            'session_key'=>'required',
            'price'=>'required',
            'code'=>'required',
            ]);
           
            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $price = isset($request->price) && !empty($request->price) ? $request->price : '' ;
            $code  = isset($request->code) && !empty($request->code) ? $request->code : '' ;

            $editId  = isset($request->edit_id) && !empty($request->edit_id) ? $request->edit_id : '' ;

            $session_key = !empty($request->session_key) ? $request->session_key : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $user_arr = DB::table('users')->whereRaw("(id = '".$userId."' AND deleted_at IS null )")->first();

            $check_gift = DB::table('gift_cards')->where("id",$editId)->first();

            if(!empty($editId))
            {
                   if(empty($check_gift))
                {
                     $resultArray['status']='0';
                     $resultArray['message']=trans('api.inval_editid');
                     echo json_encode($resultArray); exit;
                }
               
               $updategift= array(
                        'user_id'=>$userId,
                        'price'=>$price,
                        'code'=>$code,
                        );

               DB::table('gift_cards')->where('id',$editId)->update($updategift);
               $resultArray['status']=1;
               $resultArray['message']=trans('api.edit_gift_card');
               echo json_encode($resultArray); exit;
            }

        

                if(!empty($user_arr))
                {
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {   
                        $addgiftcard= array(
                                'user_id'=>$userId,
                                'price'=>$price,
                                'code'=>$code,
                            );
                            $addstaffData =  DB::table('gift_cards')->insert($addgiftcard);
                            $resultArray['status']=1;
                            $resultArray['message']=trans('api.gift_card');
                            echo json_encode($resultArray); exit;
                    }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                    echo json_encode($resultArray); exit;
                }
        }


        public function giftCardList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $giftCardlists= DB::table('gift_cards')->where('user_id',$userid)->get();

                if(count($giftCardlists)>0)
                {   
                    $giftData=[];
                    foreach ($giftCardlists as $key => $giftCardlist)
                    {
                        $giftData[$key]['id']=$giftCardlist->id;
                        $giftData[$key]['price']=$giftCardlist->price;
                        $giftData[$key]['code']=$giftCardlist->code;
                      
                    }
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.gift_list');
                    $resultArray['data']= $giftData;
                    return ($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.data_not_found');
                    return ($resultArray); exit; 
                } 
        } 

        public function giftCardDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'gift_card_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $giftCardId = isset($request->gift_card_id) && !empty($request->gift_card_id) ? $request->gift_card_id : '' ;
          
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            DB::table('gift_cards')->where('id',$giftCardId)->where('user_id',$userid)->delete();
           
            $resultArray['status']=1;
            $resultArray['message']=trans('api.gift_card_delete');
            echo json_encode($resultArray); exit;
        }

        public function serviceList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'business_type_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $businessTypeId = isset($request->business_type_id) && !empty($request->business_type_id) ? $request->business_type_id: '';

                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

                $serviceLists =  DB::table('service_list')
                                    ->select('business_services.service_name')
                                    ->join('business_services','business_services.id','=','service_list.person')
                                    ->groupBy('service_list.person')
                                    ->where('service_list.business_type_id',$businessTypeId)
                                    ->get();

                $specialOfferServices =  DB::table('service_list')
                                    ->select('business_services.service_name','service_list.special_offer')
                                    ->join('business_services','business_services.id','=','service_list.person')
                                    ->where('service_list.business_type_id',$businessTypeId)
                                    ->where('service_list.special_offer','!=','')
                                    ->groupBy('service_list.person')
                                    ->get();
          
             

                $serviceData=array();
                if(count($serviceLists)>0)
                {
                   foreach ($serviceLists as $key => $serviceList)
                    {
                        $serviceData[$key]['name']=!empty($serviceList->service_name)? $serviceList->service_name: '';
                        $serviceData[$key]['address']=!empty($serviceList->address)? $serviceList->address: '';
                        $serviceData[$key]['image']=!empty($serviceList->image)? $serviceList->image: '';

                   }
                }

                $specialofferData=array();
                if(count($specialOfferServices)>0)
                {
                   foreach ($specialOfferServices as $key => $specialOfferService)
                    {
                        $specialofferData[$key]['special_offer']=!empty($specialOfferService->special_offer)? $specialOfferService->special_offer: '';
                        $specialofferData[$key]['name']=!empty($specialOfferService->service_name)? $specialOfferService->service_name: '';
                        $specialofferData[$key]['address']= !empty($specialOfferService->address)? $specialOfferService->address: '';
                        $specialofferData[$key]['image']=!empty($specialOfferService->image)? $specialOfferService->image: '';

                   }
               
              
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.service_found');
                    $resultArray['data']['service_list']=$serviceData;
                    $resultArray['data']['special_offers_services']=$specialofferData;
                   return response()->json($resultArray); exit;
                }
                else
                {

                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_service_found');
                   return response()->json($resultArray); exit;
                }
        }


        public function serviceMap(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
                'latitude'=>'required',
                'longitude'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
                $latitude = isset($request->latitude) && !empty($request->latitude) ? $request->latitude: '';
                $longitude = isset($request->longitude) && !empty($request->longitude) ? $request->longitude: '';

                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
                $radius = 200;

                $servicemapDatas = DB::table('business_address')
                ->selectRaw("*,
                            ( 6371 * acos( cos( radians(" . $latitude . ") ) *
                            cos( radians(business_address.business_lat) ) *
                            cos( radians(business_address.business_long) - radians(" . $longitude . ") ) + 
                            sin( radians(" . $latitude . ") ) *
                            sin( radians(business_address.business_lat) ) ) ) 
                            AS distance")
                ->join('business_infos','business_infos.user_id','=','business_address.user_id')
                ->having("distance", "<", $radius)
                ->orderBy("distance")
                ->get();

               // print_r($servicemapDatas);exit;

                $serviceMap=array();
                if(count($servicemapDatas)>0)
                {
                   foreach ($servicemapDatas as $key => $servicemapData)
                    {
                        $serviceMap[$key]['name']=!empty($servicemapData->business_name)? $servicemapData->business_name: '';
                        $serviceMap[$key]['address']=!empty($servicemapData->business_address)? $servicemapData->business_address: '';
                        $serviceMap[$key]['image']=!empty($servicemapData->image)? $servicemapData->image: '';

                   }
                
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.salon_found');
                    $resultArray['data']['saloon_list']=$serviceMap;
                   return response()->json($resultArray); exit;
                 }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_salon_found');
                    return response()->json($resultArray); exit;
                }
        }

        public function addDiscount(Request $request)
        {
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            'session_key'=> 'required',
            'min_order_value'=>'required',
            'percentage'=>'required',
            'start_date'=>'required',
            'end_date'=>'required'
          ]);
           
            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }

            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;

            $minOrderValue = isset($request->min_order_value) && !empty($request->min_order_value) ? $request->min_order_value : '' ;

            $maxDiscount  = isset($request->max_discount) && !empty($request->max_discount) ? $request->max_discount : '' ;

            $coupon = 'SL'.mt_rand(100000, (int) 999999);

            $percentage  = isset($request->percentage) && !empty($request->percentage) ? $request->percentage : '' ;

            $editId  = isset($request->edit_id) && !empty($request->edit_id) ? $request->edit_id : '' ;

            $session_key = !empty($request->session_key) ? $request->session_key : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $user_arr = DB::table('users')->whereRaw("(id = '".$userId."' AND deleted_at IS null )")->first();

            $check_discount = DB::table('discounts')->where("id",$editId)->first();

            if(!empty($editId))
            {
                if(empty($check_discount))
                {
                     $resultArray['status']='0';
                     $resultArray['message']=trans('api.inval_editid');
                     echo json_encode($resultArray); exit;
                }
               $updateDiscount= array(
                        'user_id'=>$userId,
                        'min_order_value'=>$minOrderValue,
                        'max_discount'=>$maxDiscount,
                        'percentage'=>$percentage,
                        'start_date'=>$request->start_date,
                        'end_date'=>$request->end_date,
                        );

               DB::table('discounts')->where('id',$editId)->update($updateDiscount);
               $resultArray['status']=1;
               $resultArray['message']=trans('api.edit_discount');
               echo json_encode($resultArray); exit;
            }

                if(!empty($user_arr))
                {
                    $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {   
                        $adddiscount= array(
                                'user_id'=>$userId,
                                'min_order_value'=>$minOrderValue,
                                'max_discount'=>$maxDiscount,
                                'coupon'=>$coupon,
                                'percentage'=>$percentage,
                                'start_date'=>$request->start_date,
                                'end_date'=>$request->end_date,
                            );
                            $addstaffData =  DB::table('discounts')->insert($adddiscount);
                            $resultArray['status']=1;
                            $resultArray['message']=trans('api.add_discount');
                            echo json_encode($resultArray); exit;
                    }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                    echo json_encode($resultArray); exit;
                }
        }


        public function discountList(Request $request)
        {
           $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $discountlists= DB::table('discounts')->where('user_id',$userid)->get();
                if(count($discountlists)>0)
                {   
                    $discountData=[];
                    foreach ($discountlists as $key => $discountlist)
                    {
                        $discountData[$key]['id']=$discountlist->id;
                        $discountData[$key]['min_order_value']=$discountlist->min_order_value;
                        $discountData[$key]['max_discount']=$discountlist->max_discount;
                        $discountData[$key]['coupon']=$discountlist->coupon;
                        $discountData[$key]['percentage']=$discountlist->percentage;
                        $discountData[$key]['start_date']=$discountlist->start_date;
                        $discountData[$key]['end_date']=$discountlist->end_date;
                      
                    }
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.discount_list');
                    $resultArray['data']= $discountData;
                    return ($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.data_not_found');
                    return ($resultArray); exit; 
                }
        } 

        public function discountDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'discount_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $discountId = isset($request->discount_id) && !empty($request->discount_id) ? $request->discount_id : '' ;
            $session_key = !empty($request->session_key) ? $request->session_key : '' ;

          
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);


            $user_arr = DB::table('users')->whereRaw("(id = '".$userid."' AND deleted_at IS null )")->first();


                if(!empty($user_arr))
                {
                    $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
                    if($check_auth['status']!=1)
                    {
                        echo json_encode($check_auth); exit;
                    }
                    else
                    {   
                        DB::table('discounts')->where('id',$discountId)->where('user_id',$userid)->delete();
                           
                            $resultArray['status']=1;
                            $resultArray['message']=trans('api.discount_delete');
                            echo json_encode($resultArray); exit;
                    }
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                    echo json_encode($resultArray); exit;
                }
        }
        public function editSingleService(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'id'=>'required',
                'business_type_id'=>'required',
                'person'=>'required',
                'home'=>'required',
                'virtual'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
                $access_token=123456;
                $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';

                $id = isset($request->id) && !empty($request->id) ? $request->id: '';

                $business_type_id = isset($request->user_id) && !empty($request->business_type_id) ? $request->business_type_id: '';

                $serviceid = isset($request->service_id) && !empty($request->service_id) ? $request->service_id: '';

                $type = isset($request->type) && !empty($request->type) ? $request->type: ''; 


                $price = isset($request->price) && !empty($request->price) ? $request->price: '';

                $price_type = isset($request->price_type) && !empty($request->price_type) ? $request->price_type: '';

                $special_offer = isset($request->special_offer) && !empty($request->special_offer) ? $request->special_offer: '';
                $duration = isset($request->duration) && !empty($request->duration) ? $request->duration: '';
                $timeType = isset($request->time_type) && !empty($request->time_type) ? $request->time_type: '';

                $multiTime = isset($request->multi_time) && !empty($request->multi_time) ? $request->multi_time: '';

                $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';

                $serviceimage = isset($request->service_image) && !empty($request->service_image) ? $request->service_image: '';

                $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);
               
                $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
                if($check_auth['status']!=1)
                {
                    echo json_encode($check_auth); exit;
                }
                else
                {

                    if ($request->hasFile('service_image'))
                    {
                        $image = $request->file('service_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/serviceimage');
                        $image->move($destinationPath, $name);
                    }

                    $intime='NULL';
                    $inweek='NULL';
                    if($timeType==1)
                    {
                        if(!empty($multiTime))
                        {
                            $service=explode(",", $multiTime);
                            $intime=$service[0];
                            $inweek=$service[1];
                        }
                    }
                     $updateservice= array(
                                'user_id'=>$userid,
                                'business_type_id'=>$business_type_id,
                                'service_type_id'=>$serviceid,
                                'type'=>$type,
                                'price'=>$price,
                                'price_type'=>$price_type,
                                'special_offer'=>$special_offer,
                                'duration'=>$duration,
                                'time_type'=>$timeType,
                                'in_time'=>$intime,
                                'home'=>$request->home,
                                'person'=>$request->person,
                                'virtual'=>$request->virtual,
                                'in_week'=>$inweek,
                                'service_image'=>!empty($name)? $name:''
                                );
                    DB::table('seller_business_services')->where('id',$id)->update($updateservice);
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.service_update');
                    echo json_encode($resultArray); exit;   
                }
        }


        public function appoinmentListsecond(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $appoinment_date = isset($request->date) && !empty($request->date) ? $request->date : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);

           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {

               if(!empty($appoinment_date))
               {
                    $appoinmentLists=DB::table('orders')
                                 ->select('orders.*')
                                 ->where("orders.service_date",$appoinment_date)
                                 ->where('orders.seller_id',$userid)
                                 ->get();
                }
               else  
               {
                    $appoinmentLists=DB::table('orders')
                                 ->select('orders.*')
                                 ->where('orders.seller_id',$userid)
                                 ->get();
               }

                $allData=array();
                foreach ($appoinmentLists as $key => $appoinmentList)
                {
                    
                    $serviceData['order_id']=!empty($appoinmentList->order_id) ? $appoinmentList->order_id:'';
                    $serviceData['order_date']=!empty($appoinmentList->order_date) ? $appoinmentList->order_date: '';
                    $serviceData['service_date']=!empty($appoinmentList->service_date) ? $appoinmentList->service_date: '';
                     $serviceData['trans_id']=!empty($appoinmentList->trans_id) ? $appoinmentList->trans_id: '';
                    $serviceData['start_time']=!empty($appoinmentList->start_time) ? $appoinmentList->start_time: '';
                    $serviceData['end_time']=!empty($appoinmentList->end_time) ? $appoinmentList->end_time: '';
                    $serviceData['payment_status']=!empty($appoinmentList->payment_status) ? $appoinmentList->payment_status: '';
                    $serviceData['payment_type']=!empty($appoinmentList->payment_type) ? $appoinmentList->payment_type: '';
                    $serviceData['order_status']=!empty($appoinmentList->order_status) ? $appoinmentList->order_status: '';
                    $serviceData['amount']=!empty($appoinmentList->amount) ? $appoinmentList->amount: '';
                    //username
                    $userdata=DB::table('users')->where('id',$appoinmentList->user_id)->first();
                    if(!empty($userdata))
                    {
                        $serviceData['user_id']=!empty($userdata->id) ? $userdata->id: '';
                        $serviceData['user_name']=!empty($userdata->username) ? $userdata->username: '';
                        $serviceData['user_phone_no']=!empty($userdata->mobile_no) ? $userdata->mobile_no: '';
                        $serviceData['user_address']=!empty($userdata->address) ? $userdata->address: '';
                        $serviceData['user_image']='';
                        if(!empty($userdata->avatar_location))
                        {
                            $serviceData['user_image']=url('img/user/profile/'.$userdata->avatar_location);
                         }
                    }
                    //Staff data
                    $staffdata=DB::table('staff_members')->where('id',$appoinmentList->staff_id)->first();
                    if(!empty($staffdata))
                    {
                        $serviceData['staff_id']=!empty($staffdata->id) ? $staffdata->id: '';
                        $serviceData['staff_name']=!empty($staffdata->name) ? $staffdata->name: '';
                        $serviceData['staff_phone']=!empty($staffdata->staff_phone) ? $staffdata->staff_phone: '';
                        $serviceData['staff_bio']=!empty($staffdata->bio) ? $staffdata->bio: '';
                        $serviceData['staff_experience']=!empty($staffdata->experience) ? $staffdata->experience: '';
                        $serviceData['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                    }

                    $cartdatas=DB::table('carts')
                            ->leftjoin('business_services','business_services.id','=','carts.service_id')
                            ->leftjoin('seller_business_services','seller_business_services.service_type_id','=','carts.service_id')
                            ->leftjoin('business_types','business_types.id','=','carts.cat_id')
                            ->whereRaw("(seller_business_services.deleted_at IS null)")
                            ->where('carts.status','Complete')
                            ->where('carts.seller_id',$userid)
                            ->where('seller_business_services.user_id',$userid)
                            ->select('carts.*','seller_business_services.*','business_services.service_name','business_types.business_name')
                            ->where('order_id',$appoinmentList->order_id)->get();
                            //  echo '<pre>'; print_r($cartdatas);
                            $serviceDatasingle=array();
                            foreach ($cartdatas as $c => $cartdatas)
                            {
                                $mutiservice='';
                                if($cartdatas->time_type==1)
                                {
                                    $mutiservice=$cartdatas->in_time.','.$cartdatas->in_week;
                                }
                                $serviceData1['service_type']=isset($cartdatas->service_type)?$cartdatas->service_type:'';

                                $serviceData1['business_name']=isset($cartdatas->business_name)?$cartdatas->business_name:'';
                                $serviceData1['service_name']=isset($cartdatas->service_name)?$cartdatas->service_name:'';
                                $serviceData1['service_image']=url('img/serviceimage/'.$cartdatas->service_image);
                                $serviceData1['time_type']=isset($cartdatas->time_type)?$cartdatas->time_type:'';
                                $serviceData1['price_type']=isset($cartdatas->price_type)?$cartdatas->price_type:'';
                                $serviceData1['price']=isset($cartdatas->price)?$cartdatas->price:'';
                                $serviceData1['special_offer']=isset($cartdatas->special_offer)?$cartdatas->special_offer:'';
                                $serviceData1['duration']=isset($cartdatas->duration)?$cartdatas->duration:'';
                                $serviceData1['multi_time']=$mutiservice;
                                array_push($serviceDatasingle, $serviceData1);
                            }
                                $serviceData['service_info']=$serviceDatasingle ;
                                array_push($allData, $serviceData);
                }
              
                if(!empty($allData))
                {
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.appoinment_list');
                    $resultArray['data']=$allData;
                    return response()->json($resultArray); exit;
                }

                else {

                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_appoinment');
                    return response()->json($resultArray); exit;
                }
            } 
        }

        public function orderStatus(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key' => 'required',
                'order_id'=>'required'
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $orderstatus = isset($request->order_status) && !empty($request->order_status) ? $request->order_status : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                if(!empty($orderstatus))
                {
                    DB::table('orders')->where('seller_id',$sellerid)->where('order_id',$request->order_id)->update(['order_status'=>$orderstatus]);
                    $userId=DB::table('orders')->where('seller_id',$sellerid)->where('order_id',$request->order_id)->select('user_id')->first();
                     $deviceId=DB::table('user_devices')->where('user_id',$userId->user_id)->first();

                        $device_id=isset($deviceId->device_id)?$deviceId->device_id:'';
                        if($orderstatus=='Accept')
                        {
                            $title='Service Accepted';
                            $message='Your saloon service accepted';
                            $orderstatus='order';   
                        }
                        if($orderstatus=='Complete')
                        {
                            $title='Service Complete';
                            $message='Your saloon service completed'; 
                            $orderstatus='order'; 
                        }
                        if($orderstatus=='Reject')
                        {
                            $title='Service Reject';
                            $message='Your saloon service Reject';
                            $orderstatus='order';
                        }
                        DB::table('notifications')->insert([
                                       'user_id'=>$userId->user_id,
                                       'title'=> $title,
                                       'message'=> $message,
                                       'type'=> $orderstatus,
                                        ]);
                        $orderid=$request->order_id;
                      
                        $this->postpushnotification($device_id,$title,$message,$orderid,$orderstatus);
                           

                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Order_status_update_successfully');
                        echo json_encode($resultArray); exit;
                }
                else
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Order_status_not_update');
                    echo json_encode($resultArray); exit;

                }
            }
        }

        public function customerList(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $customerData=DB::table('orders')
                                    ->join('users','users.id','=','orders.user_id')
                                    ->where('orders.seller_id',$sellerid)
                                    ->select('users.username','users.mobile_no','users.avatar_location','users.id')
                                    ->groupBy('orders.user_id')
                                    ->get();
                   
                    if(count($customerData)>0)
                    {   
                        $customerArray=array();
                        foreach ($customerData as $key => $customers)
                        {
                            $customerArray[$key]['id']=$customers->id;
                            $customerArray[$key]['name']=$customers->username;
                            $customerArray[$key]['mobile_no']=isset($customers->mobile_no)?$customers->mobile_no:'';
                            $customerArray[$key]['address']=isset($customers->address)?$customers->address:'';
                            $customerArray[$key]['image']='';
                            if(!empty($customers->avatar_location) && file_exists(public_path('img/user/profile/'.$customers->avatar_location)))
                            {
                                $customerArray[$key]['image']=url('img/user/profile/'.$customers->avatar_location);
                            }
                        }
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Customer_list_found');
                        $resultArray['data']= $customerArray;
                        echo json_encode($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.Customer_not_found');
                        echo json_encode($resultArray); exit;
                    }

                   
            }
        }


        public function customerInfo(Request $request)
        {

            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'seller_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $sellerid = isset($request->seller_id) && !empty($request->seller_id) ? $request->seller_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $customersinfo=DB::table('orders')
                                    ->join('users','users.id','=','orders.user_id')
                                    ->where('orders.seller_id',$sellerid)
                                    ->where('orders.user_id',$userId)
                                    ->select('users.username','users.mobile_no','users.avatar_location',DB::raw('sum(amount) as amounts'))
                                      ->selectRaw('count(*) as total')
                                    ->selectRaw("count(case when order_status = 'confirmed' then 1 end) as confirmed")
                                    ->selectRaw("count(case when order_status = 'Pending' then 1 end) as Pending")
                                    ->selectRaw("count(case when order_status = 'Accept' then 1 end) as Accept")
                                    ->selectRaw("count(case when order_status = 'Cancel' then 1 end) as cancelled")
                                    ->selectRaw("count(case when order_status = 'Complete' then 1 end) as Complete")
                                    ->first();

                           $customerDatas=DB::table('orders')
                                    ->join('users','users.id','=','orders.user_id')
                                    ->where('orders.seller_id',$sellerid)
                                    ->where('orders.user_id',$userId)
                                    ->orderBy('orders.service_date','desc')
                                    ->get();
                            $allData=array();
                            foreach ($customerDatas as $key => $appoinmentList)
                            {
                                
                                $serviceData['order_id']=!empty($appoinmentList->order_id) ? $appoinmentList->order_id:'';
                                $serviceData['order_date']=!empty($appoinmentList->order_date) ? $appoinmentList->order_date: '';
                                $serviceData['service_date']=!empty($appoinmentList->service_date) ? $appoinmentList->service_date: '';
                                 $serviceData['trans_id']=!empty($appoinmentList->trans_id) ? $appoinmentList->trans_id: '';
                                $serviceData['start_time']=!empty($appoinmentList->start_time) ? $appoinmentList->start_time: '';
                                $serviceData['end_time']=!empty($appoinmentList->end_time) ? $appoinmentList->end_time: '';
                                $serviceData['payment_status']=!empty($appoinmentList->payment_status) ? $appoinmentList->payment_status: '';
                                $serviceData['payment_type']=!empty($appoinmentList->payment_type) ? $appoinmentList->payment_type: '';
                                $serviceData['order_status']=!empty($appoinmentList->order_status) ? $appoinmentList->order_status: '';
                                if(date('Y-m-d') <= ($appoinmentList->service_date) && $appoinmentList->order_status=='Pending')
                                    {
                                          $serviceData['order_status']='Upcoming';
                                    }
                                $serviceData['amount']=!empty($appoinmentList->amount) ? $appoinmentList->amount: '';
                             

                                $cartdatas=DB::table('carts')
                                        ->leftjoin('business_services','business_services.id','=','carts.service_id')
                                        ->leftjoin('seller_business_services','seller_business_services.service_type_id','=','carts.service_id')
                                        ->leftjoin('business_types','business_types.id','=','carts.cat_id')
                                        ->where('carts.status','Complete')
                                        ->where('carts.seller_id',$sellerid)
                                        ->where('seller_business_services.user_id',$sellerid)
                                        ->whereRaw("(seller_business_services.deleted_at IS null)")
                                        ->select('carts.*','seller_business_services.*','business_services.service_name','business_types.business_name')
                                        ->where('order_id',$appoinmentList->order_id)->get();
                                        //  echo '<pre>'; print_r($cartdatas);
                                        $serviceDatasingle=array();
                                        foreach ($cartdatas as $c => $cartdatas)
                                        {
                                            $mutiservice='';
                                            if($cartdatas->time_type==1)
                                            {
                                                $mutiservice=$cartdatas->in_time.','.$cartdatas->in_week;
                                            }
                                            $serviceData1['service_type']=isset($cartdatas->service_type)?$cartdatas->service_type:'';

                                            $serviceData1['business_name']=isset($cartdatas->business_name)?$cartdatas->business_name:'';
                                            $serviceData1['service_name']=isset($cartdatas->service_name)?$cartdatas->service_name:'';
                                            $serviceData1['service_image']=url('img/serviceimage/'.$cartdatas->service_image);
                                            $serviceData1['time_type']=isset($cartdatas->time_type)?$cartdatas->time_type:'';
                                            $serviceData1['price_type']=isset($cartdatas->price_type)?$cartdatas->price_type:'';
                                            $serviceData1['price']=isset($cartdatas->price)?$cartdatas->price:'';
                                            $serviceData1['special_offer']=isset($cartdatas->special_offer)?$cartdatas->special_offer:'';
                                            $serviceData1['duration']=isset($cartdatas->duration)?$cartdatas->duration:'';
                                            $serviceData1['multi_time']=$mutiservice;
                                            array_push($serviceDatasingle, $serviceData1);
                                        }
                                            $serviceData['service_info']=$serviceDatasingle ;
                                            array_push($allData, $serviceData);
                            }
                   
                    if(!empty($customersinfo))
                    {   
                        $customerArray['username']=isset($customersinfo->username)?$customersinfo->username:'';
                        $customerArray['phone_no']=isset($customersinfo->mobile_no)?$customersinfo->mobile_no:'';
                        $customerArray['image']='';
                        if( !empty($customersinfo->avatar_location) && file_exists(public_path('img/user/profile/'.$customersinfo->avatar_location)))
                        {
                            $customerArray['image']=url('img/user/profile/'.$customersinfo->avatar_location);
                        }
                        
                        $customerArray['total_amount']=isset($customersinfo->amounts)?$customersinfo->amounts:'';
                        $customerArray['booking']=isset($customersinfo->total)?$customersinfo->total:0;
                        $customerArray['complete']=isset($customersinfo->Complete)?$customersinfo->Complete:0;
                        $customerArray['pending']=isset($customersinfo->Pending)?$customersinfo->Pending:0;
                        $customerArray['accept']=isset($customersinfo->Accept)?$customersinfo->Accept:0;
                        $customerArray['cancelled']=isset($customersinfo->cancelled)?$customersinfo->cancelled:0;
                        $customerArray['confirmed']=isset($customersinfo->confirmed)?$customersinfo->confirmed:0;
                       
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Customer information found');
                        $resultArray['data']= $customerArray;
                        $resultArray['service_info']= $allData;
                        echo json_encode($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.Customer data not found');
                        echo json_encode($resultArray); exit;
                    }

                   
            }
        }

        public function sales(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $monthyear = isset($request->month) && !empty($request->month) ? $request->month : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $query=DB::table('orders')
                                    ->join('users','users.id','=','orders.user_id')
                                    ->where('orders.seller_id',$sellerid)
                                    ->select('users.username','users.mobile_no','users.avatar_location','orders.order_id','orders.start_time','orders.end_time','orders.amount','orders.order_status','orders.service_date');
                                    if(!empty($monthyear))
                                    {
                                       $data=explode("-", $monthyear);
                                       $month=$data[0];
                                       $year=$data[1];
                                        $query->whereRaw("MONTH(orders.service_date) ='".$month."' and YEAR(orders.service_date) ='".$year."'");
                                    }
                                    $customerData=$query->orderBY('orders.service_date','desc')
                                    ->groupBy('orders.service_date')
                                    ->get();
                    if(count($customerData)>0)
                    {   
                       
                        $data=array();
                        foreach ($customerData as $key => $customers)
                        {
                            $data[$key]['service_date']=$customers->service_date;
                            $customerData2=DB::table('orders')
                                    ->join('users','users.id','=','orders.user_id')
                                    ->where('orders.seller_id',$sellerid)
                                    ->where('orders.service_date',$customers->service_date)
                                    ->select('users.username','users.mobile_no','users.avatar_location','orders.order_id','orders.start_time','orders.end_time','orders.amount','orders.order_status','orders.service_date')
                                    ->orderBY('orders.service_date','desc')
                                    ->get();
                            $data[$key]['service_data']=$customerData2;
                        }
                            $customerArray4=array();
                            foreach($data as $key => $date)
                            {
                                
                                $customerArray5['date']= $date['service_date'];
                                $customerArray3=array();
                                foreach($date['service_data'] as $k => $value)
                                {

                                   $serviceType=DB::table('carts')
                                        ->join('business_services','business_services.id','=','carts.service_id')
                                        ->where('carts.order_id',$value->order_id)->select('carts.service_type','business_services.service_name')->first();
                                    $customerArray['order_id']=$value->order_id;
                                    $customerArray['user_name']=$value->username;
                                    $customerArray['start_time']=$value->start_time;
                                    $customerArray['end_time']=$value->end_time;
                                    $customerArray['amount']=$value->amount;
                                    $customerArray['service_name']=isset($serviceType->service_name)?$serviceType->service_name:'';
                                    $customerArray['service_type']=isset($serviceType->service_type)?$serviceType->service_type:'';
                                    $customerArray['service_date']=$value->service_date;
                                    $customerArray['status']=$value->order_status;
                                    if(date('Y-m-d') <= ($value->service_date) && $value->order_status=='Pending')
                                    {
                                         $customerArray['status']='Upcoming';
                                    }

                                    $customerArray['image']='';
                                    if(!empty($value->avatar_location) && file_exists(public_path('img/user/profile/'.$value->avatar_location)))
                                    {
                                        $customerArray['image']=url('img/user/profile/'.$value->avatar_location);
                                    } 
                                    array_push($customerArray3, $customerArray);
                                } 
                                 $customerArray5['options']= $customerArray3;
                                array_push($customerArray4, $customerArray5);
                            }
                            
                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Customer_list_found');
                        $resultArray['data']= $customerArray4;
                        echo json_encode($resultArray); exit;
                    }
                    else
                    {
                        $resultArray['status']='0';
                        $resultArray['message']=trans('api.data_not_found');
                        echo json_encode($resultArray); exit;
                    }
            }
        }

        public function orderDetail(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'order_id' => 'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $orderid = isset($request->order_id) && !empty($request->order_id) ? $request->order_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $customerData=DB::table('orders')
                                    ->where('orders.seller_id',$sellerid)
                                    ->where('orders.order_id',$orderid)
                                    ->first();
                   
              
                  
                    $serviceData['order_id']=!empty($customerData->order_id) ? $customerData->order_id:'';
                    $serviceData['order_date']=!empty($customerData->order_date) ? $customerData->order_date: '';
                    $serviceData['service_date']=!empty($customerData->service_date) ? $customerData->service_date: '';
                     $serviceData['trans_id']=!empty($customerData->trans_id) ? $customerData->trans_id: '';
                    $serviceData['start_time']=!empty($customerData->start_time) ? $customerData->start_time: '';
                    $serviceData['end_time']=!empty($customerData->end_time) ? $customerData->end_time: '';
                    $serviceData['payment_status']=!empty($customerData->payment_status) ? $customerData->payment_status: '';
                    $serviceData['payment_type']=!empty($customerData->payment_type) ? $customerData->payment_type: '';
                    $serviceData['order_status']=!empty($customerData->order_status) ? $customerData->order_status: '';
                    $serviceData['amount']=!empty($customerData->amount) ? $customerData->amount: '';
                    //username
                    $userdata=DB::table('users')->where('id',$customerData->user_id)->first();
                    if(!empty($userdata))
                    {
                        $serviceData['user_id']=!empty($userdata->id) ? $userdata->id: '';
                        $serviceData['user_name']=!empty($userdata->username) ? $userdata->username: '';
                        $serviceData['user_phone_no']=!empty($userdata->mobile_no) ? $userdata->mobile_no: '';
                        $serviceData['user_address']=!empty($userdata->address) ? $userdata->address: '';
                        $serviceData['user_image']='';
                        if(!empty($userdata->avatar_location))
                        {
                            $serviceData['user_image']=url('img/user/profile/'.$userdata->avatar_location);
                         }
                    }
                    //Staff data
                    $staffdata=DB::table('staff_members')->where('id',$customerData->staff_id)->first();
                    if(!empty($staffdata))
                    {
                        $serviceData['staff_id']=!empty($staffdata->id) ? $staffdata->id: '';
                        $serviceData['staff_name']=!empty($staffdata->name) ? $staffdata->name: '';
                        $serviceData['staff_phone']=!empty($staffdata->staff_phone) ? $staffdata->staff_phone: '';
                        $serviceData['staff_bio']=!empty($staffdata->bio) ? $staffdata->bio: '';
                        $serviceData['staff_experience']=!empty($staffdata->experience) ? $staffdata->experience: '';
                        $serviceData['staff_image']=url('img/staffimage/'.$staffdata->staff_image);
                    }

                    $cartdatas=DB::table('carts')
                            ->leftjoin('business_services','business_services.id','=','carts.service_id')
                            ->leftjoin('seller_business_services','seller_business_services.service_type_id','=','carts.service_id')
                            ->leftjoin('business_types','business_types.id','=','carts.cat_id')
                            ->where('carts.status','Complete')
                            ->where('carts.seller_id',$sellerid)
                            ->where('seller_business_services.user_id',$sellerid)
                            ->whereRaw("(seller_business_services.deleted_at IS null)")
                            ->select('carts.*','seller_business_services.*','business_services.service_name','business_types.business_name')
                            ->where('order_id',$customerData->order_id)->get();
                          //  echo '<pre>'; print_r($cartdatas);
                            $serviceDatasingle=array();
                            foreach ($cartdatas as $c => $cartdatas)
                            {
                                $mutiservice='';
                                if($cartdatas->time_type==1)
                                {
                                    $mutiservice=$cartdatas->in_time.','.$cartdatas->in_week;
                                }
                                $serviceData1['service_type']=isset($cartdatas->service_type)?$cartdatas->service_type:'';

                                $serviceData1['business_name']=isset($cartdatas->business_name)?$cartdatas->business_name:'';
                                $serviceData1['service_name']=isset($cartdatas->service_name)?$cartdatas->service_name:'';
                                $serviceData1['service_image']=url('img/serviceimage/'.$cartdatas->service_image);
                                $serviceData1['time_type']=isset($cartdatas->time_type)?$cartdatas->time_type:'';
                                $serviceData1['price_type']=isset($cartdatas->price_type)?$cartdatas->price_type:'';
                                $serviceData1['price']=isset($cartdatas->price)?$cartdatas->price:'';
                                $serviceData1['special_offer']=isset($cartdatas->special_offer)?$cartdatas->special_offer:'';
                                $serviceData1['duration']=isset($cartdatas->duration)?$cartdatas->duration:'';
                                $serviceData1['multi_time']=$mutiservice;
                                array_push($serviceDatasingle, $serviceData1);
                            }
                            $serviceData['service_info']=$serviceDatasingle ;
                            
               
              
                if(!empty($serviceData))
                {
                    $resultArray['status']=1;
                    $resultArray['message']=trans('api.appoinment_list');
                    $resultArray['data']=$serviceData;
                    return response()->json($resultArray); exit;
                }

                else {

                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.no_appoinment');
                    return response()->json($resultArray); exit;
                }
                   
            }
        }

        public function sellerRating(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                    $reviewdatas=DB::table('ratings')
                                        ->leftjoin('users','users.id','=','ratings.user_id')
                                        ->select('ratings.*','users.username')
                                        ->where('seller_id',$sellerid)->get();
                        $reviewArray=array();
                        $ratingcount=0;
                        if(count($reviewdatas)>0)
                        {
                            foreach ($reviewdatas as $key => $reviews)
                            {
                               $ratingcount+=$reviews->rating;
                            }
                        }
                        $count=count($reviewdatas);
                        $ratingData['average']=0;
                        $ratingData['all_review']=$count;
                        if($count!=0)
                        {
                            $ratingData['average']=number_format($ratingcount/$count,2);
                        }
                        $reviewList=array();
                        $ratingonestar=0;
                        $ratingtwostar=0;
                        $ratingthreestar=0;
                        $ratingfourstar=0;
                        $ratingfivestar=0;
                        foreach ($reviewdatas as $key => $value)
                        {
                            $reviewList[$key]['review']=$value->rating;
                            $reviewList[$key]['commnet']=isset($value->comment)?$value->comment:'';
                            $reviewList[$key]['username']=isset($value->username)?$value->username:'';
                            if($value->rating==1)
                            {
                                $ratingonestar=+$ratingonestar+1;
                            }elseif($value->rating==2)
                            {
                                $ratingtwostar=+$ratingtwostar+1;
                            }elseif($value->rating==3)
                            {
                                $ratingthreestar=+$ratingthreestar+1;
                            }elseif($value->rating==4)
                            {
                                $ratingfourstar=+$ratingfourstar+1;
                            }elseif($value->rating==5)
                            {
                                $ratingfivestar=+$ratingfivestar+1;
                            }
                        }
                        $ratingData['oneStart']=$ratingonestar;
                        $ratingData['twoStar']=$ratingtwostar;
                        $ratingData['threeStart']=$ratingthreestar;
                        $ratingData['fourStart']=$ratingfourstar;
                        $ratingData['fiveStart']=$ratingfivestar;
                            $resultArray['status']=1;
                            $resultArray['message']=trans('Customer list found.');
                            $resultArray['data']= $ratingData;
                            $resultArray['ratinglist']= $reviewList;
                            echo json_encode($resultArray); exit;
            }   
        }

        public function certificateDelete(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $certificat = isset($request->certificat) && !empty($request->certificat) ? $request->certificat : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $certificate=DB::table('business_infos')
                                    ->where('user_id',$sellerid)->first();
                if(!empty($certificate->certificate))
                {
                    $certificated=explode('|', $certificate->certificate);

                    if(in_array($certificat, $certificated))
                    {
                         unset($certificated[array_search($certificat,$certificated)]);

                        if(file_exists(public_path('img/certificate/'.$certificat)))
                        {
                             unlink(public_path('img/certificate/'.$certificat));
                        }
                    }
                        if(count($certificated)>0)
                        {
                            $remaingcert=implode("|", $certificated);
                            $data['certificate']=$remaingcert;
                            $businessDatas = DB::table('business_infos')->where('user_id',$sellerid)->update($data);
                        }
                       
                          
                        $businessDatas = DB::table('business_infos')->where('user_id',$sellerid)->first();

                        if(!empty($businessDatas->certificate)){
                         $certificates =  explode("|",$businessDatas->certificate);
                        }
                        $business_certi=array();
                        if(count($certificates)>0)
                        {
                            foreach ($certificates as $key => $certificate)
                            {
                                if(!empty($certificate) && file_exists(public_path('img/certificate/'.$certificate)))
                                {
                                    $business_certi2['certificate']=$certificate=url('img/certificate/'.$certificate);
                                    array_push($business_certi, $business_certi2);
                                 }
                            }
                        }

                        $resultArray['status']=1;
                        $resultArray['message']=trans('api.Certificate delete successfully ');
                        $resultArray['certificate']= $business_certi;
                        echo json_encode($resultArray); exit;                                       
                }
                else
                {   
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Certificate not found');
                    echo json_encode($resultArray); exit;

                }
            }  
        }

        public function deletebusinessType(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
                'business_id'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $businesseId = isset($request->business_id) && !empty($request->business_id) ? $request->business_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                DB::table('seller_business_services')
                                    ->where('user_id',$sellerid)->where('business_type_id',$businesseId)->update(['deleted_at'=>now()]);
                                    
                $serviceDatas = DB::table('seller_business_services')
                                ->leftjoin('business_services','business_services.id','=','seller_business_services.service_type_id')
                                ->select('seller_business_services.*','business_services.service_name')
                                ->where('seller_business_services.user_id',$sellerid)
                                ->whereRaw("(seller_business_services.deleted_at IS null)")
                                ->get();

                if(count($serviceDatas)>0)
                {  
                    $businessname = DB::table('business_types')->select('business_name')
                    ->where('id',$serviceDatas[0]->business_type_id)->first();
               
                    $serviceShow = array();
                    if(count($serviceDatas)>0)
                    {
                        foreach ($serviceDatas as $key => $serviceData)
                        {
                            $multiTime='';
                            if($serviceData->time_type==1)
                            {
                                $multiTime=$serviceData->in_time.','.$serviceData->in_week;
                            }
                                $serviceShow[$key]['id'] = $serviceData->id;
                                $serviceShow[$key]['service_id'] = $serviceData->service_type_id;
                                $serviceShow[$key]['service_name'] = isset($serviceData->service_name)?$serviceData->service_name:'';
                                $serviceShow[$key]['type'] = $serviceData->type;
                                $serviceShow[$key]['price'] =isset($serviceData->price)?$serviceData->price:'';
                                $serviceShow[$key]['price_type'] =isset($serviceData->price_type)?$serviceData->price_type:'';
                                $serviceShow[$key]['special_offer'] = !empty($serviceData->special_offer) ? $serviceData->special_offer:'';
                                $serviceShow[$key]['duration'] = !empty($serviceData->duration) ? $serviceData->duration:'';
                                $serviceShow[$key]['time_type'] = !empty($serviceData->time_type) ? $serviceData->time_type:'';
                                $serviceShow[$key]['service_image'] = url('img/serviceimage/'.$serviceData->service_image);
                                $serviceShow[$key]['multi_time'] =$multiTime;
                        } 
                    }  

                    $data['business_type_id'] = !empty($serviceDatas[0]->business_type_id) ? $serviceDatas[0]->business_type_id:'';
                    $data['business_name'] = isset($businessname->business_name) ? $businessname->business_name:'';
                    
                    $data['Service'] = $serviceShow;
                   
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.Business services delete successfully');
                    $resultArray['business_type']=  $data;
                    echo json_encode($resultArray); exit;   
                }
                else
                {
                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.Business services delete successfully');
                    echo json_encode($resultArray); exit;   
                }
                
            }  
        }


        public function getPlans()
        {
            $getPlans=Plan::where('status',1)->get();
            $planInfo=array();
            foreach($getPlans as $p=>$plans)
            {
                $planInfo[$p]['id']=$plans->id;
                $planInfo[$p]['name']=$plans->name;
                $planInfo[$p]['price']=$plans->price;
                $planInfo[$p]['no_off_staff']=$plans->no_off_staff;
            }
                $resultArray['status']='1';
                $resultArray['message']=trans('api.plan_list');
                $resultArray['plans']= $planInfo;
                echo json_encode($resultArray); exit;  
        }

        public function notificationSetting(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id' => 'required',
                'session_key'=>'required',
                'notification'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }  
            
            $access_token=123456;
            $sellerid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
           $check_auth = $this->checkToken($access_token, $sellerid, $session_key, $lang);
           if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                DB::table('users')->where('id',$sellerid)->update(['notification'=>$request->notification]);
                $notification=DB::table('users')->where('id',$sellerid)->first();

                $resultArray['status']='1';
                $resultArray['message']=trans('appi.Notification update successfully');
                $resultArray['notification']= $notification->notification;
                echo json_encode($resultArray); exit;   

            }
        }


        function postpushnotification($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
            if(!empty($device_id))
            {
              $fields = array(
                 'to' => $device_id,
                  'data' =>array('title' => $title, 'message' => $message,'urlToken' => $urlToken,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus),
                'notification'=>array('title'=>$title,'body'=>$message,'sound'=>'default','order_id'=>$orderid,'orderstatus'=>$orderstatus)
                );

                $response = $this->sendPushNotification($fields);
                return true;
            }
        }

       

        function sendPushNotification($fields = array(), $usertype=Null)
        {
             //echo '<pre>';print_r($fields); //exit;
              $API_ACCESS_KEY = 'AAAAfCJQ4L0:APA91bFz__v7ZXMDFUudEzA0y_C04gx1iiPSCeaGStcj_hrOx7oNfKl5lwGFqZxzKAqDjgedJy14GdxF_LRuXUZn7fTTcMztP4wkSxYMsPRltXCov-ldRUtFN5FyWoNB5i5qbSi9La2k';

              $headers = array
              (
                'Authorization: key=' . $API_ACCESS_KEY,
                'Content-Type: application/json'
              );

              $ch = curl_init();
              curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
              curl_setopt( $ch,CURLOPT_POST, true );
              curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
              curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
              curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
              curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
              curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
              // Execute post
              $result = curl_exec($ch);
              //print_r($result);//die;
              sleep(5);
              if ($result === FALSE) {
                  die('Curl failed: ' . curl_error($ch));
              }
              // Close connection
              curl_close($ch);
              return $result;    
        }
        function iospush($device_id,$title,$message,$orderid,$orderstatus=null,$urlToken=null)
        {
           
            $tokenLength = strlen($device_id);
            if (!empty($device_id))
            {
                $apnsHost = 'gateway.push.apple.com';
                //$apnsHost = 'gateway.sandbox.push.apple.com';
               //$apnsCert = public_path('buskalock.pem');
                $apnsCert = public_path('pushcertBuskalo.pem');
                $sound = 'default';
                $apnsPort = 2195;
                $apnsPass = '';
                $token = $device_id;
                $payload['aps'] = array('title' => $title, 'alert' => $message, 'badge' => '1', 'sound' => 'default','order_id'=>$orderid,'orderstatus'=>$orderstatus);
                $output = json_encode($payload);
                $token = pack('H*', str_replace(' ', '', $token));
                $apnsMessage = chr(0) . chr(0) . chr(32) . $token . chr(0) . chr(strlen($output)) . $output;
                $streamContext = stream_context_create();
                stream_context_set_option($streamContext, 'ssl', 'local_cert', $apnsCert);
                stream_context_set_option($streamContext, 'ssl', 'passphrase', $apnsPass);
                $apns = @stream_socket_client('ssl://' . $apnsHost . ':' . $apnsPort, $error, $errorString, 2, STREAM_CLIENT_CONNECT, $streamContext);
                //fwrite($apns, $apnsMessage);
                $result = @fwrite($apns, $apnsMessage, strlen($apnsMessage)); //fwrite($apns, $apnsMessage);
                @fclose($apns);
                if (!$result) {
                    $a = 'Message not delivered' . PHP_EOL;
                } else {
                    $a = 'Message successfully delivered' . PHP_EOL;
                }
                $log = "User: " . $_SERVER['REMOTE_ADDR'] . ' - ' . date("F j, Y, g:i a") . PHP_EOL .
                    "Attempt: " . (!empty($result) ? 'Success' : 'Failed') . PHP_EOL .
                    "Pass: " . $result . PHP_EOL .
                    "apns: " . $apns . PHP_EOL .
                    "apnsMessage: " . $apnsMessage . PHP_EOL .
                    "device_id:" .$device_id . PHP_EOL .
                    "Pass: " . $a . PHP_EOL .
                    "-------------------------" . PHP_EOL;
                  //  return $result; 
               // echo "<pre>"; print_r($apns); die;
                return $log;
                //Save string to log, use FILE_APPEND to append.
                //file_put_contents(content_url().'/log/log_'.date("j.n.Y").'.txt', $log, FILE_APPEND);
                //exit;
            }
        }


        public function updatesql(Request $request)
        {
            
            $getdata1= DB::table('users')->whereIn('id',['59','60','61'])->delete();
            $getdata2= DB::table('social_accounts')->whereIn('user_id',['59','60','61'])->delete();

            $getdata3= DB::table('users')
                        ->leftjoin('social_accounts','social_accounts.user_id','=','users.id')
                        ->select('users.id as userid','users.email','social_accounts.*')
                        ->get();
            echo '<pre>'; print_r($getdata3);
        }


        /* V Search City API */
        public function searchCities(Request $request)
        {
            $data = isset($request->cities_name) && !empty($request->cities_name) ? $request->cities_name : '' ;
            if(!empty($data))    
            {
                $mycity = City::where('cities_name', 'like', "%{$data}%")->select('id','cities_name')->get();
                $resultArray['status']=1;
                $resultArray['message']=trans('api.messages.city.success');
                $resultArray['data']=$mycity;
                return response()->json($resultArray); exit;      
            }  
            else
            { 
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                $resultArray['data']='';
                echo json_encode($resultArray); exit; 
            }  
        }

}   