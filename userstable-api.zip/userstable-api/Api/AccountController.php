<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Lookbook;
use App\Models\Auth\User;
use App\Models\Auth\SocialAccount;
use App\Models\UserSetting;
use App\Models\Plan;
use App\Repositories\BaseRepository;
use Illuminate\Support\Facades\Password;
use App\Notifications\Frontend\Auth\UserNeedsPasswordReset;
use App\Notifications\Frontend\Auth\UserNeedsConfirmation;
use App\Notifications\Frontend\Auth\UserNeedsResendOtp;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class AccountController extends APIController
{
        
        public function register(Request $request)
        {
            $validation = Validator::make($request->all(), [
                'first_name'=>'required',
                'last_name'=>'required',
                'username'=>'required',
                'user_group_id'=>'required',
                'email' => 'required|email',
                'password' => 'required|min:6',
                'confirm_password'=>'required_with:password|same:password|min:6',
                'phone_no'=>'required|numeric',
                'term_condition'=>'required|numeric',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                     return response()->json($resultArray); exit;
            }

           
            $access_token=123456;
            $user_group_id = isset($request->user_group_id) && !empty($request->user_group_id) ? $request->user_group_id: '3';
            $firstname = isset($request->first_name) && !empty($request->first_name) ? $request->first_name: '';
            $lastname = isset($request->last_name) && !empty($request->last_name) ? $request->last_name: '';
            $username = isset($request->username) && !empty($request->username) ? $request->username: '';
            $email = isset($request->email) && !empty($request->email) ? $request->email: '';
            $password = isset($request->password) && !empty($request->password) ? $request->password: '';
            $location = isset($request->location) && !empty($request->location) ? $request->location: '';
            $invitationCode = isset($request->invitation_code) && !empty($request->invitation_code) ? $request->invitation_code: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
            App::setLocale($lang);

            if(!empty($invitationCode))
            {
                $userinfo=  User::where('mobile_no',$request->phone_no)->first();
                $userinfo->first_name=$firstname;
                $userinfo->last_name=$lastname;
                $userinfo->username=$username;
                $userinfo->email=$email;
                $userinfo->password=bcrypt($password);
                $userinfo->remember_token= Hash::make('secret');
                $userinfo->save();
                
                    if ($roles = Role::where('id', $user_group_id)->get()->pluck('id')->toArray())
                    {
                        $userinfo->attachRoles($roles);
                    }
                $deviceType=isset($request->device_type)?$request->device_type:'';
                $deviceId=isset($request->device_id)?$request->device_id:'';
                DB::table('user_devices')->insert(['user_id'=>$userinfo->id,'device_type'=>$deviceType,'device_id'=>$deviceId]);
                $user= User::where('mobile_no',$request->phone_no)->first();
                $user->device_type=$deviceType;
                $user->device_id=$deviceId;
                if(!empty($user->avatar_location))
                {
                    $user->avatar_location=url('img/staffimage/'.$user->avatar_location);
                }
                $resultArray['status']='1';
                $resultArray['message']=trans('api.messages.created_confirm');
                $resultArray['data']=$user;
                return response()->json($resultArray); exit;
            }

            $checkno = DB::table('users')->where('mobile_no',$request->phone_no)->first();
            if(!empty($checkno))
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.messages.phone_taken');
                return response()->json($resultArray); exit;
            }
            
                // $emailexist = DB::table('users')->whereRaw("(email = '".$email."' AND deleted_at IS null )")->first();
                // if(!empty($emailexist))
                // {
                //     $resultArray['status']='0';
                //     $resultArray['message']=trans('api.messages.email_taken');
                //     return response()->json($resultArray); exit;
                // }

                $mobilecheck = DB::table('users')->whereRaw("(mobile_no = '".$request->phone_no."' AND deleted_at IS null )")->first();
                if(!empty($mobilecheck))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.messages.phone_taken');
                    return response()->json($resultArray); exit;
                }
           
                $registerArr['uuid'] = Uuid::uuid4()->toString();
                $registerArr['user_group_id']=$user_group_id;
                $registerArr['first_name']=$firstname;
                $registerArr['last_name']=$lastname;
                $registerArr['username']=$username;
                $registerArr['email'] = $email;
                $registerArr['mobile_no'] = $request->phone_no;
                $registerArr['to_be_logged_out'] = $location;
                $registerArr['active'] = 1;
                $registerArr['otp'] = rand(1111,9999);
                $registerArr['confirmed'] = 0;
                $registerArr['is_term_accept'] = 1;
                $registerArr['discount_message'] = isset($request->discount_message)?$request->discount_message:0;
                $registerArr['password'] =bcrypt($password);
                $registerArr['confirmation_code'] = md5(uniqid(mt_rand(), true));
                $registerArr['created_at'] = Carbon::now()->toDateTimeString();
                $registerArr['remember_token'] = Hash::make('secret');
                if($user = User::create($registerArr)) 
                {
                    if ($roles = Role::where('id', $user_group_id)->get()->pluck('id')->toArray())
                    {
                        $user->attachRoles($roles);
                    }
                }
                $deviceType=isset($request->device_type)?$request->device_type:'';
                $deviceId=isset($request->device_id)?$request->device_id:'';
                DB::table('user_devices')->insert(['user_id'=>$user->id,'device_type'=>$deviceType,'device_id'=>$deviceId]);
                $user->device_type=$deviceType;
                $user->device_id=$deviceId;
                $check_auth = $this->checkToken($access_token,$user->id);

                if (config('access.users.confirm_email'))
                {
                    $user->notify(new UserNeedsConfirmation($user->confirmation_code));
                }

                $resultArray['status']=1;
                $resultArray['message']=trans('api.messages.created_confirm');
                $resultArray['session_key']=$check_auth['Data']['randnumber'];
                $resultArray['data']=$user;
                return response()->json($resultArray); exit;
        }

        public function requestVerifyCode(Request $request)
        {
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);

            $validation = Validator::make($request->all(), [
                'invitation_code'=>'required',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                     return response()->json($resultArray); exit;
            }

            $checkrequestcode=DB::table('staff_members')->where('request_code',$request->invitation_code)->first();
            if(empty($checkrequestcode))
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.invalid_otp');
                return response()->json($resultArray); exit;
            }
                $userinfo=  User::where('mobile_no',$checkrequestcode->phone)->first();
                $registerArr['first_name']=$userinfo->first_name;
                $registerArr['last_name']=$userinfo->last_name;
                $registerArr['username']=$userinfo->username;
                $registerArr['email'] = $userinfo->email;
                $registerArr['mobile_no'] = $userinfo->mobile_no;
                $registerArr['invitation_code'] = $checkrequestcode->request_code;

                $resultArray['status']='1';
                $resultArray['message']=trans('api.messages.created_confirm');
                $resultArray['data']=$registerArr;
                return response()->json($resultArray); exit;
        }

        public function resendOtp(Request $request)
        {
            $validation = Validator::make($request->all(), [
                'phone_no'=>'required',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                     return response()->json($resultArray); exit;
            }
                $otpcode= rand(1111,9999);
                $checkuserornot= User::where('mobile_no',$request->phone_no)->first();
                if(empty($checkuserornot))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.phone_number_does_not_exist');
                    return response()->json($resultArray); exit;
                }
               $checkuserornot->otp=$otpcode;
               $checkuserornot->save();
                $user=User::where('mobile_no',$request->phone_no)->first();

                $user->notify(new UserNeedsResendOtp($user->confirmation_code)); 
                $resultArray['status']='1';
                $resultArray['message']=trans('api.resend_otp');
                return response()->json($resultArray); exit;
        }


        public function verifyCode(Request $request)
        {
            $validation = Validator::make($request->all(), [
                'verify_code'=>'required',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid parameters.');
                     return response()->json($resultArray); exit;
            }
                $checkotp= User::whereRaw("(mobile_no = '".$request->phone_no."' AND otp ='".$request->verify_code."')")->first();
                if(!empty($checkotp))
                {
                    $checkotp->confirmed=1;
                    $checkotp->save();

                    $resultArray['status']='1';
                    $resultArray['message']=trans('api.verify_code');
                    return response()->json($resultArray); exit;
                }else
                {
                   $resultArray['status']='0';
                    $resultArray['message']=trans('api.invalid_otp');
                    return response()->json($resultArray); exit; 
                }
        }


        public function updateProfile(Request $request)
        {   
            $validation = Validator::make($request->all(), [
                'user_id'=>'required',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']='0';
                    $resultArray['message']=$validation->errors()->all();
                     return response()->json($resultArray); exit;
            }

            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
             App::setLocale($lang);

                $usercheck=DB::table('users')->where('id',$userId)->first();
                if($usercheck->user_group_id==2)
                {
                   if ($request->hasFile('profile_image'))
                    {
                        if(!empty($usercheck->avatar_location) && file_exists(public_path('img/business/profile/'.$usercheck->avatar_location)))
                        {   
                        
                            unlink(public_path('img/business/profile/'.$usercheck->avatar_location));
                        }
                        $image = $request->file('profile_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/business/profile/');
                        $image->move($destinationPath, $name);
                        $profileupdate['avatar_location']= $name;
                    }
                }else
                {
                       
                    if ($request->hasFile('profile_image'))
                    {
                        if(!empty($usercheck->avatar_location) && file_exists(public_path('img/user/profile/'.$usercheck->avatar_location)))
                        {
                            unlink(public_path('img/user/profile/'.$usercheck->avatar_location));
                        }
                        $image = $request->file('profile_image');
                        $name = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/img/user/profile/');
                        $image->move($destinationPath, $name);
                        $profileupdate['avatar_location']= $name;
                    }
                }

                    $profileupdate['username']=isset($request->username)?$request->username:'';
                    $profileupdate['email']=isset($request->email)?$request->email:'';
                    $profileupdate['first_name']=isset($request->first_name)?$request->first_name:'';
                    $profileupdate['last_name']=isset($request->last_name)?$request->last_name:'';

                    DB::table('users')->where('id',$userId)->update($profileupdate);

                    $user=DB::table('users')->where('id',$userId)->first();
                    $result['username']=isset($user->username)?$user->username:'';
                    $result['email']=isset($user->email)?$user->email:'';
                    $result['first_name']=isset($user->first_name)?$user->first_name:'';
                    $result['last_name']=isset($user->last_name)?$user->last_name:'';
                    $result['image']='';
                    if(!empty($user->avatar_location) && file_exists(public_path('img/business/profile/'.$user->avatar_location)))
                    {
                        $result['image']=url('img/business/profile/'.$user->avatar_location);
                    }
                    
                    $resultArray['status']=1;
                    $resultArray['data']= $result;
                    $resultArray['message']=trans('api.messages.update_profile');
                    return response()->json($resultArray); exit;
        }
        public function updatePhoneNumber(Request $request)
        {
            $validation = Validator::make($request->all(), [
                'phone_no'=>'required|numeric',
                'user_id'=>'required',
            ]);

            if ($validation->fails()) {
                    $resultArray['status']=0;
                    $resultArray['message']=$validation->errors()->all();
                     return response()->json($resultArray); exit;
            }

            $phoneno = isset($request->phone_no) && !empty($request->phone_no) ? $request->phone_no: '';
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
             App::setLocale($lang);

            $phoneCheck = DB::table('users')->where('mobile_no', $phoneno)->where('id', '!=' , $userId)->first();
           
                if(!empty($phoneCheck))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.messages.phone_taken');
                    return response()->json($resultArray); exit;
                }
                DB::table('users')->where('id',$userId)->update(['mobile_no'=>$phoneno]);
                $resultArray['status']=1;
                $resultArray['message']=trans('api.messages.change_phone');
                 return response()->json($resultArray); exit;
        }

        

       
        

        public function logout(Request $request)
        {   
            $access_token=123456;
            $userid = isset($request->user_id) && !empty($request->user_id) ? $request->user_id : '' ;
            $lang = !empty($request->lang) ? $request->lang : 'en' ;
            App::setLocale($lang);
            $validator = Validator::make($request->all(), [
            'user_id'=> 'required',
            ]);
            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
           // $check_auth = $this->checkToken($access_token, $userid, $session_key, $lang);
            // if($check_auth['status']!=1)
            // {
            //     echo json_encode($check_auth); exit;
            // }
            DB::table('mobile_session')->where('user_id',$userid)->update(['session_key'=>'']);
            $resultArray['status']=1;
            $resultArray['message']=trans('api.messages.logout.success');
            echo json_encode($resultArray); exit;
        }

        

        public function userSettingShow(Request $request)
        {
            $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'session_key'=>'required',
            ]);

            if($validator->fails())
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.Invalid parameters.');
                echo json_encode($resultArray); exit;      
            }
            $access_token=123456;
            $userId = isset($request->user_id) && !empty($request->user_id) ? $request->user_id: '';
            $session_key = isset($request->session_key) && !empty($request->session_key) ? $request->session_key: '';
            $lang = isset($request->lang) && !empty($request->lang) ? $request->lang : 'en';
                App::setLocale($lang);

            $check_auth = $this->checkToken($access_token, $userId, $session_key, $lang);
            if($check_auth['status']!=1)
            {
                echo json_encode($check_auth); exit;
            }
            else
            {
                $userEntity = DB::table('users')
                            ->whereRaw("(active=1)")
                            ->whereRaw("(id = '".$userId."' AND deleted_at IS null )")
                            ->first();
                if(empty($userEntity))
                {
                    $resultArray['status']='0';
                    $resultArray['message']=trans('api.Invalid_user');
                    echo json_encode($resultArray); exit; 
                }

                $userData=DB::table('user_settings')->where('user_id',$userId)->first();
                $resultArray['status']=1;
                $resultArray['message']=trans('api.user_setting_list');
                $resultArray['data']=$userData;
                echo json_encode($resultArray); exit; 

            }
        }





        

       

        

        

        

        
}   