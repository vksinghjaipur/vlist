<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Support\Facades\App;
use Ramsey\Uuid\Uuid;
use Hash,DB;
use Carbon\Carbon;
use App\Models\Auth\Role;
use App\Models\City;
use App\Models\Auth\User;
use App\Models\UserSetting;
use App\Models\Coupon;
use App\Models\Product\Order;
use App\Models\Product\OrderItem;
use App\Models\Product\OrderReturn;
use App\Models\Product\Review;
date_default_timezone_set(isset($_COOKIE["fcookie"])?$_COOKIE["fcookie"]:'Asia/Kolkata');
/**
 * @group Authentication
 *
 * Class AuthController
 *
 * Fullfills all aspects related to authenticate a user.
 */
class OrderController extends APIController
{
    
    public function myOrder(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
        $getmyorders=Order::with('getProductItem')->where('user_id',$request->user_id)->get();
        $orderdetail=array();
        foreach ($getmyorders as $o => $getmyorder)
        {
            $orderdetail[$o]['order_id']=$getmyorder->order_id;
            $orderdetail[$o]['total_amount']=$getmyorder->total_amount;
            $orderdetail[$o]['order_date']=$getmyorder->payment_date;
            $orderdetail[$o]['order_status']= $getmyorder->order_status;
            $orderdetail[$o]['delivery_date']=date('Y-m-d',strtotime($getmyorder->payment_date.'+2 day'));
            $orderdetail[$o]['retuen_date']=date('Y-m-d',strtotime($getmyorder->payment_date.'+7 day'));
            $productinfo=array();
            foreach($getmyorder->getProductItem as $i=>$productitem)
            {
                $productinfo[$i]['product_name']=$productitem->getOrderProduct->name;
                if(!empty($productitem->getOrderProduct->singleImages->image))
                {
                    $productinfo[$i]['product_image']=url('img/products_image/'.$productitem->getOrderProduct->singleImages->image);
                }
            }
                $orderdetail[$o]['item_list']=$productinfo;
        }   
            if(count($orderdetail)>0)
            {
                $resultArray['status']='1';
                $resultArray['message']=trans('api.order_detail');
                $resultArray['order_list']=$orderdetail;
                return response()->json($resultArray); exit;
            }
            else
            {
                $resultArray['status']='0';
                $resultArray['message']=trans('api.data_not_found');
                return response()->json($resultArray); exit; 
            }
    }

    public function orderDetail(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $getorderDetail=Order::with('shippingAddress')->where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
        if(empty($getorderDetail))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.data_not_found');
            echo json_encode($resultArray); exit;    
        }
           $orderinfo['order_id']= $getorderDetail->order_id;
           $orderinfo['order_date']= $getorderDetail->payment_date;
           $orderinfo['total_amount']= $getorderDetail->total_amount;
           $orderinfo['shipping_charge']= $getorderDetail->shipping_charge;
           $orderinfo['discount']= isset($getorderDetail->discount)?$getorderDetail->discount:'0';
           $orderinfo['trans_id']= $getorderDetail->trans_id;
           $orderinfo['payment_status']= $getorderDetail->payment_status;
           $orderinfo['address_title']= $getorderDetail->shippingAddress->address_title;
           $orderinfo['first_name']= $getorderDetail->shippingAddress->first_name;
           $orderinfo['last_name']= $getorderDetail->shippingAddress->last_name;
           $orderinfo['email']= $getorderDetail->shippingAddress->email;
           $orderinfo['phone_no']= $getorderDetail->shippingAddress->phone_no;
           $orderinfo['address']= $getorderDetail->shippingAddress->address;
           $orderinfo['country']= $getorderDetail->shippingAddress->country;
           $orderinfo['state']= $getorderDetail->shippingAddress->state;
           $orderinfo['city']= $getorderDetail->shippingAddress->city;
           $orderinfo['zip_code']= $getorderDetail->shippingAddress->zip_code;
           $orderinfo['order_status']= $getorderDetail->order_status;
           $orderinfo['order_cancel_resion']= isset($getorderDetail->cancel_resion)?$getorderDetail->cancel_resion:'';
           $orderinfo['order_cancel_date']= isset($getorderDetail->order_cancel_date)?$getorderDetail->order_cancel_date:'';

            $getmyorders=Order::with('getProductItem')->where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
                $productinfo=array();
                foreach($getmyorders->getProductItem as $i=>$productitem)
                {   
                    $productinfo[$i]['product_item_id']=$productitem->id;
                    $productinfo[$i]['product_id']=$productitem->p_id;
                    $productinfo[$i]['price']=$productitem->price;
                    $productinfo[$i]['quantity']=$productitem->quantity;
                    $productinfo[$i]['product_name']=$productitem->getOrderProduct->name;
                    if(!empty($productitem->getOrderProduct->singleImages->image))
                    {
                        $productinfo[$i]['product_image']=url('img/products_image/'.$productitem->getOrderProduct->singleImages->image);
                    }
                }
            
                $resultArray['status']='1';
                $resultArray['message']=trans('api.order_detail');
                $resultArray['order_list']=$orderinfo;
                $resultArray['item_list']=$productinfo;
                return response()->json($resultArray); exit;
    }

    public function returnOrder(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $getorderDetail=Order::where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
        if(empty($getorderDetail))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.data_not_found');
            echo json_encode($resultArray); exit;    
        }
           $orderinfo['order_id']= $getorderDetail->order_id;
           $orderinfo['order_date']= $getorderDetail->payment_date;
           $orderinfo['total_amount']= $getorderDetail->total_amount;
           $orderinfo['order_status']= $getorderDetail->order_status;
           $orderinfo['shipping_charge']= $getorderDetail->shipping_charge;
           $orderinfo['discount']= isset($getorderDetail->discount)?$getorderDetail->discount:'0';

            $getmyorders=Order::with('getProductItem')->where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
                $productinfo=array();
            $returnProd= OrderReturn::whereRaw("(user_id='".$request->user_id."' AND order_id='".$request->order_id."')")->get()->pluck('return_item_id')->toArray();    
                foreach($getmyorders->getProductItem as $i=>$productitem)
                {   
                    $productinfo[$i]['order_status']=$getmyorders->order_status;
                    if(in_array($productitem->id,$returnProd))
                    {
                        $productinfo[$i]['order_status']='return';
                    }
                    $productinfo[$i]['product_item_id']=$productitem->id;
                    $productinfo[$i]['product_id']=$productitem->p_id;
                    $productinfo[$i]['price']=$productitem->price;
                    $productinfo[$i]['quantity']=$productitem->quantity;
                    $productinfo[$i]['product_name']=$productitem->getOrderProduct->name;
                    if(!empty($productitem->getOrderProduct->singleImages->image))
                    {
                        $productinfo[$i]['product_image']=url('img/products_image/'.$productitem->getOrderProduct->singleImages->image);
                    }
                }
            
                $resultArray['status']='1';
                $resultArray['message']=trans('api.return_order_list');
                $resultArray['order_list']=$orderinfo;
                $resultArray['item_list']=$productinfo;
                return response()->json($resultArray); exit;
    }

    public function returnRequest(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'return_order'=>'required',
                'order_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            $data=json_decode($request->return_order);
           
                $returnrequest=OrderReturn::where('user_id',$request->user_id)->where('order_id',$request->order_id)->where('return_item_id',$request->return_item_id)->first();
            
            if(!empty($returnrequest))
            {
                $resultArray['status']='1';
                $resultArray['message']=trans('api.return_request_alredy');
                echo json_encode($resultArray); exit;   
            }

           
            foreach($data as $returproduct)
            {
               // print_r($returndata);exit;
                $returndata= new OrderReturn;
                $returndata->user_id=$request->user_id;
                $returndata->return_item_id=$returproduct->return_item_id;
                $returndata->p_id=$returproduct->p_id;
                $returndata->price=$returproduct->price;
                $returndata->quantity=$returproduct->quantity;
                $returndata->order_id=$request->order_id;
                $returndata->resion=$request->resion;
                $returndata->save();
            }
            
                $resultArray['status']='1';
                $resultArray['message']=trans('api.return_request');
                echo json_encode($resultArray); exit;   
    }

    public function orderCancelRequest(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
                'resion'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $checkorderstatus=Order::where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
        if($checkorderstatus->status=='dispatch')
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.order_dispactch');
            echo json_encode($resultArray); exit;
        }

        Order::where('user_id',$request->user_id)->where('order_id',$request->order_id)->update(['cancel_resion'=>$request->resion,'order_status'=>'cancel','order_cancel_date'=>date('Y-m-d')]);

            $resultArray['status']='1';
            $resultArray['message']=trans('api.order_cancel_request');
            echo json_encode($resultArray); exit;   
    }

    public function cancelOrder(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $getorderDetail=Order::where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
        if(empty($getorderDetail))
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.data_not_found');
            echo json_encode($resultArray); exit;    
        }
           $orderinfo['order_id']= $getorderDetail->order_id;
           $orderinfo['order_date']= $getorderDetail->payment_date;
           $orderinfo['total_amount']= $getorderDetail->total_amount;
           $orderinfo['shipping_charge']= $getorderDetail->shipping_charge;
           $orderinfo['discount']= isset($getorderDetail->discount)?$getorderDetail->discount:'0';

            $getmyorders=Order::with('getProductItem')->where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();
                $productinfo=array();
                foreach($getmyorders->getProductItem as $i=>$productitem)
                {   
                    $productinfo[$i]['product_item_id']=$productitem->id;
                    $productinfo[$i]['product_id']=$productitem->p_id;
                    $productinfo[$i]['price']=$productitem->price;
                    $productinfo[$i]['quantity']=$productitem->quantity;
                    $productinfo[$i]['product_name']=$productitem->getOrderProduct->name;
                    if(!empty($productitem->getOrderProduct->singleImages->image))
                    {
                        $productinfo[$i]['product_image']=url('img/products_image/'.$productitem->getOrderProduct->singleImages->image);
                    }
                }
            
                $resultArray['status']='1';
                $resultArray['message']=trans('api.order_cancel');
                $resultArray['order_list']=$orderinfo;
                $resultArray['item_list']=$productinfo;
                return response()->json($resultArray); exit;
    }


    public function reviewList(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }

        $getorderDetail= Order::with('getProductItem')
                    ->where('user_id',$request->user_id)->where('order_id',$request->order_id)->first();

            $productinfo=array();
            
            $checkreview= Review::where('user_id',$request->user_id)->where('order_id',$request->order_id)->select('p_id','rating')->get()->pluck('p_id')->toArray();
            //echo '<pre>'; print_r($checkreview);exit;
            foreach($getorderDetail->getProductItem as $i=>$productitem)
            {
                $productinfo[$i]['checked']=0;
                $productinfo[$i]['count']=0;
                if(in_array($productitem->p_id,$checkreview))
                {
                    if($productitem->getproductId->p_id==$productitem->p_id)
                    {
                        $productinfo[$i]['count']=$productitem->getproductId->rating;
                        $productinfo[$i]['checked']=1;
                    }
                    
                }
                $productinfo[$i]['product_id']=$productitem->p_id;
                $productinfo[$i]['order_id']=$request->order_id;
                $productinfo[$i]['product_name']=$productitem->getOrderProduct->name;
                if(!empty($productitem->getOrderProduct->singleImages->image))
                {
                    $productinfo[$i]['product_image']=url('img/products_image/'.$productitem->getOrderProduct->singleImages->image);
                }
            }
        
            $resultArray['status']='1';
            $resultArray['message']=trans('api.review_list_data');
            $resultArray['data']=$productinfo;
            echo json_encode($resultArray); exit;    
    }

    public function reviewStore(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        $validator = Validator::make($request->all(), [
                'user_id'=>'required',
                'order_id'=>'required',
                'p_id'=>'required',
            ]);
        if($validator->fails())
        {
            $resultArray['status']='0';
            $resultArray['message']=trans('api.Invalid parameters.');
            echo json_encode($resultArray); exit;      
        }
            $reviwadd= new Review;
            if($request->hasFile('image1'))
            {
                $image = $request->file('image1');
                $filename = rand(1111,9999).'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/img/review');
                $image->move($destinationPath, $filename);
                $reviwadd->image= $filename;
            }
            if($request->hasFile('image2'))
            {
                $image = $request->file('image2');
                $filename2 = rand(11111,99999).'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/img/review');
                $image->move($destinationPath, $filename2);
                $reviwadd->image2= $filename2 ;
            }
            
            $reviwadd->user_id=$request->user_id;
            $reviwadd->p_id=$request->p_id;
            $reviwadd->order_id=$request->order_id;
            $reviwadd->rating=$request->rating;
            $reviwadd->description=$request->description;
            $reviwadd->save();

            $resultArray['status']='1';
            $resultArray['message']=trans('api.review_add');
            echo json_encode($resultArray); exit;    
    }   

    public function myCoupons(Request $request)
    {
        $lang = !empty($request->lang) ? $request->lang : 'en' ;
        App::setLocale($lang);
        // $validator = Validator::make($request->all(), [
        //         'user_id'=>'required',
        //         'order_id'=>'required',
        //     ]);
        // if($validator->fails())
        // {
        //     $resultArray['status']='0';
        //     $resultArray['message']=trans('api.Invalid parameters.');
        //     echo json_encode($resultArray); exit;      
        // }
            $today=date('Y-m-d');
            $mycoupons= Coupon::where('start_date','<=',$today)->where('end_date','>=',$today)->get();
            $couponArray=array();
            foreach($mycoupons as $c=>$coupon)
            {
                 $couponArray[$c]['min_amount']=$coupon->min_order_value;
                 $couponArray[$c]['max_amount']=$coupon->max_discount;
                 $couponArray[$c]['coupon']=isset($coupon->coupon)?$coupon->coupon:'';
                 $couponArray[$c]['percentage']=$coupon->percentage;
                 $couponArray[$c]['start_date']=$coupon->start_date;
            }

            $resultArray['status']='1';
            $resultArray['message']=trans('api.coupon_list');
            $resultArray['coupon_list']=$couponArray;
            echo json_encode($resultArray); exit;    
    }
}   