-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 18, 2023 at 02:26 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `carebee`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
CREATE TABLE IF NOT EXISTS `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_title` varchar(255) DEFAULT NULL,
  `banner_content` text,
  `banner_image` varchar(255) DEFAULT NULL,
  `display_order` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `banner_title`, `banner_content`, `banner_image`, `display_order`, `status`, `created_at`, `updated_at`) VALUES
(2, 'Health is Wealth', '<p>Good health saves money, bad health cost more</p>', '16601103163.jpg', 1, 1, '2022-08-09 06:59:23', '2022-08-10 05:45:16'),
(3, 'Boost your immune system', '<p>Benefiting from healthcare shouldn&rsquo;t be a matter of luck.&nbsp;Protect yourself and the ones you love</p>', '1660033386slider.jpg', 2, 1, '2022-08-09 08:23:06', '2022-08-10 05:46:54'),
(4, 'How good is your healthcare?', '<p>Caring for the whole patient, not just your symptoms,&nbsp;If you don&rsquo;t take care of your health. . . we will?</p>', '1660110588bg-14.jpg', 3, 1, '2022-08-09 08:28:05', '2022-08-10 05:49:48');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
