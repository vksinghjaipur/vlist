@extends('frontend.layouts.app')

@section('title', app_name() . ' | ' . __('navs.frontend.dashboard') )


@section('content')
@include('frontend.user.user-sidebar')
<div class="col-md-9 col-sm-9">
    <div class="right_detail_box Distributor">
      <div class="heading_text clint_list">
	       <h4>{{ strtoupper($logged_in_user->username) }} GUESS HISTORY</h4>
	       <p>Here you can find your detailed history of guess from across the all leagues of our website!</p>
	   </div>

	  	@php
			$gsuser= App\Models\Guessuser::where('user_id', Auth::id())->get();
			//echo '<pre>'; print_r($gsuser);die();
  		@endphp

	   <div class="row">
	   <div class="col-md-12">	
	   	<table id="example1" class="table table-bordered">
				<thead>
			    	<tr>
			      	<th class="text-center">Sr.No.</th>
			      	<th scope="col">League Name</th>
			      	<th class="text-center">Guess Score User<br> (Home Team)</th>
			      	<th class="text-center font-weight-bold">Final Score API<br> (Home Team)</th>
			      	<th class="text-center">Guess Score (Away Team)</th>
			      	<th class="text-center font-weight-bold">Final Score User<br> API<br> (Away Team)</th>
			      	<th class="text-center">Result</th>
			      	<th class="text-center">Guess Points</th>
			    	</tr>
				</thead>

				<tbody>
					 <?php $total_point= 0;  ?> 
				   @if(isset($gsuser) && count($gsuser) > 0)				   
				   @foreach($gsuser as $youguessuser)
				   <tr>
				      <td class="text-center">{{ $youguessuser->id}}</td>
				      <td>{{ $youguessuser->league_name}}</td>
				      <td class="text-center">{!! $youguessuser->team_home_name.'<br>'.$youguessuser->guess_number_home_team!!}</td>
				      <td class="text-center font-weight-bold">{!! $youguessuser->team_home_name.'<br>'.$youguessuser->goals_home!!}</td>
				      <td class="text-center">{!! $youguessuser->team_away_name.'<br>'.$youguessuser->guess_number_away_team!!}</td>
				      <td class="text-center font-weight-bold">{!! $youguessuser->team_away_name.'<br>'.$youguessuser->goals_away!!}</td>

				      <td class="text-center">	
							<?php  
									if ($youguessuser->guess_number_home_team == $youguessuser->goals_home && $youguessuser->guess_number_away_team == $youguessuser->goals_away) {
    									echo '<button class="btn btn-sm btn-success">Correct Guess</button>';
    									}
									
									else{
											echo '<button class="btn btn-sm btn-danger">Incorrect Guess</button>';
											}
									?>
				      </td>

				      <td class="text-center">
				      <?php  
									if ($youguessuser->guess_number_home_team == $youguessuser->goals_home) {
    									echo $youguessuser->guess_point;
    									}
									elseif ($youguessuser->guess_number_away_team == $youguessuser->goals_away) {
    									echo $youguessuser->guess_point;
											}
									else{
											echo "0";
											}
									?>				
				      </td>

				    </tr>
				   <?php	
				   $total_point = $total_point + ($youguessuser['guess_point']); ?>
				   @endforeach
				   <tr><td class="font-weight-bold text-right" colspan="7">Total Points&nbsp;</td><td class="font-weight-bold"><center>{{$total_point}}</center></td></tr>

				   @else
				    <tr colspan="8"><td colspan="8">
      					<div class="vheading_text">
      						<center><h4>No Guess Hitory Found....</h4></center>
      					</div>
      			</td>
      			</tr>			
      			@endif
      				
				   
				</tbody>
			</table>
		</div>	
	   </div>
	   	
	   <div class="row">
	    	{{-- <div class="col-md-12">
	    		<div class="Here-you-can">
	    			 <ul class="nav">
					    <li class="active"><a data-toggle="tab" href="#home" class="active">On the website</a></li>
					    <li><a data-toggle="tab" href="#menu1">ToTo</a></li>
					    <li><a data-toggle="tab" href="#menu2">Unsettled guess</a></li>
					  </ul>
	    		</div>
	    		 <div class="tab-content tav-text">
				    <div id="home" class="tab-pane fade in active show">
				      <div class="account-page">
				      	<div class="date-box">
						    <input type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						  </div>
						  <span class="apm-filters__date"></span>
						  <div class="date-box">
						  	<input type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						  </div>
						   <div class="date-box">
							 <div class="Show-btn">
							 	 <a href="#">Show</a>
							 </div>
						  </div>
						    <div class="date-box">
							 <div class="Show-btn Request">
							 	 <a href="#">Request history</a>
							 </div>
						  </div>
				      </div>
				      <div class="sports-box">
				      	<div class="wrap_multirow">
				      		<div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1">Sports</label>
							  </div>
							  <div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1">Live</label>
							  </div>
				      	</div>
				      	<div class="wrap_multirow">
				      		<div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1"> Settled</label>
							  </div>
							  <div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1">Unsettled</label>
							  </div>
				      	</div>
				      	<div class="wrap_multirow">	
							  <div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1">By settlement time</label>
							  </div>
				      	</div>
				      	<div class="wrap_multirow">	
							 <div class="form-group from-box-sec">
						    <select class="form-control" id="exampleFormControlSelect1">
						      <option>All</option>
						      <option>Single guess</option>
						      <option>Accumulator</option>
						      <option>Constructor</option>
						      <option>Lucky</option>
						      <option>Patent</option>
						      <option>Multibet</option>
						    </select>
						  </div>
				      	</div>
				      		<div class="wrap_multirow">	
							 <div class="form-group from-box-sec">
						    <select class="form-control" id="exampleFormControlSelect1">
						      <option>Time of guess</option>
						      <option>Guess amount</option>
						      <option>Odds</option>
						      <option>Status</option>
						    </select>
						  </div>
				      	</div>
				      </div>
				      <div class="no-bets" >No guess for selected period!</div>
				    </div>
				    <div id="menu1" class="tab-pane fade">
				     <div class="account-page account-page toto">
				      	<div class="date-box">
						    <input type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						  </div>
						  <span class="apm-filters__date"></span>
						  <div class="date-box">
						  	<input type="date" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						  </div>
						   <div class="date-box">
							 <div class="Show-btn">
							 	 <a href="#">Show</a>
							 </div>
						  </div>  
				      </div>
				      <div class="sports-box">
				      	<div class="wrap_multirow">
							  <div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1"> Football</label>
							  </div>
				      	     </div>
				      		<div class="wrap_multirow">
							  <div class="form-check">
							    <input type="checkbox" class="form-check-input" id="exampleCheck1">
							    <label class="form-check-label" for="exampleCheck1">Unsettled</label>
							  </div>
				      	   </div>
				      		<div class="wrap_multirow">	
							 <div class="form-group from-box-sec">
						    <select class="form-control" id="exampleFormControlSelect1">
						      <option>Bet amount</option>
						      <option>Time of guess</option>
						    </select>
						  </div>
				      	</div>
				      </div>
				       <div class="no-bets" >No guess for selected period!</div>
				    </div>
				    <div id="menu2" class="tab-pane fade">
				    
				    <div class="no-bets" >No guess for selected period!</div>
				    </div>
				  </div> --}}
	    	</div>
	    </div>
          
    </div>

    
</div>

@endsection