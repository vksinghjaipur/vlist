<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">
            <li class="nav-title">
                @lang('menus.backend.sidebar.general')
            </li>
            
            <li class="nav-item">
                <a class="nav-link {{
                    active_class(Route::is('admin/dashboard'))
                }}" href="{{ route('admin.dashboard') }}">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    @lang('menus.backend.sidebar.dashboard')
                </a>
            </li>

            @if ($logged_in_user->isAdmin())
                <li class="nav-title">
                    @lang('menus.backend.sidebar.system')
                </li>

                <li class="nav-item nav-dropdown {{
                    active_class(Route::is('admin/auth*'), 'open')
                }}">
                    <a class="nav-link nav-dropdown-toggle {{
                        active_class(Route::is('admin/auth*'))
                    }}" href="#">
                        <i class="nav-icon far fa-user"></i>
                        @lang('menus.backend.access.title')

                        @if ($pending_approval > 0)
                            <span class="badge badge-danger">{{ $pending_approval }}</span>
                        @endif
                    </a>

                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                active_class(Route::is('admin/auth/user*'))
                            }}" href="{{ route('admin.auth.user.index') }}">
                                @lang('labels.backend.access.users.management')

                                @if ($pending_approval > 0)
                                    <span class="badge badge-danger">{{ $pending_approval }}</span>
                                @endif
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{
                                active_class(Route::is('admin/auth/role*'))
                            }}" href="{{ route('admin.auth.role.index') }}">
                                @lang('labels.backend.access.roles.management')
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link {{
                                active_class(Route::is('admin/auth/permission*'))
                            }}" href="{{ route('admin.auth.permission.index') }}">
                                @lang('labels.backend.access.permissions.management')
                            </a>
                        </li>
                    </ul>
                </li>

                <li class="divider"></li>


    <!--ADMIN GESS ZONE Start-->
                <li class="nav-item nav-dropdown {{
                    active_class(Route::is('admin/general-settings*'), 'open')
                }}">
                    <a class="nav-link nav-dropdown-toggle {{active_class(Route::is('admin/general-settings*'))}}" href="#">
                    <i class="nav-icon fas fa-list"></i> @lang('menus.backend.settings.admin')
                    </a>
					
                    <!--Guess Box Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                           <a class="nav-link {{
                                    active_class(Route::is('admin/guessfixtures/guessfixtures*'))
                            }}" href="{{ route('admin.guessfixtures.index') }}">
                                <i class="nav-icon fas fa-sync"></i>
                                @lang('labels.backend.access.guessfixtures.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Guess Box Create end-->

                    <!--Guess Match Result start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/matchresults/matchresults*'))
                            }}" href="{{ route('admin.matchresults.index') }}">
                                <i class="nav-icon fa fa-trophy"></i>
                                @lang('labels.backend.access.matchresults.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Guess Match Result end---> 

                    <!--Guess Point Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guesspoints/guesspoints*'))
                            }}" href="{{ route('admin.guesspoints.index') }}">
                                <i class="nav-icon fa fa-dollar-sign"></i>
                                @lang('labels.backend.access.guesspoints.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Guess Point end- --->

                    <!--Guess Point Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guessamounts/guessamounts*'))
                            }}" href="{{ route('admin.guessamounts.index') }}">
                                <i class="nav-icon fa fa-dollar-sign"></i>
                                @lang('labels.backend.access.guessamounts.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Guess Point end- --->


                    <!--Guess Plan Fees Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guessplans/guessplans*'))
                            }}" href="{{ route('admin.guessplans.index') }}">
                                <i class="nav-icon fa fa-dollar-sign"></i>
                                @lang('labels.backend.access.guessplans.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Guess Plan Fees end- --------->


                    <!--Best Player start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/bestplayers/bestplayers*'))
                            }}" href="{{ route('admin.bestplayers.index') }}">
                                <i class="nav-icon fas fa-skating"></i>
                                @lang('labels.backend.access.bestplayers.management')
                            </a>
                        </li>
                    </ul>
                    <!--Best Player end-->


                    <!--League Winner Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/leaguewinners/leaguewinners*'))
                            }}" href="{{ route('admin.leaguewinners.index') }}">
                                <i class="nav-icon fa fa-trophy"></i>
                                @lang('labels.backend.access.leaguewinners.management')
                            </a>
                        </li>
                    </ul>    
                    <!--League Winner Create end-->

                    <!--Upcomimg Matches Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/upcomingmatches/upcomingmatches*'))
                            }}" href="{{ route('admin.upcomingmatches.index') }}">
                                <i class="nav-icon fa fa-trophy"></i>
                                @lang('labels.backend.access.upcomingmatches.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Upcomimg Matches Create end----->                                              
                    
        <!--Guess Matches end--------------->

                    
                    <!--Rewards Create start------------>
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/rewards/rewards*'))
                            }}" href="{{ route('admin.rewards.index') }}">
                                <i class="nav-icon fa fa-trophy"></i>
                                @lang('labels.backend.access.rewards.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Rewards Create end- --->

                    <!--Payments Create start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/payments/payments*'))
                            }}" href="{{ route('admin.payments.index') }}">
                                <i class="nav-icon fa fa-dollar-sign"></i>
                                @lang('labels.backend.access.payments.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Payments Create end- --->           
                   
                </li>
    <!--ADMIN GUESS ZONE End-->    
                

                <li class="divider"></li>

                

                <!--USER GUESS MANAGEMENT ZONE Start-->
                <li class="nav-item nav-dropdown {{
                    active_class(Route::is('admin/general-settings*'), 'open')
                }}">
                    <a class="nav-link nav-dropdown-toggle {{active_class(Route::is('admin/general-settings*'))}}" href="#">
                    <i class="nav-icon fas fa-list"></i> @lang('menus.backend.settings.user')
                    </a>
                    
                    <!--Guess Users List start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guessusers/guessusers*'))
                                }}" href="{{ route('admin.guessusers.index') }}">
                                <!--<i class="nav-icon fas fa-soccer-ball-o"></i>-->
                                <i class="nav-icon far fa-user"></i>
                                @lang('labels.backend.access.guessusers.management')
                            </a>
                        </li>
                    </ul>
                    <!--User Guess List end-->

                    <!--Guess Champion List start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guesschampions/guesschampions*'))
                                }}" href="{{ route('admin.guesschampions.index') }}">
                                <!--<i class="nav-icon fas fa-soccer-ball-o"></i>-->
                                <i class="nav-icon far fa-user"></i>
                                @lang('labels.backend.access.guesschampions.management')
                            </a>
                        </li>
                    </ul>
                    <!--User Champion List end-->

                    <!--Users Accounts List start-->
                    {{-- <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/useraccounts/useraccounts*'))
                                }}" href="{{ route('admin.useraccounts.index') }}">
                                <!-<i class="nav-icon fas fa-soccer-ball-o"></i>->
                                <i class="nav-icon far fa-user"></i>
                                @lang('labels.backend.access.useraccounts.management')
                            </a>
                        </li>
                    </ul> --}}
                    <!--Users Accounts List end-->  
          
                    <!--Guess Best Players start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/guessplayers/guessplayers*'))
                                }}" href="{{ route('admin.guessplayers.index') }}">
                                <i class="nav-icon fas fa-skating"></i>
                                @lang('labels.backend.access.guessplayers.management')
                            </a>
                        </li>
                    </ul>
                    <!--Guess Best Players end-->               

                    <!--League Winner start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                           <a class="nav-link {{
                                    active_class(Route::is('admin/guesslistlwinners/guesslistlwinners*'))
                                }}" href="{{ route('admin.guesslistlwinners.index') }}">
                                <i class="nav-icon fas fa-skating"></i>
                                @lang('labels.backend.access.guesslistlwinners.management')
                            </a>
                        </li>
                    </ul>    
                    <!--League Winner end-->   
                </li>
                <!--USER GUESS MANAGEMENT ZONE End--> 
                
                
                <li class="divider"></li> 


                <!--API Management Start-->
                <li class="nav-item nav-dropdown {{
                    active_class(Route::is('admin/general-settings*'), 'open')
                }}">
                    <a class="nav-link nav-dropdown-toggle {{active_class(Route::is('admin/general-settings*'))}}" href="#">
                    <i class="nav-icon fas fa-list"></i> @lang('menus.backend.settings.api')
                    </a>    

                    <!---Countries start--->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/countries/countries*'))
                            }}" href="{{ route('admin.countries.index') }}">
                                    <i class="nav-icon fas fa-globe"></i>
                                    @lang('labels.backend.access.countries.management')
                            </a>
                        </li>
                    </ul>    
                    <!---Countries End---->

                    <!--Leagues start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/leagues/leagues*'))
                            }}" href="{{ route('admin.leagues.index') }}">
                                    <i class="nav-icon fa fa-trophy"></i>
                                        @lang('labels.backend.access.leagues.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Leagues End-->

                    <!--Fixtures Matches start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                           <a class="nav-link {{
                                    active_class(Route::is('admin/fixtures/fixtures*'))
                            }}" href="{{ route('admin.fixtures.index') }}">
                                <i class="nav-icon fa fa-soccer-ball-o"></i>
                                @lang('labels.backend.access.fixtures.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Fixture Matches end-->

                    <!--Fixtures Players start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                           <a class="nav-link {{
                                    active_class(Route::is('admin/fixtureplayers/fixtureplayers*'))
                            }}" href="{{ route('admin.fixtureplayers.index') }}">
                                <i class="nav-icon fas fa-skating"></i>
                                @lang('labels.backend.access.fixtureplayers.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Fixture Players end-->
                    
                    <!--Palyers start-->
                    <ul class="nav-dropdown-items">
                        <li class="nav-item">
                            <a class="nav-link {{
                                    active_class(Route::is('admin/players/players*'))
                            }}" href="{{ route('admin.players.index') }}">
                                    <i class="nav-icon fas fa-skating"></i>
                                        @lang('labels.backend.access.players.management')
                            </a>
                        </li>
                    </ul>    
                    <!--Players End-->
                </li>    
                <!--API Management End--->


				
				<!-- Site Management Start-->
                <li class="divider"></li>

                    <li class="nav-item nav-dropdown {{
                        active_class(Route::is('admin/general-settings*'), 'open')
                    }}">
                        <a class="nav-link nav-dropdown-toggle {{active_class(Route::is('admin/general-settings*'))}}" href="#">
                        <i class="nav-icon fas fa-list"></i> @lang('menus.backend.settings.main')
                        </a>

                      
                        <!--Menu Pages Management start-->
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link {{
                                active_class(Route::is('admin/pages'))}}" href="{{ route('admin.pages.index') }}">
                                <i class="nav-icon fas fa-file"></i>
                                @lang('menus.backend.sidebar.pages')
                                </a>
                            </li>
                        </ul>    
                        <!--Menu Pages Management End-->

                        <!--Term info Pages Management start-->
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link {{
                                active_class(Route::is('admin/terms'))}}" href="{{ route('admin.terms.index') }}">
                                <i class="nav-icon fas fa-file"></i>
                                @lang('menus.backend.sidebar.informations')
                                </a>
                            </li>
                        </ul>    
                        <!--Term info Pages Management End-->

                        <!--Google Ads start-->
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link {{
                                active_class(Route::is('admin/googleads'))}}" href="{{ route('admin.googleads.index') }}">
                                <i class="nav-icon fas fa-ad"></i>
                                @lang('menus.backend.sidebar.googleads')
                                </a>
                            </li>
                        </ul>    
                        <!--Google Ads End-->

                        <!--Site Settings Start-->
                        <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link {{
                                active_class(Route::is('admin/settings*'))}}" href="{{ route('admin.settings.edit', 1) }}">
                                 <i class="fa fa-gear"></i>
                                @lang('menus.backend.sidebar.settings')
                                </a>
                            </li>
                        </ul>    
                       <!--Site Settings End-->

                        <!--Social Sharing start-->    
                        {{-- <ul class="nav-dropdown-items">
                            <li class="nav-item">
                                <a class="nav-link {{
                                active_class(Route::is('admin/socials'))
                            }}" href="{{ route('admin.socials.index') }}">
                                    @lang('labels.backend.access.socials.management')
                                </a>
                            </li>
                        </ul> --}}
                        <!--Social Sharing end-->

                </li>
                <!--Site Management End-->

                              	
				
				<li class="divider"></li>

                <!--Blog Management Start-->
                <li class="nav-item nav-dropdown {{
                    active_class(Route::is('admin/blogs'), 'open')
                }}">
                    <a class="nav-link nav-dropdown-toggle {{
                            active_class(Route::is('admin/blogs*'))
                        }}" href="#">
                        <i class="nav-icon fas fa-newspaper-o" style="font-size:15px;color:green"></i> @lang('menus.backend.sidebar.blogs')
                    </a>

                    <ul class="nav-dropdown-items">

                        <li class="nav-item">
                            <a class="nav-link {{ active_class(Route::is('admin/blogs')) }}" 
                                href="{{ route('admin.blogs.index') }}">
                                @lang('labels.backend.access.blogs.management')
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link {{
                            active_class(Route::is('admin/blogs/blog-categories*'))
                        }}" href="{{ route('admin.blog-categories.index') }}">
                                @lang('labels.backend.access.blog-category.management')
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link {{
                            active_class(Route::is('admin/blogs/blog-tags*'))
                        }}" href="{{ route('admin.blog-tags.index') }}">
                                @lang('labels.backend.access.blog-tag.management')
                            </a>
                        </li>
                    </ul>
                </li>
                <!--Blog Management End-->
												                
                <li class="divider"></li>


                <!--Manually Update Fixture Matches start-->
                <li class="nav-item">
                    <a class="nav-link {{
                            active_class(Route::is('admin/updatefixures/updatefixures*'))
                    }}" href="{{ route('admin.updatefixtures.index') }}">
                        <i class="nav-icon fas fa-futbol"></i>
                        @lang('labels.backend.access.updatefixtures.management')
                    </a>
                </li> 
                <!--Manually Update Fixture Matches end- --->

            @endif
        </ul>
    </nav>

    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
</div><!--sidebar-->
