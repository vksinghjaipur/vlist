@extends('backend.layouts.app')

@section('title', app_name() . ' | ' . __('labels.backend.access.guessfixtures.management'))

@section('breadcrumb-links')
@include('backend.guessfixtures.includes.breadcrumb-links')
@endsection

@section('content')
<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-sm-5">
                <h4 class="card-title mb-0">
                    {{ __('labels.backend.access.guessfixtures.management') }} <small class="text-muted">{{ __('labels.backend.access.guessfixtures.active') }}</small>
                </h4>
            </div>
            <!--col-->
        </div>
        <!--row-->
        <center><h4><u>Create Matches (Fixtures) By Admin For Guess Matches</u></h4></center>
        <?php $matches_count = DB::table('guessfixtures')->count(); ?>
        <strong><span>Total Matches (API): </span><span class="text-danger"> {{ $matches_count }}</span></strong><span><center><strong>Status->  <span class="text-success">Active = Guess On,</span> <span class="text-danger">Inactive = Guess Off</span></center></strong></span><br>
          <center><a class="btn btn-info" href="{{ url('import/fixtures') }}" target="_blank">Click for Update Matches From API</a></center>

        <div class="row mt-4">
            <div class="col">
                <div class="row">
                    <?php   $country = DB::table('countries')->get();?>
                    <div class="col-md-4">
                        <select class="form-control text-info font-weight-bold" id="country-dropdown">
                            <option value="">Select Country Name</option>
                            @foreach ($country->unique('name') as $countrys) 
                            <option class="text-info font-weight-bold" value="{{$countrys->name}}">
                            {{$countrys->name}}
                            </option>
                            @endforeach
                        </select>
                    </div>
                         
                    <div class="col-md-4">
                        <select class="form-control getleagename text-dark font-weight-bold" id="state-dropdown"></select>
                    </div>        
                </div><br>
                {{-- <div class="table-responsive"> --}}
                    <table id="guessfixtures-table" class="table table-bordered" data-ajax_url="{{ route("admin.guessfixtures.get") }}">
                        <thead>
                            <tr>   
                                <th>{{-- <input type="checkbox" name="main_checkbox"><label></label> --}}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_id') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_country') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_name') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.team') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.league_season') }}</th>
                                {{-- <th>{{ trans('labels.backend.access.guessfixtures.table.start') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.end') }}</th> --}}
                                
                                <th align="center" style="width: 130px;">{{ trans('labels.backend.access.guessfixtures.table.publish_datetime') }}</th>
                                <th>{{ trans('labels.backend.access.guessfixtures.table.date') }}</th>
                                 <th class="text-center"><button class="btn btn-sm btn-success d-none" id="activeInactiveBtn">Active-Inactive</button>{{ trans('labels.backend.access.guessfixtures.table.status') }}</th>
                                                               
                                 <th class="text-center"><button class="btn btn-sm btn-danger d-none" id="deleteAllBtn">Delete All</button>{{ trans('labels.general.actions')}}</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
            <!--col-->
        </div>
        <!--row-->

    </div>
    <!--card-body-->
</div>
<!----------------------V Delete All Function Start------------------------------------->
<script src="{{ asset('vkalldelete/datatable/js/jquery.dataTables.min.js') }}"></script>
<script src="{{ asset('vkalldelete/sweetalert2/sweetalert2.min.js') }}"></script>
<script src="{{ asset('vkalldelete/toastr/toastr.min.js') }}"></script>
<script type="text/javascript">
    toastr.options.preventDuplicates = true;
         $.ajaxSetup({
             headers:{
                 'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
             }
         });
</script>   
            
<script type="text/javascript">
    $(document).on('click','input[name="main_checkbox"]', function(){
          if(this.checked){
            $('input[name="league_name"]').each(function(){
                this.checked = true;
            });
          }else{
             $('input[name="league_name"]').each(function(){
                 this.checked = false;
             });
          }
          toggledeleteAllBtn();
    });


    $(document).on('change','input[name="league_name"]', function(){

       if( $('input[name="league_name"]').length == $('input[name="league_name"]:checked').length ){
           $('input[name="main_checkbox"]').prop('checked', true);
       }else{
           $('input[name="main_checkbox"]').prop('checked', false);
       }
       toggledeleteAllBtn();
    });



    function toggledeleteAllBtn(){
       if( $('input[name="league_name"]:checked').length > 0 ){
           $('button#deleteAllBtn').text('Delete ('+$('input[name="league_name"]:checked').length+')').removeClass('d-none');
       }else{
           //$('button#deleteAllBtn');
           $('button#deleteAllBtn').addClass('d-none');
       }
    }


/* V Delete All Button */

$(document).on('click','button#deleteAllBtn', function(){
            var checkedCountries = [];
            $('input[name="league_name"]:checked').each(function(){
               checkedCountries.push($(this).data('id'));
            });
            var url = '{{ route("deleteallleagues") }}';
            if(checkedCountries.length > 0){
            swal.fire({
                   title:'Are you sure?',
                   html:'You want to delete <b>('+checkedCountries.length+')</b> countries',
                   showCancelButton:true,
                   showCloseButton:true,
                   confirmButtonText:'Yes, Delete',
                   cancelButtonText:'Cancel',
                   confirmButtonColor:'#556ee6',
                   cancelButtonColor:'#d33',
                   width:300,
                   allowOutsideClick:false
                }).then(function(result){
                   if(result.value){
                       $.post(url,{countries_ids:checkedCountries},function(data){
                          if(data.code == 1){
                              $('#guessfixtures-table').DataTable().ajax.reload(null, true);
                              toastr.success(data.msg);
                              window.location.reload();
                          }
                       },'json');
                   }
                })
            }
        });    

</script>

<!--------------------------V Delete All Function End-------------------------------------->

<!----------------------------V Active Inactive Start ------------------------------------->
<script type="text/javascript">
    toastr.options.preventDuplicates = true;
         $.ajaxSetup({
             headers:{
                 'X-CSRF-TOKEN':$('meta[name="csrf-token"]').attr('content')
             }
         });
</script>    
            
<script type="text/javascript">
    $(document).on('click','input[name="main_checkbox"]', function(){
          if(this.checked){
            $('input[name="league_name"]').each(function(){
                this.checked = true;
            });
          }else{
             $('input[name="league_name"]').each(function(){
                 this.checked = false;
             });
          }
          toggleactiveInactiveBtn();
    });



    $(document).on('change','input[name="league_name"]', function(){

       if( $('input[name="league_name"]').length == $('input[name="league_name"]:checked').length ){
           $('input[name="main_checkbox"]').prop('checked', true);
       }else{
           $('input[name="main_checkbox"]').prop('checked', false);
       }
       toggleactiveInactiveBtn();
    });



    function toggleactiveInactiveBtn(){
       if( $('input[name="league_name"]:checked').length > 0 ){
           $('button#activeInactiveBtn').text('Active-Inactive ('+$('input[name="league_name"]:checked').length+')').removeClass('d-none');
       }else{
           //$('button#activeInactiveBtn');
           $('button#activeInactiveBtn').addClass('d-none');
       }
    }


/* V Delete All Button */
$(document).on('click','button#activeInactiveBtn', function(){
            var checkedCountries = [];
            $('input[name="league_name"]:checked').each(function(){
               checkedCountries.push($(this).data('id'));
            });
            //alert(checkedCountries);
            var url = '{{ route("changeStatusGuessFixture") }}';
            if(checkedCountries.length > 0){
            swal.fire({
                   title:'Are you sure?',
                   html:'Active or Inactive <b>('+checkedCountries.length+')</b> Leagues',
                   showCancelButton:true,
                   showCloseButton:true,
                   confirmButtonText:'Yes, Active or Inactive',
                   cancelButtonText:'Cancel',
                   confirmButtonColor:'#556ee6',
                   cancelButtonColor:'#d33',
                   width:300,
                   allowOutsideClick:false
                }).then(function(result){
                   if(result.value){
                       $.get(url,{leagues_ids:checkedCountries},function(data){
                          if(data.code == 1){
                              $('#leaguewinners-table').DataTable().ajax.reload(null, true);
                              toastr.success(data.msg);
                              window.location.reload();
                          }
                       },'json');
                   }
                })
            }
        });    

</script>

<!----------------------------V Active Inactive End ------------------------------------------->


<!----------------------------V GS Drop Down League Search Start------------------------------->
<script>
    $(document).ready(function() {

        var table = $('#guessfixtures-table').DataTable({
             retrieve: true,
          // dom: 'lrtip'

         // "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
        });

        $('.getleagename').on('change', function(){
             //table.columns(1).search( this.value ).draw();
             var selectedValue= $(".getleagename").val();  
            if (this.value == selectedValue) {
                table.column( 1 )
                    .search( selectedValue ? '^'+$(this).val()+'$' : selectedValue, true, false )
                    .draw();
               //table.columns(1).search(this.value,true).draw();
            }
        });
    });  
</script>

<script type="text/javascript">
$(document).ready(function() {
    $('#country-dropdown').on('change', function() {
    var country_id = this.value;
    $("#state-dropdown").html('');
    $.ajax({
    url: "{{ url('getcountryguess') }}",
    type: "get",
    data: {
    country_id: country_id,
    _token: '{{csrf_token()}}' 
    },
    dataType : 'json',
    success: function(result){
    $('#state-dropdown').html('<option class="text-dark font-weight-bold" value="">Select League</option>'); 
    $.each(result.countries,function(key,value){

    $("#state-dropdown").append('<option value="'+value.league_id+'">'+value.league_name+'</option>');
    });
    $('#city-dropdown').html('<option value="">Select League Name</option>'); 
    }
    });
    });    
 
});
</script>
<!--------------------------V GS Drop Down League Search End--------------------------------->

@endsection


@section('pagescript')
<script>
    FTX.Utils.documentReady(function() {
        FTX.Guessfixtures.list.init();
    });
</script>



@stop

