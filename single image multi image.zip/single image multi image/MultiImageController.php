<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MultipleImage;

class MultiImageController extends Controller
{
    
    public function index(){
        return view('multipleimage.index');
    }


    public function create(){
        return view('multipleimage.create');
    }

    public function store(Request $request){

        $fileNames = [];
        foreach($request->file('photo') as $image)
        {
            $imageName = $image->getClientOriginalName();
            $image->move(public_path().'/mimages/',$imageName);
            $fileNames[] = $imageName;
        }

        // $images = json_encode($fileNames);
        // $images->name = $request->name; 
        // MultipleImage::create(['photo'=>$images]);

        $file= new MultipleImage();
        $file->name= $request->name;
        $file->photo = json_encode($fileNames);
        $file->save();

        return view('multipleimage.index');
    }
    
}
