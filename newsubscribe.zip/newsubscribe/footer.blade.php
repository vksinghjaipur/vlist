

<footer class="footer sec-space">
<div class="container">
<div class="row">
  <div class="col-5">
    <div class="about-div">
      <img src="{{ asset('img/logo-f.png') }}" class="img-fluid">
      <div class="footer-logo">
         
          @if(isset($footersettings[0]) && $footersettings[0]['aboutus'])
           <p>{{ $footersettings[0]['aboutus'] }}</p>
         @else
          <p>canadianhomesteads "takeing real estate to the highest level</p>
         @endif
      

      @if(isset($footersettings[0]) && $footersettings[0]['email'])
      <p>Phone: {{ $footersettings[0]['phone'] }}</p>
      @else
      <p>Phone: Admin Phone</p>
      @endif

      @if(isset($footersettings[0]) && $footersettings[0]['email'])
        <p>Email: {{ $footersettings[0]['email'] }}</p>
      @else
        <p>Email: Admin Email</p>      
      @endif  
     </div>
    </div>
  </div>
  <div class="col-3">
    <div class="use-link">
      <h3>Useful Link</h3>
      <ul>
        <li><a href="{{ route('search') }}">Search Land</a></li>
        <li><a href="{{ route('property') }}">Advertise</a></li>
        <li><a href="{{ route('contact') }}">Contact</a></li>
        <li><a href="{{ route('blog') }}">Blog</a></li>
        @guest
        <li><a href="{{ route('login') }}">Login</a></li>
        @endguest
      </ul>
    </div>
  </div>

  <div class="col-4">
    <div class="use-link">
      <h3>Subscribe Newsletter</h3>
      <p>Lorem Ipsum is simply dummy text of the printing and typesetting</p>
      <div class="form-group mt-3">
        <form action="{{ route('newsletter')}}" method="post">
          {{ csrf_field() }}
          <div class="input-group">
            <input type="email" name="email" class="form-control f-em" placeholder="Enter your email..." required>
            <span class="input-group-btn">
              <button type="submit" class="news-btn"><i class="fa fa-paper-plane"></i></button>
            </span>
          </div>
      </form>
      </div>
      <ul class="social-link">
        <li> 
          @if(isset($footersettings[0]) && $footersettings[0]['facebook'])
          <a href="{{ $footersettings[0]['facebook'] }}" target="_blank">
            <i class="fa fa-facebook"></i>
          </a>
           @endif
        </li>

        <li>
           @if(isset($footersettings[0]) && $footersettings[0]['twitter'])
          <a href="{{ $footersettings[0]['twitter'] }}" target="_blank" >
            <i class="fa fa-twitter"></i>
          </a>
          @endif
        </li>

        <li>
          @if(isset($footersettings[0]) && $footersettings[0]['google_plus'])
          <a href="{{ $footersettings[0]['google_plus'] }}" target="_blank" >
            <i class="fa fa-google-plus"></i>
          </a>
          @endif
        </li>
      </ul>
    </div>
  </div>
</div>
</div>
</footer>
<div class="copyright-div">
<div class="container">
<div class="row">
  <div class="col-md text-center">
    @if(isset($footersettings[0]) && $footersettings[0]['footer'])
      <p>{{ $footersettings[0]['footer'] }}</p>
    @else
      <p> © 2019 canadianhomesteads all rights reserved</p>
    @endif
  </div>
</div>
</div>
</div>




<!-- 

<footer class="page-footer indigo darken-2">
    <div class="container">
        <div class="row">
            <div class="col m4 s12">
                <h5 class="white-text uppercase">About Us</h5>
                @if(isset($footersettings[0]) && $footersettings[0]['aboutus'])
                    <p class="grey-text text-lighten-4">{{ $footersettings[0]['aboutus'] }}</p>
                @else
                    <p class="grey-text text-lighten-4">Real estate company description goes here.</p>
                @endif
            </div>
            <div class="col m6 s12">
                <h5 class="white-text uppercase">Recent Properties</h5>
                <ul class="collection border0">

                    @foreach($footerproperties as $property)
                    <li class="collection-item transparent clearfix p-0 border0">
                        <span class="card-image-bg m-r-10" style="background-image:url({{Storage::disk('public')->url('app/public/property/'.$property->image)}});width:60px;height:45px;float:left;"></span>
                        <div class="float-left">
                            <h5 class="font-18 m-b-0 m-t-5">
                                <a href="{{ route('property.show',$property->slug) }}" class="white-text">{{ str_limit($property->title,40) }}</a>
                            </h5>
                            <p class="m-t-0 m-b-5 grey-text text-lighten-1">Bedroom: {{ $property->bedroom }} Bathroom: {{ $property->bathroom }} </p>
                        </div>
                    </li>
                    @endforeach

                </ul>
            </div>
            <div class="col m2 s12">
                <h5 class="white-text uppercase">Menu</h5>
                <ul>
                    <li class="uppercase {{ Request::is('property*') ? 'underline' : '' }}">
                        <a href="{{ route('property') }}" class="grey-text text-lighten-3">Properties</a>
                    </li>

                    <li class="uppercase {{ Request::is('agents*') ? 'underline' : '' }}">
                        <a href="{{ route('agents') }}" class="grey-text text-lighten-3">Agents</a>
                    </li>

                    <li class="uppercase {{ Request::is('gallery*') ? 'underline' : '' }}">
                        <a href="{{ route('gallery') }}" class="grey-text text-lighten-3">Gallery</a>
                    </li>

                    <li class="uppercase {{ Request::is('blog*') ? 'underline' : '' }}">
                        <a href="{{ route('blog') }}" class="grey-text text-lighten-3">Blog</a>
                    </li>

                    <li class="uppercase {{ Request::is('contact') ? 'underline' : '' }}">
                        <a href="{{ route('contact') }}" class="grey-text text-lighten-3">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="footer-copyright">
        <div class="container">
            @if(isset($footersettings[0]) && $footersettings[0]['footer'])
                {{ $footersettings[0]['footer'] }}
            @else
                © 2018 Developer Canvas Studio.
            @endif

            @if(isset($footersettings[0]) && $footersettings[0]['facebook'])
                <a class="grey-text text-lighten-4 right" href="{{ $footersettings[0]['facebook'] }}" target="_blank">FACEBOOK</a>
            @endif
            @if(isset($footersettings[0]) && $footersettings[0]['twitter'])
                <a class="grey-text text-lighten-4 right m-r-10" href="{{ $footersettings[0]['twitter'] }}" target="_blank">TWITTER</a>
            @endif
           

        </div>
    </div>
</footer> 

 -->